# LEXA CI contract-test fix

This patch bundle fixes the selector assumption that caused the failed frontend contract test in workflow run 40462755388.

## Apply
Replace the repository file `apps/web/tests/phase12-live-brand-visibility.test.mjs` with the same path in this ZIP. No production app code is changed by this patch. The updated test searches backward for the selector occurrence that actually declares the logo background image, because responsive CSS may repeat that selector later for sizing only.

## Verify
From `apps/web`, run:

```sh
node --test tests/phase12-live-brand-visibility.test.mjs
npm test
npm run typecheck
npm run build
```

The fix bundle is a targeted patch, not a full export of the live GitHub repository. It should be applied to the current repository tree; it is not intended to replace the entire repository.
