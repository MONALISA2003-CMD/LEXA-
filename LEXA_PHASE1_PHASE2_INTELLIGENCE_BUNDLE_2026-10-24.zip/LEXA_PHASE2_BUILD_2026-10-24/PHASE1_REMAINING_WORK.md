# LEXA Intelligence — Phase 1 Remaining Work

**Review date:** 24 October 2026  
**Repository:** `MONALISA2003-CMD/LEXA-`  
**Reviewed main ZIP-upload commit:** `1fd4ee081bf45be6c78e330e52851d8a33bb4667`  
**Phase 1 source candidate:** `LEXA_PHASE1_IMPLEMENTATION_2026-10-24.zip`

## Status

Phase 1 implementation artifacts are packaged and the bundled synthetic contract tests pass. **Phase 1 is not yet integrated into LEXA's application source.** The inspected `main` upload commit adds the ZIP file itself; the Phase 1 modules and migration are absent as unpacked source paths in that commit. The existing branch `LEXA-branch` was confirmed to exist and contains an API project/analytics router, but the expected `apps/api/app/routes/ai_assistant.py` path could not be resolved there. The combined installer therefore targets the inspected `main` layout; the branch route layout needs reconciliation before installing it there.

The visible GitHub status for the ZIP-upload commit reported a successful Vercel check. That is useful evidence for the uploaded artifact's associated web status, but it does not prove the Python API suite, PostgreSQL migration replay, RLS checks, or authenticated endpoint tests ran. This document does not reopen Phase 0; it treats Phase 0 as green as directed by the project owner.

## Remaining work, in closure order

### P0 — Integrate the source overlay on the intended branch

- [ ] Confirm that `LEXA-branch` has the expected `apps/api/`, `apps/web/`, and `migrations/` source layout, or explicitly use the verified `main` checkout.
- [ ] Run the combined Phase 1 + Phase 2 installer only against an authorized local checkout/worktree. The installer stages changes first, validates anchors, and produces backups for edited files.
- [ ] Review the complete diff manually. Confirm that Phase 1 source modules, API route registration, provider gate, candidate migration 045, clean-replay manifest/runner assertions, tests, and docs are present as application source rather than only inside a ZIP.
- [ ] Commit/push the reviewed source files using an authorized Git workflow. No source commit was made by this tool session.

### P1 — Run real repository regression checks

- [ ] Run all existing API tests, including `test_ai_assistant.py`, `test_business_insights.py`, branch access/permission regressions, and the full `apps/api/tests` suite.
- [ ] Run Python compile/lint/type checks used by the repository and normal CI workflows.
- [ ] Confirm OpenAPI contains `/api/v1/intelligence/capabilities` and the existing AI provider endpoint remains blocked unless an operator explicitly enables an approved policy. API keys being present must not enable execution by themselves.
- [ ] Verify `analytics.read` authorization, tenant identity from the authenticated context, branch-scope fail-closed behavior, safe error payloads, and no secret values in responses/logs.

### P1 — Validate migration 045 on a disposable PostgreSQL database

- [ ] Execute the clean-replay/installer candidate only against a disposable loopback database whose name explicitly identifies replay/test/CI. Do not target Neon or a production host.
- [ ] Verify migration order and prerequisite functions/tables in the full clean replay.
- [ ] Run the runner's security assertions plus explicit adversarial tests: no tenant-A read of tenant-B intelligence jobs/runs; no cross-tenant inserts; branch IDs outside membership scope are blocked; missing tenant context returns no cross-tenant rows.
- [ ] Check the application database role is granted only the operations required by the new contracts. Preserve the append-only run-provenance restriction and verify forced RLS is active.
- [ ] Capture output/receipt as test evidence. Until this passes, migration `045_intelligence_foundation.sql` remains a candidate and must not be applied to the live database.

### P2 — Close provider and operational boundaries

- [ ] Keep all external providers disabled during Phase 1 acceptance. Provider profiles, policy models and safe provider-status reporting are contracts only.
- [ ] Confirm no AI worker/job execution is enabled, no external model call is made by the new intelligence foundation, and no paid fallback is possible.
- [ ] Confirm logs/metrics expose safe identifiers and status only, not prompt text, business record dumps, tokens or credentials.
- [ ] Update the phase status only after source integration, CI, and disposable replay/security checks are recorded. Production deployment is a separate, explicit release decision.

## Evidence that is already available

- Phase 1 synthetic suite in the bundle: **20 passed** in the local test runtime.
- Phase 1 policy defaults deny external model execution; the assistant gate blocks before optional business-summary reads, rate limits and provider network I/O.
- The current session did not apply migration 045, connect to production database services, change provider secrets/settings, or deploy services.

## Phase 1 exit criterion

Phase 1 closes when the overlay is present in the selected branch as normal source files, the full API suite/CI passes, and the disposable PostgreSQL replay proves the migration and tenant/branch boundaries. A green web deployment check on a ZIP upload alone is not this exit criterion.
