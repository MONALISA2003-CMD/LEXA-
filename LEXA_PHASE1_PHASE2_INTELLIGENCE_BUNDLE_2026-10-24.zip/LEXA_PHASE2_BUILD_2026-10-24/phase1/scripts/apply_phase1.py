#!/usr/bin/env python3
"""Safely install the LEXA Phase 1 intelligence overlay into a local checkout.

This script is intentionally local-only: it has no network or infrastructure code.
It refuses ambiguous source layouts, backs up edited existing files, and does not
apply SQL, modify environment files, or run/deploy anything.
"""
from __future__ import annotations

import argparse
import shutil
import sys
from pathlib import Path


BUNDLE_ROOT = Path(__file__).resolve().parents[1]
COPY_PATHS = (
    Path("apps/api/app/intelligence/__init__.py"),
    Path("apps/api/app/intelligence/contracts.py"),
    Path("apps/api/app/intelligence/policy.py"),
    Path("apps/api/app/intelligence/events.py"),
    Path("apps/api/app/intelligence/routes.py"),
    Path("apps/api/tests/test_intelligence_phase1.py"),
    Path("migrations/045_intelligence_foundation.sql"),
    Path("docs/LEXA_INTELLIGENCE_PHASE1_IMPLEMENTATION.md"),
)


class InstallError(RuntimeError):
    pass


def replace_once(source: str, old: str, new: str, label: str) -> str:
    count = source.count(old)
    if count != 1:
        raise InstallError(f"Expected exactly one {label} anchor, found {count}; no edits were written.")
    return source.replace(old, new, 1)


def patch_config(source: str) -> str:
    if "lexa_ai_external_providers_enabled" in source:
        return source
    anchor = "    model_config = SettingsConfigDict(env_file=\".env\", extra=\"ignore\")"
    settings = '''    # External AI is globally disabled unless explicitly approved by an operator.\n    lexa_ai_external_providers_enabled: bool = False\n    lexa_ai_allowed_providers: str = \"\"\n    lexa_ai_paid_providers_enabled: bool = False\n    lexa_ai_aggregates_external_enabled: bool = False\n    lexa_ai_confidential_external_enabled: bool = False\n'''
    return replace_once(source, anchor, settings + anchor, "Settings.model_config")


def patch_main(source: str) -> str:
    if "from .intelligence.routes import router as intelligence_router" not in source:
        source = replace_once(
            source,
            "from .kernel import router as kernel_router\n",
            "from .kernel import router as kernel_router\nfrom .intelligence.routes import router as intelligence_router\n",
            "main intelligence router import",
        )
    if "app.include_router(intelligence_router, prefix=\"/api/v1\")" not in source:
        source = replace_once(
            source,
            'app.include_router(ai_assistant.router, prefix="/api/v1")\n',
            'app.include_router(ai_assistant.router, prefix="/api/v1")\napp.include_router(intelligence_router, prefix="/api/v1")\n',
            "main intelligence router registration",
        )
    return source


def patch_ai_assistant(source: str) -> str:
    import_anchor = "from ..dependencies import require_permission\n"
    imports = (
        "from ..dependencies import require_permission\n"
        "from ..intelligence.contracts import DataSensitivity, RoutingRequest, TaskType\n"
        "from ..intelligence.policy import PAID_PROVIDER_IDS, configured_provider_ids, plan_route, policy_from_settings\n"
    )
    if "from ..intelligence.policy import PAID_PROVIDER_IDS, configured_provider_ids, plan_route, policy_from_settings" not in source:
        source = replace_once(source, import_anchor, imports, "AI router policy import")

    start = source.find("def provider_status() -> list[dict[str, str | bool]]:")
    end = source.find("\n\ndef _system_instruction", start)
    if start < 0 or end < 0:
        raise InstallError("Could not identify provider_status() section in ai_assistant.py; no further edits were written.")
    new_block = '''def provider_status() -> list[dict[str, str | bool]]:\n    \"\"\"Return client-safe provider state without revealing keys or bypassing policy.\"\"\"\n    policy = policy_from_settings(settings)\n    allowed_ids = {item.value for item in policy.allowed_providers}\n    return [\n        {\n            \"id\": spec.provider_id,\n            \"label\": spec.label,\n            \"tier\": spec.tier,\n            \"model\": _model_for(spec),\n            \"configured\": bool(_api_key_for(spec)),\n            \"eligible_for_future_router\": bool(\n                policy.external_providers_enabled\n                and spec.provider_id in allowed_ids\n                and _api_key_for(spec)\n                and (spec.provider_id not in {item.value for item in PAID_PROVIDER_IDS}\n                     or policy.paid_providers_enabled)\n            ),\n            # Phase 1 adds policy contracts, not a provider execution path.\n            \"enabled\": False,\n        }\n        for spec in PROVIDERS\n    ]'''
    source = source[:start] + new_block + source[end:]

    list_start = source.find('@router.get("/providers")')
    list_end = source.find('\n\n@router.post("/assist"', list_start)
    if list_start < 0 or list_end < 0:
        raise InstallError("Could not identify /ai/providers route; no further edits were written.")
    new_list_route = '''@router.get("/providers")\ndef list_ai_providers(ctx=Depends(require_permission("analytics.read"))):\n    statuses = provider_status()\n    policy = policy_from_settings(settings)\n    return {\n        "enabled": False,
        "execution_available": False,\n        "external_providers_enabled": policy.external_providers_enabled,\n        "paid_provider_opt_in": policy.paid_providers_enabled,\n        "providers": statuses,\n        "maximum_prompt_characters": 8_000,\n    }'''
    source = source[:list_start] + new_list_route + source[list_end:]

    assist_anchor = "    db, user_id, tenant_id, _session_id = ctx\n    spec = PROVIDER_MAP[body.provider]\n"
    gate = '''    db, user_id, tenant_id, _session_id = ctx\n    # Every API-exposed provider call passes through the central policy. Treat an\n    # arbitrary user prompt as confidential business data; Phase 1 defaults block\n    # external transfer before summary reads, rate-limit work, or network I/O.\n    route_decision = plan_route(\n        RoutingRequest(\n            task=TaskType.EXPLAIN,\n            sensitivity=DataSensitivity.CONFIDENTIAL_BUSINESS,\n            provider_preference=body.provider,\n            input_safety_checked=False,\n            purpose_code="legacy_ai_assistant",\n        ),\n        policy=policy_from_settings(settings),\n        configured_providers=configured_provider_ids({\n            spec.key_env: _api_key_for(spec) for spec in PROVIDERS\n        }),\n    )\n    if not route_decision.allowed:\n        raise HTTPException(\n            status_code=503,\n            detail={\n                "code": "AI_POLICY_BLOCKED",\n                "message": "External AI is disabled or this request is not approved by LEXA's AI policy.",\n                "reason_code": route_decision.reason_code,\n            },\n        )\n    spec = PROVIDER_MAP[body.provider]\n'''
    if "route_decision = plan_route(" not in source:
        source = replace_once(source, assist_anchor, gate, "assistant policy gate")
    return source


def patch_replay_manifest(source: str) -> str:
    import json

    data = json.loads(source)
    steps = data.get("steps")
    if not isinstance(steps, list):
        raise InstallError("Clean replay manifest has no steps array; refusing to edit it.")
    migration_path = "migrations/045_intelligence_foundation.sql"
    if any(step.get("path") == migration_path for step in steps):
        return source
    steps.append({"path": migration_path, "mode": "additive-phase1-candidate"})
    purpose = str(data.get("purpose", ""))
    if "intelligence foundation candidate (045)" not in purpose:
        data["purpose"] = purpose.rstrip(". ") + "; includes the additive Phase 1 intelligence foundation candidate (045)."
    status = str(data.get("status", ""))
    data["status"] = status.replace(
        "SEMANTIC_REPLAY_PENDING_THROUGH_044_PASSWORD_RESET_SECURITY",
        "SEMANTIC_REPLAY_PENDING_THROUGH_045_INTELLIGENCE_FOUNDATION",
    )
    return json.dumps(data, indent=2) + "\n"


def patch_replay_runner(source: str) -> str:
    if "intelligence_foundation" in source and "intelligence_tables" in source:
        return source
    source = replace_once(
        source,
        "'044_phase3_password_reset_security')",
        "'044_phase3_password_reset_security','045_intelligence_foundation')",
        "clean-replay required migration query",
    )
    source = replace_once(
        source,
        "'043_phase5_journal_currency_guard','044_phase3_password_reset_security',\n                ])",
        "'043_phase5_journal_currency_guard','044_phase3_password_reset_security',\n                    '045_intelligence_foundation',\n                ])",
        "clean-replay expected migration list",
    )
    anchor = "                (journal_entry_currency_guard, journal_posting_grant) = cur.fetchone()\n"
    added_check = '''                (journal_entry_currency_guard, journal_posting_grant) = cur.fetchone()
                cur.execute("""
                    SELECT
                      count(*) FILTER (WHERE c.relname IN ('intelligence_jobs','intelligence_runs')),
                      count(*) FILTER (WHERE c.relname IN ('intelligence_jobs','intelligence_runs') AND c.relrowsecurity AND c.relforcerowsecurity),
                      count(*) FILTER (WHERE c.relname IN ('intelligence_jobs','intelligence_runs') AND EXISTS (
                        SELECT 1 FROM pg_policies p WHERE p.schemaname='public' AND p.tablename=c.relname
                          AND p.policyname = c.relname || '_tenant_branch_scope'
                      )),
                      has_table_privilege('lexa_app','public.intelligence_jobs','SELECT'),
                      has_table_privilege('lexa_app','public.intelligence_jobs','INSERT'),
                      has_table_privilege('lexa_app','public.intelligence_runs','SELECT'),
                      has_table_privilege('lexa_app','public.intelligence_runs','INSERT'),
                      has_table_privilege('lexa_app','public.intelligence_runs','UPDATE')
                    FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace
                    WHERE n.nspname='public' AND c.relkind='r'
                """)
                (intelligence_tables, intelligence_rls_forced, intelligence_policy_count,
                 intelligence_jobs_select, intelligence_jobs_insert,
                 intelligence_runs_select, intelligence_runs_insert,
                 intelligence_runs_update) = cur.fetchone()
'''
    source = replace_once(source, anchor, added_check, "clean-replay intelligence schema assertion")
    source = replace_once(
        source,
        '        if not journal_posting_grant: failures.append("Runtime role lacks the approved execute grant for journal posting")\n',
        '        if not journal_posting_grant: failures.append("Runtime role lacks the approved execute grant for journal posting")\n'
        '        if intelligence_tables != 2 or intelligence_rls_forced != 2 or intelligence_policy_count != 2:\n'
        '            failures.append(f"Phase 1 intelligence tables must both exist with forced RLS and tenant-branch policies: tables={intelligence_tables}/2, forced={intelligence_rls_forced}/2, policies={intelligence_policy_count}/2")\n'
        '        if not all((intelligence_jobs_select, intelligence_jobs_insert, intelligence_runs_select, intelligence_runs_insert)):\n'
        '            failures.append("Phase 1 intelligence job/run table grants are incomplete")\n        if intelligence_runs_update:\n            failures.append("Phase 1 intelligence run provenance is mutable by the runtime role")\n',
        "clean-replay intelligence schema failures",
    )
    source = replace_once(
        source,
        '            "journal_posting_grant": bool(journal_posting_grant),\n',
        '            "journal_posting_grant": bool(journal_posting_grant),\n'
        '            "phase1_intelligence_tables": intelligence_tables,\n'
        '            "phase1_intelligence_rls_forced": intelligence_rls_forced,\n'
        '            "phase1_intelligence_tenant_branch_policies": intelligence_policy_count,\n'
        '            "phase1_intelligence_jobs_select_grant": bool(intelligence_jobs_select),\n'
        '            "phase1_intelligence_jobs_insert_grant": bool(intelligence_jobs_insert),\n'
        '            "phase1_intelligence_runs_select_grant": bool(intelligence_runs_select),\n'
        '            "phase1_intelligence_runs_insert_grant": bool(intelligence_runs_insert),\n            "phase1_intelligence_runs_update_grant": bool(intelligence_runs_update),\n',
        "clean-replay intelligence evidence fields",
    )
    return source


def install(repo_root: Path) -> list[Path]:
    repo_root = repo_root.resolve()
    if not (repo_root / "apps/api/app/main.py").is_file():
        raise InstallError(f"{repo_root} does not look like the LEXA repository (missing apps/api/app/main.py).")

    for relative in COPY_PATHS:
        source = BUNDLE_ROOT / relative
        destination = repo_root / relative
        if not source.is_file():
            raise InstallError(f"Bundle is incomplete: missing {source}")
        if destination.exists() and destination.read_bytes() != source.read_bytes():
            raise InstallError(f"Refusing to overwrite existing file: {destination}")

    edits = {
        Path("apps/api/app/config.py"): patch_config,
        Path("apps/api/app/main.py"): patch_main,
        Path("apps/api/app/routes/ai_assistant.py"): patch_ai_assistant,
        Path("scripts/run_clean_migration_replay.py"): patch_replay_runner,
    }
    planned: dict[Path, str] = {}
    for relative, patcher in edits.items():
        destination = repo_root / relative
        if not destination.is_file():
            raise InstallError(f"Expected existing LEXA file is missing: {destination}")
        current = destination.read_text(encoding="utf-8")
        updated = patcher(current)
        planned[relative] = updated

    manifest_path = repo_root / "migrations/reconstructed/clean_replay_order.json"
    if not manifest_path.is_file():
        raise InstallError(f"Expected replay manifest is missing: {manifest_path}")
    manifest_content = manifest_path.read_text(encoding="utf-8")
    planned[Path("migrations/reconstructed/clean_replay_order.json")] = patch_replay_manifest(manifest_content)

    # All anchors are validated before any write, preventing a partially patched checkout
    # if the target source has diverged from the inspected revision.
    changed: list[Path] = []
    for relative, updated in planned.items():
        destination = repo_root / relative
        current = destination.read_text(encoding="utf-8")
        if current != updated:
            backup = destination.with_suffix(destination.suffix + ".phase1.bak")
            if backup.exists():
                raise InstallError(f"Refusing to overwrite existing backup: {backup}")
            shutil.copy2(destination, backup)
            destination.write_text(updated, encoding="utf-8")
            changed.append(destination)

    for relative in COPY_PATHS:
        source = BUNDLE_ROOT / relative
        destination = repo_root / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        if not destination.exists():
            shutil.copy2(source, destination)
            changed.append(destination)

    return changed


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo-root", type=Path, required=True, help="Path to a local LEXA checkout")
    args = parser.parse_args()
    try:
        changed = install(args.repo_root)
    except InstallError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2
    if changed:
        print("Phase 1 files installed; review this diff before committing:")
        for path in changed:
            print(f"  {path}")
    else:
        print("Phase 1 overlay is already installed; no files changed.")
    print("No database migration, provider enablement, network action, or deployment was performed.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
