"""Read-only capability discovery for the Phase 1 intelligence foundation."""
from __future__ import annotations

from fastapi import APIRouter, Depends

from ..config import settings
from ..dependencies import require_permission
from . import CONTRACT_VERSION, POLICY_VERSION
from .policy import configured_provider_ids, policy_from_settings

router = APIRouter(prefix="/intelligence", tags=["intelligence"])


@router.get("/capabilities")
def intelligence_capabilities(ctx=Depends(require_permission("analytics.read"))):
    """Describe capabilities and gates without returning secrets or business data."""
    del ctx  # Authentication/permission dependency is the access-control boundary.
    policy = policy_from_settings(settings)
    configured = configured_provider_ids()
    from .policy import PAID_PROVIDER_IDS

    eligible = sorted(
        provider.value
        for provider in configured.intersection(policy.allowed_providers)
        if policy.external_providers_enabled
        and policy.confidential_external_enabled
        and (provider not in PAID_PROVIDER_IDS or policy.paid_providers_enabled)
    )
    return {
        "contract_version": CONTRACT_VERSION,
        "policy_version": POLICY_VERSION,
        "phase": "phase1_foundation",
        "capabilities": {
            "deterministic_business_insights": True,
            "deterministic_replenishment_calculations": True,
            "python_forecasting": False,
            "document_extraction": False,
            "cross_module_daily_brief": False,
            "business_writes_from_intelligence": False,
        },
        "external_ai": {
            # Phase 1 intentionally has no trusted input-screening/execution path.
            "enabled": False,
            "execution_available": False,
            "eligible_provider_ids_for_a_later_phase": eligible,
            "paid_provider_opt_in": policy.paid_providers_enabled,
            "aggregated_business_data_approved": policy.aggregate_external_enabled,
            "confidential_business_data_approved": policy.confidential_external_enabled,
            "personal_data_external_allowed": False,
            "automatic_fallbacks": False,
        },
        "durable_job_schema_version": "045_intelligence_foundation",
        "durable_job_execution_enabled": False,
        "write_capabilities": [],
    }
