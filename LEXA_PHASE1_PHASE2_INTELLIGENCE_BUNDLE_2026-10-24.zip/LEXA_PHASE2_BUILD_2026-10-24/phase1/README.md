# LEXA Phase 1 — Intelligence Foundation

This is a local implementation bundle for `MONALISA2003-CMD/LEXA-`, built against the inspected `main` source revision `4e40dcc1b18e6ddfdae5a7fa7e183dca52de6896`.

## Included

- Shared, strict Pydantic contracts for tenant scope, evidence-backed insights, source references, actions, events and routing decisions.
- LEXA-owned AI policy routing: task profiles, sensitivity rules, an explicit provider allowlist, separate paid-provider opt-in, and no automatic fallbacks.
- Read-only `GET /api/v1/intelligence/capabilities`, guarded by the existing `analytics.read` permission.
- A default-deny policy gate on the legacy `/api/v1/ai/assist` endpoint. Phase 1 has no live external model execution path; arbitrary user prompts are blocked because trusted classification/redaction is not yet implemented.
- Forward-only SQL candidate `045_intelligence_foundation.sql`, with tenant/branch RLS, narrowly allow-listed reference metadata, idempotent jobs, append-only run provenance and restricted privileges.
- Additions to the disposable clean-replay manifest/runner, focused synthetic tests and an anchored local installer.

## Install into a local checkout

```bash
python /path/to/LEXA_PHASE1_IMPLEMENTATION/scripts/apply_phase1.py --repo-root /path/to/LEXA-
```

The installer has no network or cloud API code. It validates source anchors before writing, refuses conflicting existing files, makes `.phase1.bak` backups of existing files it edits, and is idempotent. Review the full diff before committing. It does not apply migrations, modify `.env`, enable providers, or deploy anything.

## Tests

```bash
cd /path/to/LEXA_PHASE1_IMPLEMENTATION/apps/api
PYTHONPATH=. pytest -q tests/test_intelligence_phase1.py
```

Validation completed for this bundle: **20 synthetic tests passed**; installer mock test passed (13 initial paths changed, second install a no-op); generated Python source parsed. These checks did not connect to PostgreSQL, run SQL, access live business data, or exercise the full upstream CI suite.

## Operational boundary

- All new provider settings default to disabled/empty.
- Provider configuration status is not execution availability. Both provider and capability endpoints state that Phase 1 execution is unavailable.
- Do not switch on external AI in Phase 1.
- SQL 045 is a candidate. It has not been applied and must be reviewed and tested through LEXA's disposable migration replay before any separate release decision.
- No Render, Neon, Vercel, GitHub Actions, secrets, roles, production records or deployments were changed.

## Upstream status

The connected GitHub integration denied branch creation with `403 Resource not accessible by integration`, so this bundle has **not** been committed to GitHub or opened as a pull request. The installer enables applying the changes to a local checkout for review, followed by commit/PR through an authorized route.
