# LEXA Intelligence Phase 1 + Phase 2 — Validation Results

**Date:** 24 October 2026  
**Scope:** Bundled synthetic tests and installer tests only. No production calls.

## Passed

| Suite | Result | What it covers |
|---|---:|---|
| Phase 1 contracts and policy | 20 passed | Router policy defaults, data sensitivity, event/contract shape, no execution by default |
| Phase 2 daily-brief rules | 9 passed | Deterministic priority, stale/unavailable quarantine, currency guard, duplicate identifiers, relative-only evidence links, no business writes |
| Combined installer | 6 passed | Analytics-service extraction, fail-closed anchors, capability flags, typed web API helper, page wiring, staging/backups/idempotence |
| **Total** | **35 passed** | Synthetic fixtures and bundled code only |

Additional Python compilation checks passed for the two installers and core Python modules.

## Not yet verified

- The combined installer has not been applied to a real LEXA checkout in this runtime; installer tests use a synthetic checkout.
- The full existing API suite and the repository CI pipeline have not been run on the installed combined source.
- The generated `app/intelligence/insight_service.py` has not been built from a filesystem checkout of the actual `main` `analytics.py` inside this runtime. The installer contains strict source anchors and a synthetic extraction test; real-checkout review is still required.
- The updated Next.js/TypeScript files have not been checked by the repository's Node 24 typecheck/test/build pipeline, and no browser/mobile visual review was performed.
- Migration `045_intelligence_foundation.sql` has not been run against PostgreSQL, even a disposable instance. Forced RLS and grants remain unverified at database runtime.
- No authenticated staging end-to-end test has been run.
- No production database, production secret, environment setting, deployment, or provider execution was changed or activated.

## Commands used

The bundled Phase 1 + Phase 2 tests were copied to a temporary test workspace so the Phase 1 `app` package could be imported, then executed with `PYTHONPATH=apps/api`. Installer tests were run directly from `scripts/test_phase2_installer.py`.
