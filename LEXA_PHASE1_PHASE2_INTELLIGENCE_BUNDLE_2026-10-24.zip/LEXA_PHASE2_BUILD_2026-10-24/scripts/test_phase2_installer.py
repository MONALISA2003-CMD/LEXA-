"""Synthetic tests for the Phase 2 source refactor installer; no LEXA DB is used."""
from __future__ import annotations

import importlib.util
import sys
from pathlib import Path

SCRIPT = Path(__file__).resolve().parent / "apply_intelligence_phases.py"
spec = importlib.util.spec_from_file_location("lexa_phase2_installer_tested", SCRIPT)
module = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = module
assert spec.loader is not None
spec.loader.exec_module(module)


def test_extract_insight_service_moves_canonical_body_and_generates_thin_route():
    source = '''from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy import text
from ..dependencies import require_permission
from ..business_insights import build_balance_insight, build_margin_insight, build_sales_movement_insight, build_stock_risk_insight
router = APIRouter(prefix="/analytics")
@router.get("/insights")
def business_insights(
    start_date: date,
    end_date: date,
    currency_code: str = Query(..., min_length=3, max_length=3),
    focus: Literal["all", "sales", "margin", "stock", "balances"] = Query(default="all"),
    ctx=Depends(require_permission("analytics.read")),
):
    """Return bounded deterministic insights with explicit freshness and source evidence.

    The endpoint is read-only.
    """
    db, actor_id, tenant_id, _ = ctx
    if start_date > end_date:
        raise HTTPException(status_code=422, detail="bad period")
    first = build_balance_insight(as_of_date=date.today(),)
    second = build_stock_risk_insight(as_of_date=date.today(),)
    chosen = [first, second] if focus == "all" else [first]
    return {"insights": chosen, "period": {"from_date": start_date.isoformat(), "to_date": end_date.isoformat()}}

@router.post("/refresh")
def refresh():
    return {"ok": True}
'''
    service, updated = module.extract_insight_service(source)
    compile(service, "insight_service.py", "exec")
    compile(updated, "analytics.py", "exec")
    assert "def calculate_business_insights(" in service
    assert "as_of_date=(as_of_date_override or date.today())" in service
    assert "from ..intelligence.insight_service import calculate_business_insights" in updated
    assert 'return calculate_business_insights(' in updated
    assert "db, actor_id, tenant_id, _ = ctx" in updated
    assert "def refresh():" in updated


def test_refactor_fails_closed_if_insight_anchor_is_ambiguous():
    source = '@router.get("/insights")\ndef business_insights(): pass\n@router.get("/insights")\ndef business_insights(): pass\n@router.post("/refresh")'
    try:
        module.extract_insight_service(source)
    except module.InstallError as exc:
        assert "uniquely locate" in str(exc)
    else:
        raise AssertionError("ambiguous analytics source must be rejected")


def test_route_capability_patch_marks_daily_brief_as_deterministic():
    source = '''from __future__ import annotations
from fastapi import APIRouter, Depends
from ..config import settings
from ..dependencies import require_permission
from . import CONTRACT_VERSION, POLICY_VERSION
from .policy import configured_provider_ids, policy_from_settings
router = APIRouter(prefix="/intelligence")
def intelligence_capabilities():
    return {
        "phase": "phase1_foundation",
        "capabilities": {
            "deterministic_business_insights": True,
            "deterministic_replenishment_calculations": True,
            "python_forecasting": False,
            "document_extraction": False,
            "cross_module_daily_brief": False,
            "business_writes_from_intelligence": False,
        },
        "durable_job_execution_enabled": False,
    }
'''
    updated = module.patch_intelligence_routes(source)
    assert '"phase": "phase2_rules_first"' in updated
    assert '"cross_module_daily_brief": True' in updated
    assert "def intelligence_daily_brief(" in updated
    assert "public.lexa_business_date(now(), CAST(:tenant_id AS uuid))" in updated
    assert '"durable_job_execution_enabled": False,\n        "daily_brief_api_enabled": True,' in updated



def test_web_api_adds_typed_daily_brief_client_and_is_idempotent():
    source = "export function getHealth() { return getJson('/health'); }\n"
    updated = module.patch_web_api(source)
    assert "export type DailyBrief =" in updated
    assert "export function getDailyBrief(currencyCode: string)" in updated
    assert "getJson<DailyBrief>(`/api/v1/intelligence/daily-brief?currency_code=" in updated
    assert module.patch_web_api(updated) == updated


def test_web_page_renders_daily_brief_and_fetches_it_with_workspace_currency():
    source = '''"use client";
import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import { AppShell } from "../../components/app-shell";
import {
  getAnalyticsOverview,
  getBusinessInsights,
  getBusinessProfile,
  type BusinessInsightsResponse,
  type BusinessProfile,
  userFacingError,
} from "../../lib/api";
function formatMoney(value, currency) { return String(value); }
function safeError(reason) { return String(reason); }
export default function IntelligencePage() {
  const [profile, setProfile] = useState<BusinessProfile | null>(null);
  const [overview, setOverview] = useState(null);
  const [businessInsights, setBusinessInsights] = useState<BusinessInsightsResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [errors, setErrors] = useState<string[]>([]);
  const load = useCallback(async () => {
    const issues: string[] = [];
    const currentProfile = profile;
    if (currentProfile?.currency_code && /^[A-Z]{3}$/.test(currentProfile.currency_code)) {
      const fromDate = "2026-10-01";
      const toDate = "2026-10-24";
      const [overviewResult, insightsResult] = await Promise.allSettled([
        getAnalyticsOverview(fromDate, toDate, currentProfile.currency_code),
        getBusinessInsights(fromDate, toDate, currentProfile.currency_code),
      ]);
      if (overviewResult.status === "fulfilled") setOverview(overviewResult.value);
      if (insightsResult.status === "fulfilled") setBusinessInsights(insightsResult.value);
      else { setBusinessInsights(null); issues.push(`Business insights: ${safeError(insightsResult.reason)}`); }
    } else {
      setOverview(null);
      setBusinessInsights(null);
      issues.push("Add your business currency in Settings to see money values correctly.");
    }
    setErrors(issues);
    setLoading(false);
  }, [profile]);
  return <AppShell title="Business insights"><main className="workspace">
      <section className="workspace-section">
        <div className="section-head"><div><span className="section-label">EXPLAINABLE · READ-ONLY</span><h2>What may need your attention?</h2><p>These checks use saved data.</p></div><Link href="/reports" className="button button-soft">Open reports</Link></div>
        {businessInsights && <p>Business insight data</p>}
      </section>
    </main></AppShell>;
}
'''
    updated = module.patch_web_page(source)
    assert "getDailyBrief," in updated
    assert "type DailyBrief," in updated
    assert "const [dailyBrief, setDailyBrief] = useState<DailyBrief | null>(null);" in updated
    assert "getDailyBrief(currentProfile.currency_code)" in updated
    assert "Your business daily brief" in updated
    assert "dailyBrief.data_quality" in updated
    assert module.patch_web_page(updated) == updated

def _write_fixture(repo: Path, relative: str, content: str) -> None:
    target = repo / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(content, encoding="utf-8")


def _make_synthetic_checkout(repo: Path) -> None:
    _write_fixture(repo, "apps/api/app/config.py", '''from pydantic_settings import SettingsConfigDict
class Settings:
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")
''')
    _write_fixture(repo, "apps/api/app/main.py", '''from .kernel import router as kernel_router
app.include_router(ai_assistant.router, prefix="/api/v1")
''')
    _write_fixture(repo, "apps/api/app/routes/ai_assistant.py", '''from fastapi import APIRouter, Depends, HTTPException
from ..dependencies import require_permission
router = APIRouter(prefix="/ai")
PROVIDERS = ()
PROVIDER_MAP = {}
def _model_for(spec): return "synthetic"
def _api_key_for(spec): return ""
def provider_status() -> list[dict[str, str | bool]]:
    return [{"id": "synthetic"}]


def _system_instruction(area): return "read-only"
@router.get("/providers")
def list_ai_providers(ctx=Depends(require_permission("analytics.read"))):
    return {"enabled": True}


@router.post("/assist")
async def assist(body, ctx=Depends(require_permission("analytics.read"))):
    db, user_id, tenant_id, _session_id = ctx
    spec = PROVIDER_MAP[body.provider]
    return {"ok": True}
''')
    _write_fixture(repo, "apps/api/app/routes/analytics.py", '''from datetime import date, datetime, timedelta, timezone
from decimal import Decimal
from typing import Any, Literal
import re
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy import text
from ..dependencies import require_permission
from ..branch_access import require_full_branch_scope
from ..business_insights import build_balance_insight, build_margin_insight, build_sales_movement_insight, build_stock_risk_insight
router = APIRouter(prefix="/analytics")
@router.get("/insights")
def business_insights(
    start_date: date,
    end_date: date,
    currency_code: str = Query(..., min_length=3, max_length=3),
    focus: Literal["all", "sales", "margin", "stock", "balances"] = Query(default="all"),
    ctx=Depends(require_permission("analytics.read")),
):
    """Return bounded deterministic insights with explicit freshness and source evidence.
    The endpoint is read-only and evidence-backed.
    """
    db, actor_id, tenant_id, _ = ctx
    if start_date > end_date:
        raise HTTPException(status_code=422, detail="invalid period")
    daily_is_fresh = True
    current_daily = {}
    previous_daily = {}
    current_products = {}
    previous_products = {}
    last_refresh_at = None
    receivables_summary = {}
    supplier_ledger_summary = {}
    stock_latest = None
    stock_summary = None
    stock_examples = []
    built_balance = build_balance_insight(as_of_date=date.today(),)
    built_stock = build_stock_risk_insight(as_of_date=date.today(),)
    all_insights = [built_balance, built_stock]
    chosen = all_insights if focus == "all" else all_insights
    return {"rule_version": "test", "insights": chosen, "period": {"from_date": start_date.isoformat(), "to_date": end_date.isoformat()}, "comparison_period": {}, "last_successful_refresh_at": None}

@router.post("/refresh")
def refresh():
    return {"ok": True}
''')
    # The Phase 1 installer only edits this file through exact, reviewed anchors.
    _write_fixture(repo, "apps/web/lib/api.ts", "export function getJson<T>(path: string): Promise<T> { throw new Error(path); }\n")
    _write_fixture(repo, "apps/web/app/intelligence/page.tsx", '''"use client";
import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import { AppShell } from "../../components/app-shell";
import {
  getAnalyticsOverview,
  getBusinessInsights,
  getBusinessProfile,
  type BusinessInsightsResponse,
  type BusinessProfile,
  userFacingError,
} from "../../lib/api";
function formatMoney(value, currency) { return String(value); }
function safeError(reason) { return String(reason); }
export default function IntelligencePage() {
  const [profile, setProfile] = useState<BusinessProfile | null>(null);
  const [overview, setOverview] = useState(null);
  const [businessInsights, setBusinessInsights] = useState<BusinessInsightsResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [errors, setErrors] = useState<string[]>([]);
  const load = useCallback(async () => {
    const issues: string[] = [];
    const currentProfile = profile;
    if (currentProfile?.currency_code && /^[A-Z]{3}$/.test(currentProfile.currency_code)) {
      const fromDate = "2026-10-01";
      const toDate = "2026-10-24";
      const [overviewResult, insightsResult] = await Promise.allSettled([
        getAnalyticsOverview(fromDate, toDate, currentProfile.currency_code),
        getBusinessInsights(fromDate, toDate, currentProfile.currency_code),
      ]);
      if (overviewResult.status === "fulfilled") setOverview(overviewResult.value);
      if (insightsResult.status === "fulfilled") setBusinessInsights(insightsResult.value);
      else { setBusinessInsights(null); issues.push(`Business insights: ${safeError(insightsResult.reason)}`); }
    } else {
      setOverview(null);
      setBusinessInsights(null);
      issues.push("Add your business currency in Settings to see money values correctly.");
    }
    setErrors(issues);
    setLoading(false);
  }, [profile]);
  return <AppShell title="Business insights"><main className="workspace">
      <section className="workspace-section">
        <div className="section-head"><div><span className="section-label">EXPLAINABLE · READ-ONLY</span><h2>What may need your attention?</h2><p>These checks use saved data.</p></div><Link href="/reports" className="button button-soft">Open reports</Link></div>
        {businessInsights && <p>Business insight data</p>}
      </section>
    </main></AppShell>;
}
''')
    _write_fixture(repo, "scripts/run_clean_migration_replay.py", '''# synthetic migration replay contract
'044_phase3_password_reset_security')
'043_phase5_journal_currency_guard','044_phase3_password_reset_security',
                ])
                (journal_entry_currency_guard, journal_posting_grant) = cur.fetchone()
        if not journal_posting_grant: failures.append("Runtime role lacks the approved execute grant for journal posting")
            "journal_posting_grant": bool(journal_posting_grant),
''')
    _write_fixture(repo, "migrations/reconstructed/clean_replay_order.json", '''{
  "schema_version": 1,
  "purpose": "Synthetic disposable replay fixture",
  "status": "SEMANTIC_REPLAY_PENDING_THROUGH_044_PASSWORD_RESET_SECURITY",
  "steps": [{"path": "migrations/001.sql", "mode": "fixture"}]
}
''')


def test_combined_installer_is_staged_backed_up_and_idempotent(tmp_path):
    _make_synthetic_checkout(tmp_path)
    first = module.install(tmp_path)
    assert first
    assert (tmp_path / "apps/api/app/intelligence/daily_brief.py").exists()
    assert (tmp_path / "apps/api/app/intelligence/insight_service.py").exists()
    assert (tmp_path / "apps/api/tests/test_intelligence_phase2.py").exists()
    assert "def calculate_business_insights(" in (tmp_path / "apps/api/app/intelligence/insight_service.py").read_text()
    assert "def intelligence_daily_brief(" in (tmp_path / "apps/api/app/intelligence/routes.py").read_text()
    assert (tmp_path / "apps/api/app/config.py.phase1.bak").exists()
    assert (tmp_path / "apps/api/app/routes/analytics.py.phase2.bak").exists()
    assert module.install(tmp_path) == []
