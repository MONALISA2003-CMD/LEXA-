#!/usr/bin/env python3
"""Stage and install the LEXA Phase 1 overlay plus Phase 2 daily-brief increment.

The installer is local-only and network-free. It performs Phase 1 and Phase 2
transformations in a disposable staging tree, validates every source anchor first,
then applies the result with backups. It does not apply SQL, enable providers,
change environment values, contact infrastructure, or deploy.
"""
from __future__ import annotations

import argparse
import importlib.util
import shutil
import sys
import tempfile
from pathlib import Path

BUNDLE_ROOT = Path(__file__).resolve().parents[1]
PHASE1_ROOT = BUNDLE_ROOT / "phase1"
PHASE2_ROOT = BUNDLE_ROOT / "phase2"
BASE_PATHS = (
    Path("apps/api/app/config.py"),
    Path("apps/api/app/main.py"),
    Path("apps/api/app/routes/ai_assistant.py"),
    Path("apps/api/app/routes/analytics.py"),
    Path("scripts/run_clean_migration_replay.py"),
    Path("migrations/reconstructed/clean_replay_order.json"),
    Path("apps/web/lib/api.ts"),
    Path("apps/web/app/intelligence/page.tsx"),
)
PHASE2_COPY_PATHS = (
    Path("apps/api/app/intelligence/daily_brief.py"),
    Path("apps/api/tests/test_intelligence_phase2.py"),
    Path("docs/LEXA_INTELLIGENCE_PHASE2_IMPLEMENTATION.md"),
)


class InstallError(RuntimeError):
    pass


def _load_phase1_installer():
    path = PHASE1_ROOT / "scripts/apply_phase1.py"
    spec = importlib.util.spec_from_file_location("lexa_phase1_installer", path)
    if spec is None or spec.loader is None:
        raise InstallError("Could not load the bundled Phase 1 installer")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def replace_once(source: str, old: str, new: str, label: str) -> str:
    count = source.count(old)
    if count != 1:
        raise InstallError(f"Expected exactly one {label} anchor; found {count}. No source files were changed.")
    return source.replace(old, new, 1)


def extract_insight_service(analytics_source: str) -> tuple[str, str]:
    """Extract the canonical analytics insight body into a reusable service.

    The exact existing body is moved rather than copied into a second query path.
    This avoids duplicate SQL definitions for sales, margin, stock and balances.
    """
    start_marker = '@router.get("/insights")\ndef business_insights('
    end_marker = '\n@router.post("/refresh")'
    if analytics_source.count(start_marker) != 1 or analytics_source.count(end_marker) != 1:
        raise InstallError("Could not uniquely locate the canonical analytics insight handler; refusing to refactor it.")
    start = analytics_source.index(start_marker)
    end = analytics_source.index(end_marker, start)
    block = analytics_source[start:end]
    body_marker = '    """Return bounded deterministic insights with explicit freshness and source evidence.'
    if block.count(body_marker) != 1:
        raise InstallError("Analytics insight handler signature/docstring differs from the inspected source.")
    body = block[block.index(body_marker):]
    assignment = '    db, actor_id, tenant_id, _ = ctx\n'
    if body.count(assignment) != 1:
        raise InstallError("Expected one request-context assignment in analytics insight handler.")
    body = body.replace(assignment, "", 1)

    # Use tenant-local business date for the new brief when supplied, while keeping
    # the old analytics endpoint's date behavior unchanged through the default None.
    freshness_date = 'as_of_date=date.today(),'
    if body.count(freshness_date) != 2:
        raise InstallError("Expected exactly two date anchors for balance/stock freshness calculations.")
    body = body.replace(freshness_date, 'as_of_date=(as_of_date_override or date.today()),')

    service = '''"""Canonical deterministic analytics insight calculator, shared by API routes."""
from __future__ import annotations

import re
from datetime import date, datetime, timedelta, timezone
from decimal import Decimal
from typing import Any, Literal

from fastapi import HTTPException
from sqlalchemy import text

from ..branch_access import require_full_branch_scope
from ..business_insights import (
    build_balance_insight,
    build_margin_insight,
    build_sales_movement_insight,
    build_stock_risk_insight,
)


def calculate_business_insights(
    *,
    db: Any,
    actor_id: Any,
    tenant_id: Any,
    start_date: date,
    end_date: date,
    currency_code: str,
    focus: Literal["all", "sales", "margin", "stock", "balances"] = "all",
    as_of_date_override: date | None = None,
) -> dict[str, Any]:
'''
    service += body.rstrip() + "\n"

    route = '''@router.get("/insights")
def business_insights(
    start_date: date,
    end_date: date,
    currency_code: str = Query(..., min_length=3, max_length=3),
    focus: Literal["all", "sales", "margin", "stock", "balances"] = Query(default="all"),
    ctx=Depends(require_permission("analytics.read")),
):
    db, actor_id, tenant_id, _ = ctx
    return calculate_business_insights(
        db=db,
        actor_id=actor_id,
        tenant_id=tenant_id,
        start_date=start_date,
        end_date=end_date,
        currency_code=currency_code,
        focus=focus,
    )
'''
    updated = analytics_source[:start] + route + analytics_source[end:]
    import_anchor = 'from ..business_insights import build_balance_insight, build_margin_insight, build_sales_movement_insight, build_stock_risk_insight\n'
    updated = replace_once(
        updated,
        import_anchor,
        'from ..intelligence.insight_service import calculate_business_insights\n',
        "analytics shared insight-service import",
    )
    return service, updated


def patch_intelligence_routes(source: str) -> str:
    if "def intelligence_daily_brief(" in source:
        if all(marker in source for marker in (
            '"phase": "phase2_rules_first"',
            '"daily_brief_api_enabled": True',
            'from .insight_service import calculate_business_insights',
        )):
            return source
        raise InstallError("A partial/conflicting daily-brief route already exists; refusing to patch it.")
    import_anchor = "from fastapi import APIRouter, Depends\n"
    imports = '''from datetime import date, timedelta
import re

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy import text
'''
    source = replace_once(source, import_anchor, imports, "intelligence route imports")
    service_anchor = "from .policy import configured_provider_ids, policy_from_settings\n"
    service_imports = '''from .policy import configured_provider_ids, policy_from_settings
from .daily_brief import build_daily_brief
from .insight_service import calculate_business_insights
'''
    source = replace_once(source, service_anchor, service_imports, "daily brief service imports")
    old_capabilities = '''        "phase": "phase1_foundation",
        "capabilities": {
            "deterministic_business_insights": True,
            "deterministic_replenishment_calculations": True,
            "python_forecasting": False,
            "document_extraction": False,
            "cross_module_daily_brief": False,
            "business_writes_from_intelligence": False,
        },'''
    new_capabilities = '''        "phase": "phase2_rules_first",
        "capabilities": {
            "deterministic_business_insights": True,
            "deterministic_replenishment_calculations": True,
            "cross_module_daily_brief": True,
            "daily_brief_mode": "deterministic_rules_only",
            "python_forecasting": False,
            "document_extraction": False,
            "business_writes_from_intelligence": False,
        },'''
    source = replace_once(source, old_capabilities, new_capabilities, "phase 2 capability advertisement")
    route = '''

@router.get("/daily-brief")
def intelligence_daily_brief(
    currency_code: str = Query(default="UGX", min_length=3, max_length=3),
    ctx=Depends(require_permission("analytics.read")),
):
    """Return a deterministic seven-day business brief for the active tenant.

    Tenant and user IDs are derived only from the validated server context. The
    source calculator enforces full branch scope before producing tenant-wide
    analytics. The route performs reads only and never invokes a model or writes
    business records.
    """
    db, actor_id, tenant_id, _session_id = ctx
    business_date = db.execute(
        text("SELECT public.lexa_business_date(now(), CAST(:tenant_id AS uuid))"),
        {"tenant_id": str(tenant_id)},
    ).scalar_one_or_none()
    if not isinstance(business_date, date):
        raise HTTPException(
            status_code=503,
            detail={"code": "BUSINESS_DATE_UNAVAILABLE", "message": "LEXA could not determine this workspace's business date."},
        )

    currency = currency_code.strip().upper()
    if not re.fullmatch(r"[A-Z]{3}", currency):
        raise HTTPException(status_code=422, detail="Enter a valid three-letter currency code.")

    end_date = business_date
    start_date = end_date - timedelta(days=6)
    insights_payload = calculate_business_insights(
        db=db,
        actor_id=actor_id,
        tenant_id=tenant_id,
        start_date=start_date,
        end_date=end_date,
        currency_code=currency,
        focus="all",
        as_of_date_override=business_date,
    )
    return build_daily_brief(
        insights_payload=insights_payload,
        as_of_date=business_date,
        currency_code=currency,
    )
'''
    source += route
    # Flag is independent of whether provider API keys happen to exist. Phase 1/2
    # intentionally has no external model execution route.
    source = replace_once(
        source,
        '"durable_job_execution_enabled": False,',
        '"durable_job_execution_enabled": False,\n        "daily_brief_api_enabled": True,',
        "daily brief capability status",
    )
    return source


def patch_web_api(source: str) -> str:
    """Add the typed read-only Phase 2 API client without altering auth transport."""
    marker = "export function getDailyBrief("
    if marker in source:
        if "export type DailyBrief =" in source and "getJson<DailyBrief>(`/api/v1/intelligence/daily-brief?currency_code=" in source:
            return source
        raise InstallError("A conflicting getDailyBrief implementation already exists; refusing to overwrite it.")
    block = '''

// LEXA Intelligence Phase 2 — deterministic read-only daily business brief.
export type DailyBriefItem = {
  rule_id: string; source_insight_id: string; category: string; title: string; summary: string;
  status: string; severity: string; action_label: string; action_href: string;
  evidence: { label: string; href: string; source_tables: string[]; record_count: number; as_of_date: string | null; refreshed_at: string | null };
  metric: { label: string; value: string | number; unit: string; currency_code?: string } | null;
  comparison: Record<string, string | number | null> | null; details: Record<string, string | number | null> | null;
  examples: Array<Record<string, unknown>>; limitations: string[];
};
export type DailyBrief = {
  schema_version: string; rule_version: string; generated_at: string; as_of_date: string; currency_code: string;
  period: { from_date: string; to_date: string; comparison_period: Record<string, string> };
  scope: string; headline: string; status: "available" | "attention" | "partial" | "unavailable";
  counts: { insights_considered: number; action_items: number; information_items: number; data_quality_items: number };
  action_items: DailyBriefItem[]; information_items: DailyBriefItem[]; data_quality: DailyBriefItem[];
  last_successful_refresh_at: string | null; advisory_only: true; external_ai_used: false; business_writes_performed: false; limitations: string[];
};
export function getDailyBrief(currencyCode: string) {
  const currency = currencyCode.trim().toUpperCase();
  if (!/^[A-Z]{3}$/.test(currency)) return Promise.reject(new Error("Set a valid three-letter business currency before loading the daily brief."));
  return getJson<DailyBrief>(`/api/v1/intelligence/daily-brief?currency_code=${encodeURIComponent(currency)}`);
}
'''
    return source.rstrip() + block + "\n"


def patch_web_page(source: str) -> str:
    """Render the daily brief in the existing source-linked Intelligence workspace."""
    present = "getDailyBrief," in source and "Your business daily brief" in source and "const [dailyBrief, setDailyBrief]" in source
    if present:
        return source
    if "Your business daily brief" in source or "const [dailyBrief, setDailyBrief]" in source:
        raise InstallError("The Intelligence page has a partial/conflicting daily brief change; refusing to patch it.")

    source = replace_once(source, "  getBusinessInsights,\n", "  getBusinessInsights,\n  getDailyBrief,\n", "Intelligence page daily brief API import")
    source = replace_once(source, "  type BusinessInsightsResponse,\n", "  type BusinessInsightsResponse,\n  type DailyBrief,\n", "Intelligence page daily brief type import")
    source = replace_once(
        source,
        "  const [businessInsights, setBusinessInsights] = useState<BusinessInsightsResponse | null>(null);\n",
        "  const [businessInsights, setBusinessInsights] = useState<BusinessInsightsResponse | null>(null);\n  const [dailyBrief, setDailyBrief] = useState<DailyBrief | null>(null);\n",
        "Intelligence page daily brief state",
    )
    source = replace_once(
        source,
        '''      const [overviewResult, insightsResult] = await Promise.allSettled([
        getAnalyticsOverview(fromDate, toDate, currentProfile.currency_code),
        getBusinessInsights(fromDate, toDate, currentProfile.currency_code),
      ]);
''',
        '''      const [overviewResult, insightsResult, briefResult] = await Promise.allSettled([
        getAnalyticsOverview(fromDate, toDate, currentProfile.currency_code),
        getBusinessInsights(fromDate, toDate, currentProfile.currency_code),
        getDailyBrief(currentProfile.currency_code),
      ]);
''',
        "Intelligence page daily brief fetch",
    )
    source = replace_once(
        source,
        '''      if (insightsResult.status === "fulfilled") setBusinessInsights(insightsResult.value);
      else { setBusinessInsights(null); issues.push(`Business insights: ${safeError(insightsResult.reason)}`); }
''',
        '''      if (insightsResult.status === "fulfilled") setBusinessInsights(insightsResult.value);
      else { setBusinessInsights(null); issues.push(`Business insights: ${safeError(insightsResult.reason)}`); }
      if (briefResult.status === "fulfilled") setDailyBrief(briefResult.value);
      else { setDailyBrief(null); issues.push(`Daily brief: ${safeError(briefResult.reason)}`); }
''',
        "Intelligence page daily brief result",
    )
    source = replace_once(
        source,
        '''      setOverview(null);
      setBusinessInsights(null);
      issues.push("Add your business currency in Settings to see money values correctly.");
''',
        '''      setOverview(null);
      setBusinessInsights(null);
      setDailyBrief(null);
      issues.push("Add your business currency in Settings to see money values correctly.");
''',
        "Intelligence page missing-currency reset",
    )
    render_anchor = '''      <section className="workspace-section">
        <div className="section-head"><div><span className="section-label">EXPLAINABLE · READ-ONLY</span><h2>What may need your attention?</h2>'''
    render = '''      <section className="workspace-section" aria-labelledby="daily-brief-title">
        <div className="section-head"><div><span className="section-label">OWNER BRIEF · RULES FIRST</span><h2 id="daily-brief-title">Your business daily brief</h2><p>A seven-day, source-backed review of sales, margin, stock and working-capital signals. It does not place orders or post transactions.</p></div>{dailyBrief && <span className={`status ${dailyBrief.status === "attention" ? "warn" : dailyBrief.status === "partial" || dailyBrief.status === "unavailable" ? "neutral" : "good"}`}>{dailyBrief.status === "attention" ? "Review needed" : dailyBrief.status === "partial" ? "Partial evidence" : dailyBrief.status === "unavailable" ? "Unavailable" : "No urgent flags"}</span>}</div>
        {dailyBrief && <p className="muted">As of {dailyBrief.as_of_date} · {dailyBrief.period.from_date} – {dailyBrief.period.to_date} · {dailyBrief.currency_code}{dailyBrief.last_successful_refresh_at ? ` · Last successful refresh ${dailyBrief.last_successful_refresh_at.replace("T", " ").slice(0, 16)} UTC` : " · Refresh timestamp unavailable"}</p>}
        {loading && !dailyBrief && <p role="status">Checking the saved records for your daily brief…</p>}
        {!dailyBrief && !loading && <div className="empty-state compact"><strong>Daily brief unavailable</strong><span>LEXA could not verify the cross-module source data. Try again after checking workspace access and analytics refresh.</span><button type="button" className="button button-soft" onClick={() => void load()} disabled={loading}>Try again</button></div>}
        {dailyBrief && <><p className="insight-answer-summary" role="status">{dailyBrief.headline}</p>
          {dailyBrief.action_items.length > 0 && <div className="foundation-grid">{dailyBrief.action_items.map(item => <article key={item.rule_id} className="panel foundation-panel"><div className="panel-head"><div><span className={`status ${item.severity === "critical" ? "bad" : "warn"}`}>{item.severity === "critical" ? "Critical review" : "Needs review"}</span><h3>{item.title}</h3></div></div><p>{item.summary}</p>{item.metric && <p className="muted"><strong>{item.metric.label}:</strong> {item.metric.unit === "money" ? formatMoney(item.metric.value, item.metric.currency_code || currency) : `${item.metric.value}${item.metric.unit === "percent" ? "%" : item.metric.unit === "items" ? " items" : ""}`}</p>}<p className="muted"><strong>Evidence:</strong> {item.evidence.source_tables.join(", ")} · {item.evidence.record_count} saved rows{item.evidence.as_of_date ? ` · as of ${item.evidence.as_of_date}` : ""}{item.evidence.refreshed_at ? ` · refreshed ${item.evidence.refreshed_at.replace("T", " ").slice(0, 16)}` : ""}</p><div className="insight-evidence-links"><Link href={item.action_href} className="button button-soft button-small">{item.action_label}</Link><Link href={item.evidence.href} className="button button-soft button-small">{item.evidence.label}</Link></div>{item.limitations.slice(0, 2).map(limit => <p className="muted" key={limit}>Limit: {limit}</p>)}</article>)}</div>}
          {dailyBrief.data_quality.length > 0 && <div className="notice notice-error" role="status"><strong>Some sources need checking.</strong><ul>{dailyBrief.data_quality.map(item => <li key={item.rule_id}>{item.title}: {item.summary}</li>)}</ul></div>}
          {dailyBrief.action_items.length === 0 && dailyBrief.status === "available" && <p className="muted">No urgent rule-based alerts were raised from the available saved data. This is not a prediction or a guarantee that every record is correct.</p>}
          {dailyBrief.information_items.length > 0 && <div className="insight-evidence-links">{dailyBrief.information_items.slice(0, 3).map(item => <Link key={item.rule_id} href={item.evidence.href} className="button button-soft button-small">{item.title}</Link>)}</div>}
          <p className="muted">Rules version {dailyBrief.rule_version} · Deterministic rules only · External AI used: no · Business writes performed: no.</p>
        </>}
      </section>

'''
    return replace_once(source, render_anchor, render + render_anchor, "Intelligence daily brief section")

def install_phase2_to_stage(stage_root: Path) -> list[Path]:
    analytics_path = stage_root / "apps/api/app/routes/analytics.py"
    if not analytics_path.is_file():
        raise InstallError("Staged LEXA analytics router is missing.")
    service, analytics_updated = extract_insight_service(analytics_path.read_text(encoding="utf-8"))

    intelligence_routes = stage_root / "apps/api/app/intelligence/routes.py"
    if not intelligence_routes.is_file():
        raise InstallError("Phase 1 must be present before Phase 2 daily brief can be installed.")
    routes_updated = patch_intelligence_routes(intelligence_routes.read_text(encoding="utf-8"))

    web_api_path = stage_root / "apps/web/lib/api.ts"
    web_page_path = stage_root / "apps/web/app/intelligence/page.tsx"
    if not web_api_path.is_file() or not web_page_path.is_file():
        raise InstallError("The existing LEXA Intelligence web page or API client is missing.")
    web_api_updated = patch_web_api(web_api_path.read_text(encoding="utf-8"))
    web_page_updated = patch_web_page(web_page_path.read_text(encoding="utf-8"))

    planned = {
        Path("apps/api/app/routes/analytics.py"): analytics_updated,
        Path("apps/api/app/intelligence/insight_service.py"): service,
        Path("apps/api/app/intelligence/routes.py"): routes_updated,
        Path("apps/web/lib/api.ts"): web_api_updated,
        Path("apps/web/app/intelligence/page.tsx"): web_page_updated,
    }
    for rel in PHASE2_COPY_PATHS:
        source = PHASE2_ROOT / rel
        if not source.is_file():
            raise InstallError(f"Phase 2 bundle is incomplete: missing {source}")
        destination = stage_root / rel
        if destination.exists() and destination.read_bytes() != source.read_bytes():
            raise InstallError(f"Refusing to overwrite a conflicting staged file: {destination}")
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, destination)
        planned[rel] = destination.read_text(encoding="utf-8")

    changed: list[Path] = []
    for relative, content in planned.items():
        destination = stage_root / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        current = destination.read_text(encoding="utf-8") if destination.exists() else None
        if current != content:
            destination.write_text(content, encoding="utf-8")
            changed.append(relative)
    return changed


def _already_installed(repo_root: Path, phase1) -> bool:
    analytics = repo_root / "apps/api/app/routes/analytics.py"
    routes = repo_root / "apps/api/app/intelligence/routes.py"
    service = repo_root / "apps/api/app/intelligence/insight_service.py"
    required = (
        analytics, routes, service,
        repo_root / "apps/web/lib/api.ts",
        repo_root / "apps/web/app/intelligence/page.tsx",
        repo_root / "apps/api/app/intelligence/daily_brief.py",
    )
    if not all(path.is_file() for path in required):
        return False
    analytics_text = analytics.read_text(encoding="utf-8")
    routes_text = routes.read_text(encoding="utf-8")
    service_text = service.read_text(encoding="utf-8")
    if not all((
        "def calculate_business_insights(" in service_text,
        "from ..intelligence.insight_service import calculate_business_insights" in analytics_text,
        "def intelligence_daily_brief(" in routes_text,
        "export function getDailyBrief(" in (repo_root / "apps/web/lib/api.ts").read_text(encoding="utf-8"),
        "Your business daily brief" in (repo_root / "apps/web/app/intelligence/page.tsx").read_text(encoding="utf-8"),
        "def build_daily_brief(" in (repo_root / "apps/api/app/intelligence/daily_brief.py").read_text(encoding="utf-8")
        if (repo_root / "apps/api/app/intelligence/daily_brief.py").is_file() else False,
    )):
        return False
    # Phase 1's route file is intentionally extended by Phase 2. Every other static
    # overlay file must remain byte-identical; do not bless arbitrary drift as complete.
    for relative in phase1.COPY_PATHS:
        destination = repo_root / relative
        bundle_source = PHASE1_ROOT / relative
        if not destination.is_file():
            return False
        if relative == Path("apps/api/app/intelligence/routes.py"):
            if destination.read_text(encoding="utf-8") != patch_intelligence_routes(bundle_source.read_text(encoding="utf-8")):
                return False
        elif destination.read_bytes() != bundle_source.read_bytes():
            return False
    for relative in PHASE2_COPY_PATHS:
        destination = repo_root / relative
        bundle_source = PHASE2_ROOT / relative
        if not destination.is_file() or destination.read_bytes() != bundle_source.read_bytes():
            return False
    return True


def install(repo_root: Path) -> list[Path]:
    repo_root = repo_root.resolve()
    for relative in BASE_PATHS:
        if not (repo_root / relative).is_file():
            raise InstallError(f"{repo_root} does not look like the inspected LEXA checkout; missing {relative}.")

    phase1 = _load_phase1_installer()
    if _already_installed(repo_root, phase1):
        return []
    # The Phase 1 installer is intentionally conservative about existing overlay
    # files; preflight collisions in the real checkout before creating a stage.
    for relative in phase1.COPY_PATHS:
        destination = repo_root / relative
        source = PHASE1_ROOT / relative
        if destination.exists() and destination.read_bytes() != source.read_bytes():
            raise InstallError(f"Conflicting Phase 1 file already exists: {relative}")
    for relative in PHASE2_COPY_PATHS:
        destination = repo_root / relative
        source = PHASE2_ROOT / relative
        if destination.exists() and destination.read_bytes() != source.read_bytes():
            raise InstallError(f"Conflicting Phase 2 file already exists: {relative}")

    with tempfile.TemporaryDirectory(prefix="lexa-intelligence-stage-") as temp_name:
        stage = Path(temp_name)
        for relative in BASE_PATHS:
            target = stage / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(repo_root / relative, target)
        for relative in phase1.COPY_PATHS:
            existing = repo_root / relative
            if existing.exists():
                target = stage / relative
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(existing, target)
        for relative in PHASE2_COPY_PATHS:
            existing = repo_root / relative
            if existing.exists():
                target = stage / relative
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(existing, target)

        phase1.install(stage)
        install_phase2_to_stage(stage)

        # Capture all changed/new files other than transient staging backups.
        staged_files = [p for p in stage.rglob("*") if p.is_file() and not p.name.endswith((".phase1.bak", ".phase2.bak"))]
        staged_files = [p for p in staged_files if ".git" not in p.parts]
        changes: dict[Path, bytes] = {}
        for source in staged_files:
            relative = source.relative_to(stage)
            destination = repo_root / relative
            content = source.read_bytes()
            if not destination.exists() or destination.read_bytes() != content:
                changes[relative] = content

        # All writes/backups are preflighted before touching the user's checkout.
        backup_plan: dict[Path, Path] = {}
        for relative in changes:
            destination = repo_root / relative
            if destination.exists():
                phase1_backup = destination.with_suffix(destination.suffix + ".phase1.bak")
                phase2_backup = destination.with_suffix(destination.suffix + ".phase2.bak")
                if phase1_backup.exists() or phase2_backup.exists():
                    raise InstallError(f"Refusing to overwrite an existing rollback backup for {relative}.")
                # Files changed by Phase 1 in the staged run have a corresponding
                # Phase 1 backup. Everything else receives a Phase 2 backup.
                staged_phase1_backup = (stage / relative).with_suffix((stage / relative).suffix + ".phase1.bak")
                backup_plan[relative] = phase1_backup if staged_phase1_backup.exists() else phase2_backup

        written: list[Path] = []
        created: list[Path] = []
        try:
            for relative, backup in backup_plan.items():
                shutil.copy2(repo_root / relative, backup)
            for relative, content in changes.items():
                destination = repo_root / relative
                destination.parent.mkdir(parents=True, exist_ok=True)
                if not destination.exists():
                    created.append(destination)
                destination.write_bytes(content)
                written.append(destination)
        except Exception:
            for destination in reversed(written):
                relative = destination.relative_to(repo_root)
                backup = backup_plan.get(relative)
                if backup and backup.exists():
                    shutil.copy2(backup, destination)
                elif destination in created and destination.exists():
                    destination.unlink()
            for backup in backup_plan.values():
                if backup.exists():
                    backup.unlink()
            raise
        return sorted(changes)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo-root", type=Path, required=True, help="Path to a local LEXA checkout")
    args = parser.parse_args()
    try:
        changes = install(args.repo_root)
    except InstallError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2
    if changes:
        print("Phase 1 + Phase 2 overlay staged locally; review the source diff before committing:")
        for path in changes:
            print(f"  {path}")
    else:
        print("Phase 1 + Phase 2 overlay is already installed; no files changed.")
    print("No SQL was applied, provider was enabled, production system was accessed, or deployment was performed.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
