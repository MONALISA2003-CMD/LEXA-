# LEXA Intelligence — Phase 1 closure + Phase 2 daily brief

This bundle combines the previously uploaded Phase 1 intelligence foundation with a deeper Phase 2 rules-first daily brief. It is designed for the inspected LEXA `main` source; its installer validates anchors, works on a temporary staging copy first, and creates backups before changing a local checkout.

## Important repository finding

GitHub commit `1fd4ee081bf45be6c78e330e52851d8a33bb4667` on `main` contains `LEXA_PHASE1_IMPLEMENTATION_2026-10-24.zip` as an uploaded ZIP asset. It does not contain the unpacked Phase 1 Python modules or migration as application source files. The `LEXA-branch` branch exists and contains an API project/analytics router, but its `apps/api/app/routes/ai_assistant.py` path was not found. Since the installer targets the currently inspected `main` layout and uses that route as a reviewed patch anchor, reconcile the branch's route layout before applying this bundle there. The visible status for the ZIP commit is a passing Vercel check; that is not evidence of Python test or migration replay execution.

## Phase 1 closure checklist

See [`PHASE1_REMAINING_WORK.md`](PHASE1_REMAINING_WORK.md) for the exact source-integration, CI, disposable PostgreSQL, tenant/RLS, and provider-closure work still required.

## Included

- Phase 1 overlay: strict intelligence contracts, policy-only AI router, default-deny gate, migration candidate 045, tests and clean-replay assertions.
- Phase 2: deterministic daily-brief builder, contract tests, typed web API client, and a daily-brief panel in the existing Intelligence workspace.
- A combined installer that applies Phase 1 and Phase 2 in a staged tree, extracts the existing deterministic analytics insight body into a shared service (without duplicating its SQL), turns `/analytics/insights` into a thin wrapper, adds `GET /api/v1/intelligence/daily-brief`, and wires that endpoint into the existing web page.
- A Phase 1 remaining-work/closure checklist, architecture notes, safety boundaries, and acceptance criteria.

## Install (local checkout only)

```bash
python scripts/apply_intelligence_phases.py --repo-root /path/to/LEXA-
```

The installer does not access GitHub/Render/Vercel/Neon, change environment settings, apply SQL, enable model providers, or deploy. Inspect the diff and generated `.phase1.bak` / `.phase2.bak` files. Existing conflicting overlay files cause a fail-closed refusal.

## Tests

Phase 1 synthetic tests:

```bash
cd phase1/apps/api
PYTHONPATH=. python -m pytest -q tests/test_intelligence_phase1.py
```

Phase 2 synthetic tests are in `phase2/apps/api/tests/test_intelligence_phase2.py`. The pure module requires the Phase 1 `app` package to be installed or placed on the test workspace path. The installer/extraction/web-integration tests are in `scripts/test_phase2_installer.py`.

## Current validation limits

- Phase 1 synthetic tests: 20 passed. Phase 2 synthetic tests: 9 passed. Installer/extraction/web-integration tests: 6 passed (**35 synthetic tests total**).
- Tests ran against bundled code and a synthetic checkout. The combined installer has not yet been run against an actual LEXA checkout in this environment.
- No real PostgreSQL replay has been performed.
- No full upstream CI or live authenticated API/frontend integration test has been performed by this bundle.
- Migration 045 has not been applied.
- External AI execution remains disabled; Phase 2 does not call providers.
- The web/Next.js production build and a mobile/visual browser review remain unverified; the installed project's normal Node 24 checks must run after integration.
