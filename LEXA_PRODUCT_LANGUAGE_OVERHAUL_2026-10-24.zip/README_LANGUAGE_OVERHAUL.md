# LEXA Product Language Overhaul — 24 October 2026

This ZIP is an overlay for the LEXA repository. Extract it at the repository root, targeting `main`.

## What it changes

- Removes customer-facing AI provider discovery, provider names, key/quota/pricing disclosures, technical setup instructions, and the misleading question form from the Business assistant page.
- Keeps the unavailable Business assistant page useful by directing users to Sales, Stock, Reports, Purchases, Customers, and Documents.
- Simplifies navigation labels and keeps existing route paths/search destinations compatible.
- Polishes user-facing copy in Daily overview, Sales forecast, and Documents, including empty states, error messages, evidence labels and date presentation.
- Rewords related forecast/document errors so technical details and raw server messages are not shown to ordinary users.
- Adds the product-language standards, a whole-interface inventory, and regression tests.

## Safety boundary

This is a copy/UI-only overlay except for user-facing error and status wording. It does not add or continue business feature phases. It does not change migrations, production data, permissions, accounting logic, AI server configuration, secrets, deployments, or infrastructure settings. Provider selection is no longer requested by this assistant page; the page makes no assistant request while the assistant is unavailable.

## Validation

The overlay includes Node contract tests for the Assistant, navigation, forecast and document language. Validation results are recorded in `VALIDATION_RESULTS.md`. The included focused suite passed 19 Node tests; three changed Python modules compile; navigation syntax checks pass. These are focused checks, not a claim that the full repository CI, Next.js production build, or authenticated browser acceptance was run in this environment.
