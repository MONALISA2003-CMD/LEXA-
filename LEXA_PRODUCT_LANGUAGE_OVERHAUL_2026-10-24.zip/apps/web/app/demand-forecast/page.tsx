"use client";

import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import { AppShell } from "../../components/app-shell";
import { getDemandForecast, type DemandForecastItem, type DemandForecastResponse } from "../../lib/demand-forecast-api";
import styles from "./page.module.css";

function units(value: string | number | null | undefined) {
  if (value === null || value === undefined || !Number.isFinite(Number(value))) return "Not measurable";
  return Number(value).toLocaleString("en-UG", { maximumFractionDigits: 3 });
}
function backtestLabel(value: string | null) {
  if (value === "BETTER_THAN_LAST_WEEK_BASELINE") return "More accurate than using last week alone";
  if (value === "WORSE_THAN_LAST_WEEK_BASELINE") return "Less accurate than using last week alone";
  if (value === "TIED_WITH_LAST_WEEK_BASELINE") return "About as accurate as using last week alone";
  return "Not comparable yet";
}
function ForecastCard({ item }: { item: DemandForecastItem }) {
  return <article className={styles.card}>
    <div className={styles.cardHead}>
      <div><span className="section-label">{item.sku || "Product code not added"}</span><h3>{item.product_name} · {item.variant_name}</h3></div>
      <span className={`status ${item.status === "available" ? "good" : "warn"}`}>{item.status === "available" ? "Enough history to compare" : "More sales history needed"}</span>
    </div>
    <div className={styles.metrics}>
      <div><span>Expected units</span><strong>{units(item.total_forecast_units)} units</strong><small>Next {item.horizon_days} days</small></div>
      <div><span>Average forecast error</span><strong>{units(item.backtest.mae_units)} units</strong><small>{item.backtest.test_days_evaluated}-day check against past sales</small></div>
      <div><span>Error as a share of sales</span><strong>{item.backtest.wape_percent === null ? "Not measurable" : `${units(item.backtest.wape_percent)}%`}</strong><small>Compared with last week: {item.backtest.last_week_baseline_wape_percent === null ? "not measurable" : `${units(item.backtest.last_week_baseline_wape_percent)}%`}</small></div>
    </div>
    <p className={styles.comparison}>{backtestLabel(item.backtest.comparison_to_baseline)}</p>
    <details className={styles.details}>
      <summary>Daily estimate and usual range</summary>
      <div className={styles.tableWrap}>
        <table>
          <thead><tr><th scope="col">Date</th><th scope="col">Expected units</th><th scope="col">Usual range for this day of the week</th></tr></thead>
          <tbody>{item.forecast.map(day => <tr key={day.date}><td>{day.date}</td><td>{units(day.forecast_units)}</td><td>{units(day.historical_same_weekday_low)} – {units(day.historical_same_weekday_high)}</td></tr>)}</tbody>
        </table>
      </div>
    </details>
    <p className={styles.meta}>Sales were recorded on {item.active_demand_days} of the last {item.history_days} days.</p>
  </article>;
}

export default function DemandForecastPage() {
  const [report, setReport] = useState<DemandForecastResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const load = useCallback(async () => {
    setLoading(true); setError("");
    try { setReport(await getDemandForecast(14)); }
    catch (cause) { setReport(null); setError(cause instanceof Error ? cause.message : "LEXA couldn't load the sales forecast. Check recent sales records and try again."); }
    finally { setLoading(false); }
  }, []);
  useEffect(() => { void load(); }, [load]);

  return <AppShell title="Sales forecast" eyebrow="SALES PLANNING">
    <main className={`workspace ${styles.page}`} style={{ maxWidth: 1240 }}>
      <div className="workspace-header">
        <div><span className="workspace-breadcrumb">LEXA · SALES PLANNING</span><h1>Plan stock with recent sales in mind.</h1><p>This estimate uses recent sales patterns. We compare it with earlier sales to show how well it would have performed.</p></div>
        <div className="header-actions"><Link href="/inventory" className="button button-soft">Open stock</Link><button className="button button-soft" type="button" onClick={() => void load()} disabled={loading}>{loading ? "Checking…" : "Refresh estimate"}</button></div>
      </div>
      <section className={styles.notice} aria-label="Forecast safety limits">
        <strong>For planning only</strong>
        <p>LEXA does not create purchase orders or change stock from this estimate. Sales can look lower when products are out of stock. The range shows past patterns; it is not a promise of future demand.</p>
      </section>
      {error && <div className="notice notice-error" role="alert">{error}<button className="button button-soft" type="button" onClick={() => void load()} disabled={loading}>Try again</button></div>}
      {loading && <div className="empty-state compact" role="status">Checking recent sales records…</div>}
      {!loading && report && <>
        <section className={styles.summary}>
          <div className={styles.summaryHead}><div><span className="section-label">AS OF {report.as_of_date}</span><h2>{report.status === "unavailable" ? "A forecast is not available yet." : report.status === "partial" ? "Some products need more sales history." : "Estimates are ready to review."}</h2><p>{report.message}</p><p className={styles.meta}>Across all active branches</p></div><span className={`status ${report.status === "available" ? "good" : report.status === "partial" ? "warn" : "neutral"}`}>{report.status === "available" ? "Available" : report.status === "partial" ? "Needs more history" : "Not available"}</span></div>
          <div className={styles.summaryStats}><div><span>Sales history checked</span><strong>{report.history_coverage_verified ? "Yes" : "No"}</strong><small>{report.history_from_date} – {report.history_to_date}</small></div><div><span>Products included</span><strong>{report.items.length}</strong><small>Up to 30 products with the most recorded sales</small></div><div><span>Products not included</span><strong>{report.excluded_items.length}</strong><small>Not enough recent sales records</small></div><div><span>Last updated</span><strong>{report.history_refresh_completed_at ? "Recent" : "Unavailable"}</strong><small>{report.history_refresh_completed_at ? new Date(report.history_refresh_completed_at).toLocaleString("en-UG", { dateStyle: "medium", timeStyle: "short" }) : "No recent update found"}</small></div></div>
        </section>
        {report.items.length > 0 ? <section className="workspace-section"><div className="section-head"><div><span className="section-label">14-DAY ESTIMATE</span><h2>Expected demand by product</h2><p>Products are ordered by recorded sales over the last 56 days. We show the error as a share of sales only when the comparison period includes sales.</p></div></div><div className={styles.cards}>{report.items.map(item => <ForecastCard key={item.variant_id} item={item} />)}</div></section> : <div className={styles.empty}>There is not enough reliable recent sales information to prepare an estimate. Missing or outdated information is not treated as zero sales.</div>}
        {report.excluded_items.length > 0 && <section className="workspace-section"><div className="section-head"><div><span className="section-label">INFORMATION QUALITY</span><h2>Products without an estimate</h2><p>These products do not yet have enough recent sales history for a useful estimate.</p></div></div><div className={styles.excluded}>{report.excluded_items.map(item => <article key={`${item.sku}-${item.variant_name}`}><strong>{item.product_name} · {item.variant_name}</strong><span>{item.sku || "No product code"}</span><p>{item.message}</p></article>)}</div></section>}
        <details className={styles.method}><summary>How the estimate is made</summary><ul><li>Requires a recent update that includes the full previous 56 days of sales records.</li><li>Looks at the typical number of units sold on the same day of the week over the previous eight weeks.</li><li>Checks the estimate against two weeks of past sales, then compares the result with a simple estimate based on the previous week.</li><li>The estimate may be lower when products were out of stock. It also does not account for holidays, promotions, differences between branches or supplier delivery times.</li><li>This estimate does not change stock or create an order. Use the purchasing tools to plan and record orders.</li></ul></details>
        <p className={styles.footer}>This estimate is for planning only. LEXA has not changed your stock or purchasing records.</p>
      </>}
    </main>
  </AppShell>;
}
