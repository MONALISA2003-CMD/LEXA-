import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { resolve } from 'node:path';
import { primaryNavigation, resolveBusinessSearchDestination } from '../lib/navigation.mjs';

const ROOT = resolve(import.meta.dirname, '..');
const read = (path) => readFile(resolve(ROOT, path), 'utf8');

test('navigation uses familiar labels while preserving real routes and search aliases', () => {
  assert.ok(primaryNavigation.some(([href, label]) => href === '/ai-assistant' && label === 'Business assistant'));
  assert.ok(primaryNavigation.some(([href, label]) => href === '/demand-forecast' && label === 'Sales forecast'));
  assert.ok(primaryNavigation.some(([href, label]) => href === '/commerce' && label === 'Checkout'));
  assert.equal(resolveBusinessSearchDestination('business assistant'), '/ai-assistant?q=business%20assistant');
  assert.equal(resolveBusinessSearchDestination('expected demand'), '/demand-forecast?q=expected%20demand');
  assert.equal(resolveBusinessSearchDestination('open checkout'), '/commerce?q=open%20checkout');
});

test('assistant page contains no provider, key, quota, pricing or technical setup copy', async () => {
  const page = await read('app/ai-assistant/page.tsx');
  for (const phrase of ['API key', 'quota', 'provider', 'OpenAI', 'Gemini', 'Groq', 'paid service', 'NEXT_PUBLIC_', 'model']) {
    assert.doesNotMatch(page.toLowerCase(), new RegExp(phrase.toLowerCase()));
  }
  assert.match(page, /The assistant isn’t available right now/);
  assert.ok(page.includes('href: "/sales"'));
  assert.ok(page.includes('href: "/inventory"'));
  assert.ok(page.includes('href: "/reports"'));
  assert.ok(page.includes('href: "/purchasing"'));
});

test('forecast copy avoids leaking internal model metrics and database names to users', async () => {
  const page = await read('app/demand-forecast/page.tsx');
  assert.match(page, /Sales forecast/);
  assert.match(page, /Plan stock with recent sales in mind/);
  assert.doesNotMatch(page, /\bWAPE\b|\bMAE\b|rolling-origin|source_tables|external_ai_used|Business writes performed/i);
});

test('document review explains that found details must be checked by a person', async () => {
  const page = await read('app/documents/page.tsx');
  assert.match(page, /Review important details from your documents/);
  assert.match(page, /Check every detail against the original/);
  assert.match(page, /friendlyReadingMethod\(selected\.extraction_method\)/);
  assert.doesNotMatch(page, /branch-scoped store|AI provider|API key|quota|label match/i);
});

test('language standards and inventory ship with this overlay', async () => {
  const standards = await read('../../docs/LEXA_PRODUCT_LANGUAGE_STANDARDS.md');
  const inventory = await read('../../docs/LEXA_PRODUCT_LANGUAGE_INVENTORY_2026-10-24.md');
  assert.match(standards, /Professional and approachable/);
  assert.match(standards, /financial meaning|accounting records/i);
  assert.match(inventory, /Business assistant/);
  assert.match(inventory, /Tax and receipts/);
});

test('daily overview avoids database terminology and reports page-specific errors', async () => {
  const page = await read('app/daily-brief/page.tsx');
  const api = await read('lib/daily-brief-api.ts');
  assert.match(page, /Daily overview/);
  assert.match(page, /Based on \{item\.evidence\.record_count\} saved/);
  assert.doesNotMatch(page, /source_tables\.join|saved rows|deterministic rules|external AI provider/i);
  assert.match(api, /couldn’t load the daily overview/);
  assert.doesNotMatch(api, /sales forecast|FRESH_COMPLETE_HISTORY_REQUIRED|INSUFFICIENT_DEMAND_HISTORY/);
});

test('forecast limitations use business language, not implementation terminology', async () => {
  const forecasting = await read('../../apps/api/app/intelligence/forecasting.py');
  assert.match(forecasting, /recent sales records are needed to prepare an estimate/);
  assert.match(forecasting, /make a useful estimate/);
  assert.doesNotMatch(forecasting, /history window is required|for this baseline/);
});

test('document form asks for currency in an understandable way', async () => {
  const page = await read('app/documents/page.tsx');
  assert.match(page, /Currency \(for example, UGX\)/);
  assert.doesNotMatch(page, /label: "Currency code"/);
});
