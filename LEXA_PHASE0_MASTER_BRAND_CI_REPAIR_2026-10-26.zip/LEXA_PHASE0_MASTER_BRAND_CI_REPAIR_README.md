# LEXA Phase 0 — master brand CI repair

## Exact failure observed
GitHub Actions run `40295573655` on `main` (`7ef1444f3f455a940fa1e0cae18c98c76775b72f`) reports:
- API unit/contract tests: pass
- Web typecheck: pass
- Frontend contract tests: **1 failure out of 126**
- Docker Compose / HAProxy config: pass
- Production frontend build: skipped because frontend contracts failed

Failing test: `apps/web/tests/phase12-live-brand-visibility.test.mjs`, test `desktop sidebar and authentication use the full master artwork`.

Cause: `lastRule(".app-sidebar .app-brand {")` finds a later height-only override, so the last effective matching rule no longer declares the master logo background. The mobile-logo assertion uses the same last-rule pattern and would also be at risk after the first failure is fixed.

## Repair
Apply `LEXA_PHASE0_MASTER_BRAND_CI_REPAIR.patch` to the repository. It appends final, high-specificity brand rules:
- Sidebar: `/lexa-master-logo.jpg`
- Authentication story: `/lexa-master-logo.jpg`
- Mobile topbar pseudo-element: `/lexa-wordmark-master.jpg`, with explicit empty content and transparent text

It does not change business logic, data, APIs, migrations, deployment settings, or secrets.

## Verification status
This is a proposed source patch, not yet applied to GitHub and not yet run through CI. The connected GitHub write operation returned HTTP 403 `Resource not accessible by integration`; no repository or deployment mutation was performed. Apply the patch on a branch, run the frontend contract suite and production build, then merge only if the exact candidate passes.

## Deployment reconciliation
- GitHub `main` / observed Vercel SHA: `7ef1444f3f455a940fa1e0cae18c98c76775b72f`
- Render live API SHA: `aa4cdf46c9f59d4be120886b63613122cd3bf94a`
- GitHub compare: Render SHA is an ancestor; `main` is **19 commits ahead**, 0 behind. This is a deployment lag / source-version mismatch, not two divergent histories.
- Render auto-deploy is configured on commit, but no new deployment was triggered from this session. Keep deployment and expensive production checks deferred as requested.
