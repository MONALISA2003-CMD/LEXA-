#!/usr/bin/env bash
set -euo pipefail

EXPECTED_MAIN_SHA='ccb9753b10157348946a5e0cba42671b0f008085'
PATCH_FILE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/LEXA_LOW_COST_CI_FIX_2026-10-24.patch"

if ! git rev-parse --show-toplevel >/dev/null 2>&1; then
  echo 'ERROR: run this script from inside a trusted LEXA git checkout.' >&2
  exit 2
fi
if [[ -n "$(git status --porcelain)" ]]; then
  echo 'ERROR: working tree is not clean. Move the bundle outside the repo and clean/stash changes first.' >&2
  exit 3
fi

git fetch origin main
ACTUAL_MAIN_SHA="$(git rev-parse origin/main)"
if [[ "$ACTUAL_MAIN_SHA" != "$EXPECTED_MAIN_SHA" ]]; then
  echo "ERROR: expected origin/main $EXPECTED_MAIN_SHA, found $ACTUAL_MAIN_SHA. Review/rebase instead of forcing this patch." >&2
  exit 4
fi

BRANCH='fix/low-cost-ci-2026-10-24'
if git show-ref --verify --quiet "refs/heads/$BRANCH"; then
  echo "ERROR: local branch $BRANCH already exists. Choose a new branch name and apply manually." >&2
  exit 5
fi

git switch -c "$BRANCH" origin/main
git apply --check "$PATCH_FILE"
git apply "$PATCH_FILE"
git diff --check
echo "Patch applied on $BRANCH. Run the verification commands in README.md before pushing/opening a PR. No push or deployment was performed."
