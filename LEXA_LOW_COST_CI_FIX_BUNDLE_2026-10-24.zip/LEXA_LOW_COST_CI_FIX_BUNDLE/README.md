# LEXA low-cost CI fix — 24 October 2026

Prepared against the verified `origin/main` commit:

`ccb9753b10157348946a5e0cba42671b0f008085`

Only three files are changed by the patch:

- `apps/api/app/config.py`
- `apps/web/tests/phase5-sales-cockpit.test.mjs`
- `apps/web/tests/phase7-purchasing-contract.test.mjs`

## Root causes

1. **API test failure:** `apps/api/app/routes/ai_assistant.py` reads settings attributes such as `settings.groq_api_key` and `settings.groq_model` after checking process environment variables. Those fields were missing from Pydantic `Settings` in `apps/api/app/config.py`. The exact failure was `ValueError: "Settings" object has no field "groq_api_key"`, with pytest reporting `1 failed, 219 passed, 2 warnings, 1 error`. Define the key/model fields for all six configured providers so `.env` values can be loaded, preserving blank API-key defaults (provider disabled) and the existing model defaults.

2. **Frontend contract failures:** two tests demanded the identifiers `run_phase345_staging_e2e` and `run_phase7_staging_e2e` plus clean replay/write-enabled staging details inside `.github/workflows/lexa-ci.yml`. The actual canonical workflow intentionally runs only the cheap `api-unit-contracts`, `web-build`, and `compose-config` jobs. The test expectations had become inconsistent with the agreed “expensive gates last” policy. The patch now asserts the three lightweight jobs exist and the expensive staging/replay gates remain absent; safeguards continue to be tested in the E2E spec/config.

The failing run is [40057796707](https://github.com/MONALISA2003-CMD/LEXA-/actions/runs/40057796707).

## Apply safely

Extract this bundle outside the repository. In a clean trusted checkout:

```bash
git fetch origin main
test "$(git rev-parse origin/main)" = "ccb9753b10157348946a5e0cba42671b0f008085"
git switch -c fix/low-cost-ci-2026-10-24 origin/main
git apply --check /path/to/LEXA_LOW_COST_CI_FIX_2026-10-24.patch
git apply /path/to/LEXA_LOW_COST_CI_FIX_2026-10-24.patch
git diff --check
```

If `origin/main` has advanced, **stop and review/rebase the patch** instead of forcing it.

## Verify before PR

```bash
(cd apps/api && python -m pip install -e '.[dev]' && python -m pytest tests -q)
(cd apps/web && npm ci --no-audit --no-fund && npm test && npm run typecheck && npm run build)
docker compose config --quiet
docker run --rm --volume "$PWD/deploy/docker/haproxy.cfg:/usr/local/etc/haproxy/haproxy.cfg:ro" haproxy:3.2-alpine haproxy -c -f /usr/local/etc/haproxy/haproxy.cfg
git diff --check
```

Then push the branch and open a PR into `main`; do not commit straight to `main`. Verify the Actions run uses the PR's exact head SHA. Do not enable write-enabled staging E2E, clean production migration replay, paid provider calls, or production deployment as part of this low-cost fix.

## Verification evidence / limitations

Checks completed in this session:

- Pydantic model smoke test: all 12 provider key/model settings are declared and assignable.
- `.env` regression smoke test: dummy `GROQ_API_KEY` and `GROQ_MODEL` values load into `Settings`; empty Gemini key remains disabled.
- `py_compile` of the modified config passed.
- `node --check` of both modified test files passed.
- Focused assertions confirmed that the lightweight workflow structure matches the revised test expectations.
- `git diff --check` and `git apply --check` passed against a clean fixture built from the origin file contents.

The full API/frontend CI suites were **not run** in this session. This environment's GitHub write integration returned `403 Resource not accessible by integration` on branch creation, and direct network access for a local clone was unavailable. No repository, deployment, secret, or database state was changed. Full CI must pass on the PR before merging.
