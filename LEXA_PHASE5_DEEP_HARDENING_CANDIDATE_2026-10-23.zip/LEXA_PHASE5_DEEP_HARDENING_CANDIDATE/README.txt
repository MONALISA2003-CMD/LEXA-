LEXA Phase 5 Deep Hardening Candidate

Review-only, repository-relative patch bundle. Contains one forward-only SQL migration candidate, one static regression contract test, and an evidence/acceptance note. Not a full application-source ZIP. No database was modified, no migration was applied, no deployment was triggered, and no GitHub write succeeded.

Required before adoption: reconcile with the exact current source SHA, run SQL replay + behavioral tests against disposable PostgreSQL 18, run all CI and staging E2E, and pass restore-drill acceptance.
