# LEXA Phase 5 deep-hardening candidate — review notes

## Scope and status

This is a review-only patch bundle for `MONALISA2003-CMD/LEXA-`. It is not applied to either Neon database and has not been committed or deployed. GitHub branch creation was denied with HTTP 403. No Render/Vercel action was taken.

## Candidate change

`migrations/045_phase5_journal_period_date_guard.sql` replaces `public.post_journal_entry` with the existing Phase 5 posting protections plus a tenant-scoped accounting-period lookup and an explicit requirement that `journal_entries.entry_date` fall within `accounting_periods.start_date..end_date`. It is additive/forward-only and records migration identity `045_phase5_journal_period_date_guard`.

The companion test is a static contract test. It is not a substitute for database execution tests. Before adoption, test on a disposable PostgreSQL 18 database with positive cases (first/last day of period) and negative cases (one day before, one day after, closed/locked period, missing period, wrong tenant). Verify rollback on rejection and preserve the original function signature/grants.

## Live observations from read-only checks on 2026-10-23

- Main Neon project `LEXA`, branch `lexa-live`, database `neondb`: 43 migration-ledger rows, latest applied timestamp 2026-10-23T09:58:48Z.
- Backup Neon project `LEXA-BACKUP-20261022`, branch `lexa-backup`, database `lexa_backup`: 31 migration-ledger rows, latest applied timestamp 2026-10-21T08:00:36Z.
- Main has 130 public tables; backup has 119. Main has 11 public tables absent from backup: `analytics_refresh_queue`, `inventory_replenishment_policies`, `purchase_landed_cost_allocations`, `purchase_landed_costs`, `supplier_bills`, `supplier_ledger_entries`, `supplier_payment_allocations`, `supplier_payments`, `team_conversation_reads`, `team_conversations`, `team_messages`.
- The backup archive manifest says it is `VERIFIED_WITH_EXPLICIT_EXCLUSIONS`, a `selective_native_schema_and_data_copy`; its own verification table reports 119/119 row-count and content matches for the copied/represented tables. It explicitly records 12 excluded tables and 57 omitted operational rows (38 sessions, 16 outbox events, 3 idempotency records). It is not a byte-identical provider snapshot, nor proof of a completed restore drill.
- No scheduled Neon snapshot schedule was found for either named project during the preceding audit. The manual backup snapshot record alone does not prove recoverability.
- The queried financial/commerce tables returned zero rows in both databases for this read-only check: `journal_entries`, `journal_lines`, `sales`, `sale_returns`, `refund_records`, `payment_allocations`, `receivables`, `customer_credits`, and `inventory_transactions`. Therefore aggregate invariant checks pass vacuously and do not establish workflow correctness.
- The live `post_journal_entry(uuid,uuid)` definition contains no references to `entry_date`, `start_date`, or `end_date`, confirming that the date-range check is absent from the currently observed function.
- Live posted-journal audit found zero posted entries, so no claim is made that historical posted entries are clean.
- GitHub branch creation for `lexa/phase5-deep-hardening-2026-10-23` failed with HTTP 403 (`Resource not accessible by integration`). No retry was made.

## Release gate

1. Confirm the source migration directory and current canonical migration chain on the pinned `main` SHA before integrating migration 045. Check for an existing migration 045 or a concurrent change.
2. Run the migration replay against disposable PostgreSQL 18, then execute behavioral SQL tests for both boundary and rejection cases.
3. Run the complete backend and frontend suites, Node 24 build/typecheck, and authenticated staging E2E against a non-production database.
4. Prove restore from a new, current recovery artifact into a separate disposable database, including schema, data, RLS, grants, routines, triggers, and application smoke tests.
5. Keep both named Neon databases unchanged until explicit approval of the migration and backup recovery work. Do not use the third `LEXA-PHASE7-REPLAY-20261022` project; it is outside this scope.
