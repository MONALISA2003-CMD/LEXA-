# LEXA Rename/Delete Manifest

**Input:** `LEXA--main (1).zip`  
**Output:** `LEXA-cleaned.zip`  
**Date:** 2026-10-27

## Summary counts

- File moves/renames: **27**.
- Added canonical-tree paths: **9** (seven source/maintenance additions plus the two reports).
- Original archive file paths deleted: **2,190** (move-source paths are excluded from deletions).
- Existing paths modified in place: **13**.
- Original archive file entries: **2,607**; duplicate paths in the original ZIP: 0.

The original ZIP wrapped everything in `LEXA--main/`. The cleaned ZIP writes all paths from the repository root (for example, `apps/web/...`, `migrations/...`, and `README.md`).

## File moves and renames

| Original path | New path | Reason |
|---|---|---|
| `API_KEYS_FOR_RENDER.md` | `docs/operations/provider-credentials.md` | Moved provider credential guidance into operations. |
| `BILLING_ON_HOLD.md` | `docs/operations/billing-boundary.md` | Moved the billing boundary statement into operations. |
| `FRESH_NEW_PRODUCT_STRATEGY.md` | `docs/product/product-direction.md` | Moved product direction into product documentation. |
| `docs/AI_AND_DOCKER_MAIN_BUILD.md` | `docs/operations/container-and-build.md` | Moved container/build guidance into operations. |
| `docs/DEPLOYMENT_RENDER_VERCEL.md` | `docs/operations/deployment.md` | Reorganized deployment procedures under operations; wording refreshed to reflect checked-in deployment config. |
| `docs/LEXA_AI_MODEL_ROUTER.md` | `docs/architecture/ai-policy-router.md` | Moved AI policy/router design into architecture documentation. |
| `docs/LEXA_AI_SYNTHETIC_TEST_PLAN.md` | `docs/testing/ai-synthetic-test-plan.md` | Moved AI synthetic-test guidance into testing documentation. |
| `docs/LEXA_EXPERIENCE_FOUNDATION_v1.4.2.md` | `docs/product/experience-foundation.md` | Moved UX foundation into product documentation; removed version-style directory naming. |
| `docs/LEXA_INTELLIGENCE_PHASE1_IMPLEMENTATION.md` | `docs/architecture/intelligence-foundation.md` | Moved useful intelligence foundation notes into architecture. |
| `docs/LEXA_INTELLIGENCE_PHASE2_IMPLEMENTATION.md` | `docs/architecture/daily-brief.md` | Moved daily-brief design into architecture. |
| `docs/LEXA_INTELLIGENCE_PHASE3_DOCUMENT_INTELLIGENCE.md` | `docs/architecture/document-intelligence.md` | Moved document-intelligence design into architecture. |
| `docs/LEXA_MASTER_BRAND_AND_UI_SYSTEM.md` | `docs/product/brand-and-ui-system.md` | Moved brand/UI reference into product documentation. |
| `docs/LEXA_PHASE4_DEMAND_FORECASTING_PILOT.md` | `docs/architecture/demand-forecasting.md` | Moved demand-forecasting notes into architecture. |
| `docs/LEXA_PRODUCT_LANGUAGE_INVENTORY_2026-10-24.md` | `docs/product/language-inventory.md` | Moved language inventory into product documentation. |
| `docs/LEXA_PRODUCT_LANGUAGE_STANDARDS.md` | `docs/product/language-standards.md` | Moved language standards into product documentation. |
| `docs/LEXA_SALES_INTEGRITY_AND_5000_USER_READINESS.md` | `docs/architecture/sales-integrity-and-scale-readiness.md` | Moved sales integrity/scale notes into architecture. |
| `docs/LEXA_UNIFIED_FRONTEND_BRAND_AND_WORKFLOW_SYSTEM.md` | `docs/product/frontend-workflow-and-brand-guidelines.md` | Moved frontend workflow guidance into product documentation. |
| `docs/PHASE0_2_SECURITY_CUTOVER_RUNBOOK.md` | `docs/operations/database-security-cutover.md` | Moved database security cutover runbook into operations. |
| `docs/PHASE0_RUNBOOK.md` | `docs/operations/initial-environment-checks.md` | Moved initial-environment checks into operations. |
| `docs/PHASE1_SECURITY_STABILITY_RUNBOOK.md` | `docs/operations/security-hardening-runbook.md` | Moved security hardening runbook into operations. |
| `docs/PHASE4_KPI_DEFINITIONS.md` | `docs/architecture/kpi-definitions.md` | Moved KPI definitions into architecture. |
| `docs/PHASE_2_IDENTITY_TENANCY_AUTHORIZATION.md` | `docs/architecture/identity-and-tenant-authorization.md` | Moved identity and tenant-authorization design into architecture. |
| `docs/PHASE_3_INVENTORY.md` | `docs/architecture/inventory-domain.md` | Moved inventory-domain notes into architecture. |
| `docs/PHASE_4A_END_TO_END.md` | `docs/architecture/sales-and-settlement.md` | Moved sales/settlement architecture notes into architecture. |
| `docs/PHASE_4B_ACCOUNTING_EFRIS.md` | `docs/architecture/accounting-and-efris.md` | Moved accounting/EFRIS architecture notes into architecture. |
| `docs/PHASE_5_ANALYTICS.md` | `docs/architecture/analytics-and-reporting.md` | Moved analytics/reporting notes into architecture. |
| `docs/PRODUCTION_SECURITY_CHANGE_029_2026-10-21.md` | `docs/operations/production-security-change-029-2026-10-21.md` | Moved dated production security notes into operations while retaining date provenance. |

## Files added to the canonical tree

| Path | Reason |
|---|---|
| `.editorconfig` | Added consistent editor defaults for indentation, final newlines, and text files. |
| `CONTRIBUTING.md` | Added repository-specific contribution and validation workflow guidance. |
| `SECURITY.md` | Added a security reporting and credential-handling policy. |
| `docs/development/source-archive-handling.md` | Promoted the archive-replacement safeguards into canonical developer docs. |
| `tests/test_canonical_repository_contract.py` | Added canonical-tree assertions so CI catches references to discarded overlay roots. |
| `tests/test_workspace_membership_contract.py` | Promoted workspace/membership contract checks into the canonical repository test suite. |
| `tests/workspace-tenant-acceptance.test.mjs` | Promoted tenant/workspace acceptance contract coverage into the canonical test tree. |
| `CLEANUP_REPORT.md` | This run report. |
| `RENAME_DELETE_MANIFEST.md` | This path-change manifest. |

## Important modifications in place

| Path | Change |
|---|---|
| `.github/workflows/lexa-ci.yml` | Path filters now target the retained `replace-from-archive.yml` workflow rather than the removed `lexa-zip-extract.yml` name. |
| `README.md` | Replaced an overlay-specific upload note with the canonical architecture, setup, tests, migrations, deployment and validation boundary guide. |
| `migrations/048_phase7_approval_limits_reversals_accounting.sql` | Corrected the supplier-payment journal to use its declared `a_cash` variable rather than undefined `v_cash`. |
| `migrations/README.md` | Reorganized migration policies and documented the migration 048 source correction without claiming production application or historical byte recovery. |
| `scripts/validate-package.sh` | Validation now targets `apps/api/app` and the retained canonical workspace acceptance test, not a deleted `overrides/` path. |
| `tests/test_workspace_domain.py` | Uses the canonical `apps/api/app/workspace_domain.py` module and asserts current required setup-progress inputs and steps. |
| `tests/unit/test_migration_source_integrity.py` | Uses the reorganized deployment guide/current replay-manifest size and includes a guard for the migration 048 cash-account variable. |
| `apps/api/tests/test_phase7_approval_reversal_accounting.py` | Updated regression coverage for purchasing approval/reversal accounting source contracts. |
| `apps/web/tests/lexa-language-overhaul.test.mjs` | Updated contract expectations to current user-facing language conventions. |
| `apps/web/tests/phase12-live-brand-visibility.test.mjs` | Updated brand/UI visibility source-contract assertions to the canonical selector. |
| `tests/test_phase4_6_completeness_contract.py` | Updated stale canonical-path/contract expectations. |
| `tests/unit/test_analytics_currency_contract.py` | Updated analytic currency contract check to current source behavior. |
| `tests/unit/test_deployment_audit.py` | Updated deployment audit assertions to the current checked-in configuration. |

## Removed duplicate project snapshots and alternate source roots

The following original top-level source directories were absent from the final canonical tree. Counts are original archive file entries, not generated reports or estimates:

| Removed directory | Files removed | Original uncompressed bytes | Reason |
|---|---:|---:|---|
| `source/` | 386 | 4,132,098 | Redundant snapshot, overlay, alternate source root, or obsolete exported project directory removed after canonical-root review. |
| `LEXA_PHASE4_UX_RESET_IMPLEMENTATION_2026-10-21/` | 278 | 3,089,448 | Redundant snapshot, overlay, alternate source root, or obsolete exported project directory removed after canonical-root review. |
| `LEXA-Phase1-2.9.1/` | 219 | 2,572,731 | Redundant snapshot, overlay, alternate source root, or obsolete exported project directory removed after canonical-root review. |
| `lexa_v280_src/` | 156 | 1,950,891 | Redundant snapshot, overlay, alternate source root, or obsolete exported project directory removed after canonical-root review. |
| `LEXA_Phase4B_Accounting_EFRIS_v2.3.0/` | 127 | 2,155,667 | Redundant snapshot, overlay, alternate source root, or obsolete exported project directory removed after canonical-root review. |
| `LEXA_Phase4A_EndToEnd_v2.1.0/` | 114 | 2,029,914 | Redundant snapshot, overlay, alternate source root, or obsolete exported project directory removed after canonical-root review. |
| `LEXA_Phase1_Business_Kernel_v1.7.0/` | 95 | 1,822,765 | Redundant snapshot, overlay, alternate source root, or obsolete exported project directory removed after canonical-root review. |
| `src/` | 79 | 1,437,850 | Redundant snapshot, overlay, alternate source root, or obsolete exported project directory removed after canonical-root review. |
| `LEXA_Open_Development_v1.5.0/` | 76 | 1,404,256 | Redundant snapshot, overlay, alternate source root, or obsolete exported project directory removed after canonical-root review. |
| `lexa-final/` | 75 | 1,399,742 | Redundant snapshot, overlay, alternate source root, or obsolete exported project directory removed after canonical-root review. |
| `LEXA_Phase2_Catalog_Hardening_v1.2.0/` | 66 | 320,842 | Redundant snapshot, overlay, alternate source root, or obsolete exported project directory removed after canonical-root review. |
| `LEXA_Phase3_Increments_01_06/` | 53 | 500,510 | Redundant snapshot, overlay, alternate source root, or obsolete exported project directory removed after canonical-root review. |
| `lexa_fix_audit/` | 52 | 135,513 | Redundant snapshot, overlay, alternate source root, or obsolete exported project directory removed after canonical-root review. |
| `LEXA_Phase0_to_Phase3_Increments_01_06_Closure_2026-10-20/` | 51 | 473,539 | Redundant snapshot, overlay, alternate source root, or obsolete exported project directory removed after canonical-root review. |
| `phase3-increments-01-03/` | 38 | 255,225 | Redundant snapshot, overlay, alternate source root, or obsolete exported project directory removed after canonical-root review. |
| `LEXA_Phase3_Increment_01/` | 32 | 173,962 | Redundant snapshot, overlay, alternate source root, or obsolete exported project directory removed after canonical-root review. |
| `overrides/` | 12 | 116,927 | Redundant snapshot, overlay, alternate source root, or obsolete exported project directory removed after canonical-root review. |
| `lexa-connectivity-hotfix/` | 10 | 105,114 | Redundant snapshot, overlay, alternate source root, or obsolete exported project directory removed after canonical-root review. |
| `phase0-2-evidence/` | 8 | 55,434 | Redundant snapshot, overlay, alternate source root, or obsolete exported project directory removed after canonical-root review. |
| `handoff/` | 7 | 111,464 | Redundant snapshot, overlay, alternate source root, or obsolete exported project directory removed after canonical-root review. |
| `reports/` | 5 | 22,609 | Redundant snapshot, overlay, alternate source root, or obsolete exported project directory removed after canonical-root review. |
| `artifacts/` | 3 | 20,773 | Redundant snapshot, overlay, alternate source root, or obsolete exported project directory removed after canonical-root review. |
| `incoming/` | 1 | 378 | Redundant snapshot, overlay, alternate source root, or obsolete exported project directory removed after canonical-root review. |

These directories contained competing snapshots/overlays rather than import roots referenced by the canonical app's runtime and deployment settings. Distinct, unreleased overlay changes were not merged into the app without evidence of release intent and safe behavior; see the risks section of `CLEANUP_REPORT.md`.

## Nested ZIP bundles removed

All 25 nested `.zip` files were removed from the source tree (their original total archive-entry size was 1,932,751 bytes). The deliverable is one source archive rather than a source archive containing further delivery archives.

- `LEXA_BRAND_AUTHORITY_UPLOAD.zip` — 323,326 bytes
- `LEXA_CI_FAILURE_FIX.zip` — 2,641 bytes
- `LEXA_CI_FIX_OVERLAY_2026-10-25.zip` — 5,467 bytes
- `LEXA_CI_REPAIR_UPLOAD_READY_2026-10-24.zip` — 14,556 bytes
- `LEXA_CLEAN_PROJECT.zip` — 853,737 bytes
- `LEXA_END_TO_END_AUDIT_PACK_2026-10-25.zip` — 5,298 bytes
- `LEXA_LOW_COST_CI_FIX_BUNDLE_2026-10-24.zip` — 5,928 bytes
- `LEXA_Migration_Reconciliation_2026-10-26.zip` — 66,870 bytes
- `LEXA_PHASE00_01_IMPLEMENTATION_OVERLAY_2026-10-25.zip` — 42,729 bytes
- `LEXA_PHASE0_AUDIT_2026-10-24.zip` — 11,424 bytes
- `LEXA_PHASE0_MASTER_BRAND_CI_REPAIR_2026-10-26.zip` — 1,897 bytes
- `LEXA_PHASE1_CRITICAL_JOURNEY_HANDOFF_2026-10-26.zip` — 5,647 bytes
- `LEXA_PHASE1_IMPLEMENTATION_2026-10-24.zip` — 27,690 bytes
- `LEXA_PHASE1_PHASE2_INTELLIGENCE_BUNDLE_2026-10-24.zip` — 54,471 bytes
- `LEXA_PHASE1_PRODUCT_AND_DATA_ENTRY_IMPLEMENTATION_2026-10-26.zip` — 43,155 bytes
- `LEXA_PHASE1_SOURCE_SYNC_VALIDATED_PATCH_BUNDLE_2026-10-26.zip` — 43,380 bytes
- `LEXA_PHASE4_5_6_ACCEPTANCE_COMPLETION_2026-10-25.zip` — 13,248 bytes
- `LEXA_PHASE7_DOWNLOAD_FOR_PHONE.zip` — 41,962 bytes
- `LEXA_PHASE7_FIX_PACKAGE_2026-10-25.zip` — 10,435 bytes
- `LEXA_PRODUCT_SETUP_PHASE2_IMPLEMENTATION_2026-10-26.zip` — 89,189 bytes
- `LEXA_Phase1_Generic_Inventory_Overlay.zip` — 22,218 bytes
- `LEXA_TRANSACTION_SPINE_TRACEABILITY_OVERLAY_2026-10-25.zip` — 46,728 bytes
- `LEXA_Traceability_Integration_Package_preprod_findings_2026-10-26.zip` — 78,582 bytes
- `LEXA_Traceability_Integration_Package_preprod_status.zip` — 62,482 bytes
- `LEXA_Traceability_Integration_Package_verified.zip` — 59,691 bytes

## Removed stale root-level reports, handoffs, and package exports

The following original root-level files were removed because they were dated phase/increment handoffs, historical audit snapshots, stale release status reports, package/patch manifests, or exported upload instructions rather than canonical source/configuration. Important runtime config, migration history/recovery evidence, CI, tests, and current operational docs were retained.

- `AUDIT_REPORT_v0.6.md`
- `AUTH_RLS_CONTEXT_FORENSIC_REPORT_2026-10-22.md`
- `BUNDLE_MANIFEST.json`
- `DEPLOYMENT_FIXES_2026-10-13.md`
- `DEPLOYMENT_REPAIR_AUDIT_v1.9.1.md`
- `FINAL_RELEASE_GATE_STATUS.md`
- `FIRST_INCREMENT_HANDOFF.md`
- `HOTFIX_APPLY.md`
- `LEXA_2.14.0_IMPLEMENTATION_HANDOFF_2026-10-22.md`
- `LEXA_AI_ROUTER_MANIFEST.json`
- `LEXA_BRAND_AUTHORITY_UPLOAD.zip`
- `LEXA_BRAND_AUTHORITY_UPLOAD_GUIDE.md`
- `LEXA_CI_FAILURE_FIX.zip`
- `LEXA_CI_FIX_OVERLAY_2026-10-25.zip`
- `LEXA_CI_REPAIR_UPLOAD_READY_2026-10-24.zip`
- `LEXA_CLEAN_PROJECT.zip`
- `LEXA_E2E_FORENSIC_AUDIT_2026-10-13.md`
- `LEXA_EMERALD_FUSION_BRAND_AND_UX_IMPLEMENTATION_2026-10-22.md`
- `LEXA_EMERALD_FUSION_BRAND_GUIDE_2026-10-22.md`
- `LEXA_END_TO_END_AUDIT_PACK_2026-10-25.zip`
- `LEXA_FINAL_NONBILLING_CLOSEOUT_2026-10-22.md`
- `LEXA_FINAL_NONBILLING_RELEASE_RECHECK_2026-10-22.md`
- `LEXA_FULL_BRAND_SYSTEM_UPLOAD_GUIDE.md`
- `LEXA_Integration_Repair_v1.7.1_NOTES.md`
- `LEXA_LANGUAGE_BUNDLE_MANIFEST.json`
- `LEXA_LIVE_BRAND_VISIBILITY_FIX_GUIDE.md`
- `LEXA_LIVE_REMEDIATION_VERIFICATION_2026-10-13.md`
- `LEXA_LOW_COST_CI_FIX_BUNDLE_2026-10-24.zip`
- `LEXA_Migration_Reconciliation_2026-10-26.zip`
- `LEXA_PACKAGE_MANIFEST.json`
- `LEXA_PHASE00_01_IMPLEMENTATION_OVERLAY_2026-10-25.zip`
- `LEXA_PHASE0_AUDIT_2026-10-24.zip`
- `LEXA_PHASE0_MASTER_BRAND_CI_REPAIR_2026-10-26.zip`
- `LEXA_PHASE1_CRITICAL_JOURNEY_HANDOFF_2026-10-26.zip`
- `LEXA_PHASE1_IMPLEMENTATION_2026-10-24.zip`
- `LEXA_PHASE1_PHASE2_INTELLIGENCE_BUNDLE_2026-10-24.zip`
- `LEXA_PHASE1_PRODUCT_AND_DATA_ENTRY_IMPLEMENTATION_2026-10-26.zip`
- `LEXA_PHASE1_SOURCE_SYNC_VALIDATED_PATCH_BUNDLE_2026-10-26.zip`
- `LEXA_PHASE4_5_6_ACCEPTANCE_COMPLETION_2026-10-25.zip`
- `LEXA_PHASE4_6_COMPLETENESS_MANIFEST_2026-10-21.json`
- `LEXA_PHASE4_8_CI_REPAIR_README.md`
- `LEXA_PHASE7_CANDIDATE_README.txt`
- `LEXA_PHASE7_DOWNLOAD_FOR_PHONE.zip`
- `LEXA_PHASE7_FIX_PACKAGE_2026-10-25.zip`
- `LEXA_PHASE7_LOGIN_UX_REPAIR_AUDIT_2026-10-22.md`
- `LEXA_PHASE7_TO_9_REAL_IMPLEMENTATION_HANDOFF_2026-10-23.md`
- `LEXA_PHASE7_TO_9_REAL_IMPLEMENTATION_MANIFEST_2026-10-23.json`
- `LEXA_PHASE8_IMPLEMENTATION_README.md`
- `LEXA_PHASE8_IMPLEMENTATION_REPORT_2026-10-22.md`
- `LEXA_PHASE8_REVISED_ARCHITECTURE_AND_IMPLEMENTATION_PLAN_2026-10-22.md`
- `LEXA_PRE_PHASE9_POLISH_IMPLEMENTATION_REPORT_2026-10-22.md`
- `LEXA_PRODUCT_SETUP_PHASE2_IMPLEMENTATION_2026-10-26.zip`
- `LEXA_Phase1_Generic_Inventory_Overlay.zip`
- `LEXA_STAGE1_5_LIVE_DEPLOYMENT_AUDIT_2026-10-22.md`
- `LEXA_STAGE2_3_IMPLEMENTATION_REPORT_2026-10-22.md`
- `LEXA_STAGE4_STAGE5_ACCEPTANCE_MANIFEST_2026-10-22.json`
- `LEXA_TRANSACTION_SPINE_TRACEABILITY_OVERLAY_2026-10-25.zip`
- `LEXA_Traceability_Integration_Package_preprod_findings_2026-10-26.zip`
- `LEXA_Traceability_Integration_Package_preprod_status.zip`
- `LEXA_Traceability_Integration_Package_verified.zip`
- `LEXA_UNIFIED_FRONTEND_PLAN_MANIFEST.json`
- `LEXA_UNIFIED_FRONTEND_PLAN_UPLOAD_GUIDE.md`
- `MANUAL_PUSH_INSTRUCTIONS.md`
- `MASTER_INDEX.md`
- `NEXT_PHASE_PLAN.md`
- `PACKAGE_FILE_SHA256SUMS.txt`
- `PATCH_MANIFEST.json`
- `PHASE0_1_2_ORIGIN_FORENSICS.md`
- `PHASE1_DATABASE_EVIDENCE.md`
- `PHASE1_REMAINING_WORK.md`
- `PHASE1_VALIDATION.md`
- `PHASE1_ZIP_README.md`
- `PHASE2_COMPONENT_MAP_02.md`
- `PHASE2_FORENSIC_AUDIT_2026-10-20.md`
- `PHASE2_INCREMENT_01_REPORT.md`
- `PHASE2_INCREMENT_02_MANIFEST.json`
- `PHASE2_INCREMENT_02_REPORT.md`
- `PHASE2_INCREMENT_03_REPORT.md`
- `PHASE2_INCREMENT_04_MANIFEST.json`
- `PHASE2_INCREMENT_05_IMPLEMENTATION_REPORT_2026-10-23.md`
- `PHASE2_INCREMENT_05_MANIFEST.json`
- `PHASE2_INCREMENT_06_MANIFEST.json`
- `PHASE2_INCREMENT_07_MANIFEST.json`
- `PHASE2_ONWARD_HANDOFF.md`
- `PHASE2_ROUTE_INVENTORY_01.md`
- `PHASE2_STAGING_ACCEPTANCE.md`
- `PHASE3_INCREMENT_01_MANIFEST.json`
- `PHASE3_URA_AND_MOBILE_MONEY_INTEGRATION_GATES.md`
- `PHASE4_6_COMPLETENESS_ACCEPTANCE_MATRIX_2026-10-21.md`
- `PHASE4_6_COMPLETENESS_IMPLEMENTATION_REPORT_2026-10-21.md`
- `PHASE4_8_RELEASE_AUDIT_2026-10-25.md`
- `PHASE4_CLOSEOUT_STATUS_2026-10-21.json`
- `PHASE4_IMPLEMENTATION_REPORT_2026-10-21.md`
- `PHASE4_UPLOAD_README.md`
- `PHASE5_ACCEPTANCE_REPAIR_UPLOAD_README.md`
- `PHASE5_CORE_HARDENING_REPORT_2026-10-21.md`
- `PHASE5_FINAL_GATE_REPORT_2026-10-21.md`
- `PHASE5_INCREMENT_02_FULL_SOURCE_CANDIDATE_STATUS.md`
- `PHASE5_INCREMENT_03_ACCEPTANCE_MATRIX.md`
- `PHASE5_INCREMENT_03_IMPLEMENTATION_REPORT_2026-10-21.md`
- `PHASE5_INCREMENT_03_README_2026-10-21.md`
- `PHASE5_RELEASE_GATE_STATUS_2026-10-21.json`
- `PHASE5_REPAIR_README_2026-10-21.md`
- `PHASE6_ACCEPTANCE_MATRIX.md`
- `PHASE6_ENTRY_POLICY.md`
- `PHASE6_IMPLEMENTATION_REPORT_2026-10-21.md`
- `PHASE6_RELEASE_GATE_STATUS_2026-10-21.json`
- `PHASE6_TO_PHASE9_ACCEPTANCE_MATRIX_2026-10-23.md`
- `PHASE6_TO_PHASE9_IMPLEMENTATION_REPORT_2026-10-23.md`
- `PHASE7_ACCEPTANCE_MATRIX.md`
- `PHASE7_CI_AND_RELEASE_UNBLOCK_CHECKLIST_2026-10-22.md`
- `PHASE7_DEEP_AUDIT_ACCEPTANCE_REPORT_2026-10-22.md`
- `PHASE7_FINALIZATION_RELEASE_GATE_STATUS_2026-10-22.json`
- `PHASE7_IMPLEMENTATION_REPORT_2026-10-21.md`
- `PHASE7_INCREMENT_02_FINALIZATION_REPORT_2026-10-22.md`
- `PHASE7_INCREMENT_03_RELEASE_GATE_STATUS_2026-10-22.json`
- `PHASE7_PURCHASING_AUTHORIZATION_README.md`
- `PHASE7_RELEASE_GATE_STATUS_2026-10-21.json`
- `PHASE7_REMOTE_REPLAY_EVIDENCE_2026-10-22.json`
- `PHASE8_IMPLEMENTATION_REPORT_2026-10-22.md`
- `PHONE_UPLOAD_GUIDE.md`
- `README_AI_ROUTER.md`
- `README_APPLY_AUTH_RLS_HOTFIX.md`
- `README_FIX_PACKAGE.md`
- `README_LANGUAGE_OVERHAUL.md`
- `README_LEXA_AI_INTELLIGENCE_REPAIR.md`
- `RELEASE.txt`
- `RELEASE_NOTES_2.1.0.md`
- `RELEASE_NOTES_2.10.0_PHASE6_INCREMENT_01.md`
- `RELEASE_NOTES_2.11.0_PHASE4_6_COMPLETENESS.md`
- `RELEASE_NOTES_2.12.0_PHASE7_INCREMENT_01.md`
- `RELEASE_NOTES_2.12.0_PHASE7_INCREMENT_02.md`
- `RELEASE_NOTES_2.12.0_PHASE7_INCREMENT_03.md`
- `RELEASE_NOTES_2.2.0.md`
- `RELEASE_NOTES_2.3.0.md`
- `RELEASE_NOTES_2.4.0.md`
- `RELEASE_NOTES_2.5.0.md`
- `RELEASE_NOTES_2.5.1.md`
- `RELEASE_NOTES_2.6.0.md`
- `RELEASE_NOTES_2.7.0.md`
- `RELEASE_NOTES_2.8.0.md`
- `RELEASE_NOTES_2.8.1_FRONTEND_BUILD_REPAIR.md`
- `RELEASE_NOTES_2.8.2_PHASE0_RELIABILITY.md`
- `RELEASE_NOTES_2.8.4_PHASE0_AUTH_RLS_HARDENING.md`
- `RELEASE_NOTES_2.8.5_E2E_AUTH_READINESS.md`
- `RELEASE_NOTES_2.8.6_PHASE0_CANDIDATE.md`
- `RELEASE_NOTES_2.8.7_PHASE0_FINAL_HANDOFF.md`
- `RELEASE_NOTES_2.9.1_PHASE1_SECURITY_STABILITY.md`
- `RELEASE_NOTES_2.9.2_PHASE5_INCREMENT_03.md`
- `RUN_40114334149_FORENSICS.md`
- `SHA256SUMS.txt`
- `SOURCE_ARCHIVE_COMPARISON.md`
- `STAGE4_STAGE5_REPORTING_AND_ACCEPTANCE.md`
- `START_HERE.md`
- `TEST_RESULTS.txt`
- `VALIDATION_RESULTS.json`
- `VALIDATION_RESULTS.md`

## Removed stale files from the old `docs/` root

Useful documentation was moved into the architecture, operations, product, and testing folders above. These remaining files at the old docs root were historical reports, old overlay/workflow source blobs, or superseded handoffs; they were removed after the useful current docs were retained or reorganized.

- `docs/ACCEPTANCE_MATRIX.md`
- `docs/FRESH_NEW_PRODUCT_STRATEGY.md`
- `docs/IMPLEMENTATION_REPORT.md`
- `docs/LEXA_AI_MODEL_REGISTRY_SOURCE.py`
- `docs/LEXA_AI_MODEL_REGISTRY_TESTS.py`
- `docs/LEXA_AI_ROUTER_WORKFLOW.yml`
- `docs/LEXA_BUSINESS_LANGUAGE_AUDIT_TEST.mjs`
- `docs/LEXA_CI_40064896058_ROOT_CAUSE_AND_PHASE4_2026-10-24.md`
- `docs/LEXA_CI_ROOT_CAUSES_AND_PHASE1_3_VALIDATION_2026-10-24.md`
- `docs/LEXA_FIRST_INCREMENT_IMPLEMENTATION_REPORT_2026-10-19.md`
- `docs/LEXA_IMPLEMENTATION_EXECUTION_PLAN_2026-10-23.md`
- `docs/LEXA_International_Research_Phase3.md`
- `docs/LEXA_LANGUAGE_OVERHAUL_WORKFLOW.yml`
- `docs/LEXA_LIVE_INTEGRATION_v1.8.1.md`
- `docs/LEXA_OPEN_DEVELOPMENT_MODE_v1.5.1.md`
- `docs/LEXA_STATEMENT_OF_TRUTH_2026-10-19.md`
- `docs/MAIN_BRANCH_APPLY_STEPS.md`
- `docs/MANUAL_DEPLOY_v2.5.0.md`
- `docs/MIGRATION_SOURCE_LOSS_ACCEPTANCE_2026-10-21.md`
- `docs/PHASE0_2_CLOSURE_AUDIT_2026-10-20.md`
- `docs/PHASE0_2_FINAL_READINESS_AUDIT_2026-10-20.md`
- `docs/PHASE0_2_REMAINING_GATE_REGISTER_2026-10-20.md`
- `docs/PHASE0_2_TABLE_ACCESS_DESIGN_2026-10-20.md`
- `docs/PHASE0_IMPLEMENTATION_REPORT.md`
- `docs/PHASE0_TO_PHASE2_HANDOFF_2026-10-23.md`
- `docs/PHASE0_TO_PHASE2_IMPLEMENTATION_STATUS_2026-10-23.md`
- `docs/PHASE1_SECURITY_STABILITY_REPORT_2026-10-19.md`
- `docs/PHASE1_UX_IMPLEMENTATION_REPORT.md`
- `docs/PHASE1_UX_RUNBOOK.md`
- `docs/PHASE2_PLATFORM_RELEASE_GATE.md`
- `docs/PHASE3_CLOSEOUT_VALIDATION_2026-10-21.md`
- `docs/PHASE3_ENTRY_CHECKLIST.md`
- `docs/PHASE3_SECURITY_AUDIT_AND_IMPLEMENTATION_REPORT_2026-10-23.md`
- `docs/PHASE3_TO_PHASE5_HANDOFF_2026-10-23.md`
- `docs/PHASE3_WRITE_PATH_PATCH_2026-10-21.md`
- `docs/PHASE4_6_STRATEGY_COVERAGE_2026-10-21.md`
- `docs/PHASE4_CLOSEOUT_REPORT_2026-10-21.md`
- `docs/PHASE4_OVERLAY_MANIFEST.json`
- `docs/PHASE4_OVERLAY_README.md`
- `docs/PHASE4_RELEASE_ACCEPTANCE_MATRIX.md`
- `docs/PHASE4_SOURCE_RECONCILIATION_2026-10-21.md`
- `docs/PHASE4_UX_RESET_IMPLEMENTATION.md`
- `docs/PHASE5_ACCEPTANCE_MATRIX_2026-10-21.md`
- `docs/PHASE5_ENTRY_BRIEF.md`
- `docs/PHASE5_IMPLEMENTATION_REPORT_2026-10-21.md`
- `docs/PHASE5_INCREMENT_02_ACCEPTANCE_MATRIX.md`
- `docs/PHASE5_INCREMENT_02_IMPLEMENTATION_REPORT_2026-10-21.md`
- `docs/PHASE5_INCREMENT_02_README.md`
- `docs/PHASE5_INCREMENT_02_SOURCE_MANIFEST.json`
- `docs/PHASE5_OVERLAY_README.md`
- `docs/PHASE5_SOURCE_MANIFEST.json`
- `docs/PHASE5_STAGING_ACCEPTANCE_FIXTURE.example.json`
- `docs/PHASE6_7_IMPLEMENTATION_CLOSEOUT_2026-10-23.md`
- `docs/PHASE6_RUNBOOK.md`
- `docs/PHASE6_STAGING_ACCEPTANCE_FIXTURE.example.json`
- `docs/PHASE7_BRANCH_SCOPE_FIXTURE.example.json`
- `docs/PHASE7_STRATEGY_COVERAGE_2026-10-21.md`
- `docs/PHASE_0_RECOVERY.md`
- `docs/PHASE_0_VERIFICATION_REPORT.md`
- `docs/PHASE_1.md`
- `docs/PHASE_1_5_PRODUCTION_READINESS_REPAIR.md`
- `docs/PHASE_1_BUSINESS_KERNEL.md`
- `docs/PHASE_1_NEON_STATUS.md`
- `docs/PHASE_2_AUTH_HARDENING_STATUS.md`
- `docs/PHASE_2_CATALOG.md`
- `docs/PHASE_2_CATALOG_STATUS.md`
- `docs/PHASE_2_UNIVERSAL_BUSINESS_ENGINE.md`
- `docs/PHASE_2_VALIDATION_REPORT.md`
- `docs/PHASE_3_5_WORKSPACE_CONVERGENCE.md`
- `docs/PHASE_3_UI_UX_IMPLEMENTATION.md`

## Workflow and script removals

- `.github/workflows/lexa-ai-router-build.yml` — removed an obsolete source-mutating workflow that operated from documentation/patch artifacts; the canonical CI workflow remains.
- `scripts/lexa_apply_ai_router.py` and `scripts/lexa_apply_business_language.py` — removed source patch appliers for the inactive overlay workflows.
- `scripts/package_phase2_zip.py` and `scripts/package_phase4_6_completeness.py` — removed one-off packaging scripts for historical bundles.
- `scripts/apply_deployment_repairs.py` and `scripts/cleanup-obsolete-frontend-routes.sh` — removed stale repair/cleanup utilities after checking the canonical app and workflow references.
- `docs/LEXA_AI_MODEL_REGISTRY_SOURCE.py`, `docs/LEXA_AI_MODEL_REGISTRY_TESTS.py`, `docs/LEXA_AI_ROUTER_WORKFLOW.yml`, `docs/LEXA_LANGUAGE_OVERHAUL_WORKFLOW.yml`, `docs/LEXA_BUSINESS_LANGUAGE_AUDIT_TEST.mjs`, `README_AI_ROUTER.md`, and `README_LANGUAGE_OVERHAUL.md` — removed doc-stored source/workflow artifacts tied to the inactive patch process.
- Redundant generated manifests/checksums/release pointer files (`*_MANIFEST.json`, `PATCH_MANIFEST.json`, `PACKAGE_FILE_SHA256SUMS.txt`, `SHA256SUMS.txt`, and `RELEASE.txt`) were removed when they described a bundle rather than canonical runtime configuration. Migration source manifests and recovery/ledger evidence remain under `migrations/`.

## Generated/cache/dependency exclusions

Caches, `.pyc`/`.pyo`, TypeScript build info, `.next`, coverage/test output, dependency directories, `.git` history, OS metadata, and nested archives are excluded from the final archive. No real `.env` file was found; `.env.example` remains. Applied migration filenames/order and recovery metadata were retained.
