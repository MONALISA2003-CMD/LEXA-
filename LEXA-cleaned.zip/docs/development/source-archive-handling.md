# Source archive handling

The repository workflow `.github/workflows/replace-from-archive.yml` replaces the full repository tree from a verified ZIP asset. It does not extract arbitrary uploaded archives automatically, and uploading a ZIP in chat does not grant GitHub write access.

## Required safeguards

- Create the ZIP from the intended repository root; archive paths should begin with `apps/`, `migrations/`, `docs/`, and other canonical top-level folders, not a duplicate wrapper directory.
- Publish the exact ZIP as a GitHub Release asset over HTTPS.
- Compute the SHA-256 checksum of that exact asset and provide the target branch's full expected 40-character commit SHA.
- Explicitly select `REPLACE_ALL_FILES`; the default `NO` confirmation intentionally refuses replacement.
- Prefer `pull_request` mode. Review the complete diff and CI result before merging.
- Keep credentials, `.git`, `node_modules`, caches, generated build output, nested ZIPs, and production data out of the archive.

The workflow verifies the checksum and branch head, creates a pre-replacement backup artifact, validates the archive, and produces a reviewable change. Because full-tree replacement is destructive, do not use it to bypass normal code review or branch protection.
