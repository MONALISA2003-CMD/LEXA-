# Database migrations

This directory is the canonical SQL migration sequence for LEXA. Existing migration filenames and sequence prefixes are immutable source identifiers and must not be renamed during repository cleanup.

## Key files

- Numbered `.sql` files: forward schema changes.
- `SOURCE_RECOVERY.md`: migration source lineage and recovery rules.
- `source_gaps.json`, `migration_dispositions.json`, `reconstructed_source_manifest.json`: migration-source provenance and disposition metadata.
- `reconstructed/`: explicitly labelled equivalents, repairs and replay-only compatibility candidates. These files are not automatically executable production migrations.
- `live_ledger_snapshot_*.json`: historical migration-ledger observations; check their dates and target database before using them as evidence.

## Safe workflow

1. Inspect the target database migration ledger.
2. Review the exact SQL file diff and its provenance.
3. Replay the whole chain in an isolated disposable PostgreSQL database.
4. Validate row-level security, tenant isolation, indexes, constraints and grants.
5. Require independent review and a documented forward/rollback plan before a hosted schema change.

Run `python scripts/check_migration_sources.py` for local source consistency. A remote database is not changed by this repository check.
