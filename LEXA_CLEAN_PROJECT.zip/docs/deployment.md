# Deployment and operations

## Architecture

- **Web:** Next.js application in `apps/web`, deployed to Vercel.
- **API:** FastAPI application in `apps/api`, deployed as a Render web service.
- **Database:** PostgreSQL is the transactional source of truth; the project uses Neon.
- **Cache/queue:** Render Key Value/Valkey or another configured Redis-compatible service.

Do not create a parallel business database on Render when Neon is the configured PostgreSQL source of truth.

## Render API service

Use the repository root for the Render Blueprint (`render.yaml`). The API service uses `apps/api`, installs `requirements.txt`, and starts with `uvicorn app.main:app --host 0.0.0.0 --port $PORT`.

Configure the health-check path as `/ready`. `/health` is process liveness only; `GET /ready` checks database identity/schema/auth readiness and the configured Redis-compatible dependency. Readiness must fail closed when the selected database is not the approved canonical branch or required schema/security contracts are incomplete.

Set every secret and every `sync: false` variable in Render's environment settings. Configure the database application role only after the selected database branch has that role and its required grants.

## Vercel web application

Create the Vercel project from the same repository and set the root directory to `apps/web`. Use the Next.js preset and lockfile-pinned dependencies. The API origin must be server-side `LEXA_API_URL`; browser requests use the same-origin `/api/lexa/*` proxy. Do not add a public API-origin fallback that might allow a Preview deployment to connect to production unintentionally.

Set `LEXA_API_URL` to the intended Render API HTTPS origin. Set `LEXA_PROXY_SHARED_SECRET` in Vercel and Render to the same randomly generated value (at least 32 characters), keeping it server-only. Add the required Vercel origins to Render's `CORS_ORIGINS`. If account recovery is enabled, configure the approved email provider, sender identity and trusted public application URL before enabling reset links.

## Safe deployment order

1. Review and merge the intended source diff.
2. Configure the API environment and Redis-compatible service.
3. Point the API to the correct PostgreSQL branch and verify the migration ledger.
4. Deploy the API; verify `/health` and `/ready` separately.
5. Configure Vercel's `apps/web` root and server-side API origin.
6. Configure matching proxy shared secrets and the intended CORS origins.
7. Deploy the web app, then perform authenticated smoke tests against the intended environment.
8. Run dedicated staging journeys with non-production accounts and disposable fixtures before releasing.
9. Prepare an explicit database rollout and recovery plan for schema changes; never rely on a successful frontend build as evidence of database readiness.

## Secrets and network trust

Never commit database URLs, Redis URLs, JWT secrets, email-provider keys, proxy shared secrets or authentication state. Do not store authenticated Playwright state in source control. Only trust forwarded client-IP headers when the configured trusted-proxy mechanism validates the shared secret; never trust client-supplied forwarding headers on their own.

## Runtime probes

- `GET /health`: process liveness, independent of external dependencies.
- `GET /api/health`: compatibility alias for liveness.
- `GET /ready`: dependency-aware API readiness.
- `GET /api/ready`: compatibility alias for readiness.

A live process is not necessarily ready to serve business requests. A successful archive check or local test run is not proof of a live deployment or a production database change.
