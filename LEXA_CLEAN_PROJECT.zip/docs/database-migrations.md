# Database and migration policy

## Canonical source

The ordered SQL migration chain is maintained in `migrations/`. Migration provenance, recovered-source metadata and reconstructed candidates are recorded beside it. Review `migrations/SOURCE_RECOVERY.md`, `migrations/source_gaps.json`, `migrations/migration_dispositions.json` and the other manifest files before changing database history.

## Naming and immutability

Migration sequence prefixes and existing migration filenames are intentionally preserved, even where a historical filename contains an old phase label. Once a migration has been applied or referenced by a ledger, renaming it can cause checksum/ledger mismatch and duplicate execution. New migrations should use the next required sequence plus a concise business description; do not edit or rename an already-released migration as a cleanup operation.

## Validation policy

- Review every SQL diff.
- Use a fresh disposable PostgreSQL database for complete replay checks.
- Verify tenant constraints, row-level security, grants and foreign keys in addition to successful SQL execution.
- Run `python scripts/check_migration_sources.py` for source-disposition checks.
- Run `python scripts/check_migration_replay_evidence.py --evidence artifacts/migration-replay-evidence.json --expected-commit <full-commit-sha>` only when the evidence artifact is current for that exact commit and migration bundle.
- Do not apply reconstructed, equivalent or replay-only SQL to production without a formally reviewed, explicit forward-migration plan and approval.

The existing migration sequence is preserved in this cleanup. This package does not change any database schema or claim to have validated the live database.
