# Security and tenant isolation

LEXA serves multiple business workspaces. Every user-controlled object reference must be checked against the active tenant and the user's permissions. A client-supplied tenant identifier, category, price list, branch, warehouse, location, product or variant is not trusted simply because it is syntactically valid.

## Required controls

- Authenticate requests before accessing private business records.
- Resolve active workspace context on the server and fail closed when it is absent or invalid.
- Apply permission checks at each API operation, not just in navigation.
- Use tenant-scoped reads and writes and PostgreSQL row-level security where configured.
- Establish database context transaction-locally so pooled connections do not leak tenant/user state between requests.
- Validate foreign references in the same tenant and enforce uniqueness in the database where possible.
- Keep bearer tokens and invitation secrets out of logs, audit payloads and database plaintext fields.
- Make retries and duplicate submissions safe for mutating operations when idempotency support exists.

## Testing

Changes affecting authorization should include negative tests for cross-tenant identifiers, inactive memberships, invalid branch/location scope, missing permissions and failed retries. Test both the API checks and database policies.

## Migrations

Historical migration files and provenance records must not be renamed or silently replaced. Reconstructed or replay-only SQL is evidence for controlled validation, not permission to execute it against a live database.
