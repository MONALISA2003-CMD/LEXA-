# Architecture

LEXA is organized as a single repository with independently deployed web and API applications sharing one PostgreSQL data model.

## Runtime components

- **Web:** Next.js App Router and React, located in `apps/web/`. Vercel configuration lives beside the web app.
- **API:** FastAPI, Pydantic and SQLAlchemy in `apps/api/`. The service is deployed with the root `render.yaml` configuration.
- **Database:** PostgreSQL, with Neon as the configured hosted platform. The existing database remains the single transactional system of record.
- **Cache and rate limits:** Redis-compatible cache where configured.
- **Schema:** SQL migration files under `migrations/`; API models and route validation must remain compatible with these records.

## Data flow

The browser calls the API through the shared client in `apps/web/lib/api.ts`. API endpoints authenticate the user, resolve active workspace context, enforce permissions and use tenant-scoped database access. Database-level row-level security is an additional isolation layer, not a replacement for API authorization.

## Core boundaries

1. Product records and variant definitions belong to the catalogue domain.
2. Stock changes belong to inventory transactions and balances; product setup must not manufacture opening stock.
3. Sales and returns use their existing business transaction paths and tax/accounting controls.
4. Draft or preview data must not be confused with live, saleable records.
5. Any cross-domain change must update contracts and tests at both API and frontend boundaries.

## Source-of-truth rules

The canonical application code is under `apps/`; the canonical migration ledger source is under `migrations/`. Full copies of the project, ad-hoc patches and old build output are not alternative sources of truth.
