# Development guide

## Prerequisites

- Node.js 24 for the web application and its tests.
- Python 3.12 or newer for the API and source verification tools.
- PostgreSQL for database integration tests.
- Redis for the complete API suite.

## Environment

Copy `.env.example` to a local, untracked environment file and supply local credentials. Never commit access tokens, real database URLs, user data, Playwright storage state or production secrets. Use a disposable test database for migration tests.

## Run the web app

```bash
cd apps/web
npm ci
npm run dev
```

Useful checks: `npm test`, `npm run typecheck`, and `npm run build`. Playwright acceptance suites require explicitly configured staging URLs, a test fixture, and an authorized test account. They should not write to production.

## Run the API

```bash
python -m pip install -e 'apps/api[dev]'
export PYTHONPATH=apps/api
export APP_ENV=development
export DATABASE_URL='postgresql+psycopg://user:password@localhost:5432/lexa_dev'
export REDIS_URL='redis://localhost:6379/0'
export JWT_SECRET='replace-with-a-local-development-secret'
uvicorn app.main:app --reload --app-dir apps/api
```

## Run tests

```bash
python -m compileall -q apps/api scripts tests
PYTHONPATH=apps/api python -m pytest -q tests apps/api/tests
node --test apps/web/tests/*.test.mjs
(cd apps/web && npm run typecheck && npm test && npm run build)
```

The full API suite should run with the declared test dependencies, PostgreSQL and Redis available. A partial local test run must be described as partial.

## Code organization

Use descriptive filenames for new modules and tests based on the business capability or behaviour under test. Do not add repository snapshots, dated implementation handoffs or temporary patch overlays to the root.
