# Repository maintenance and full-source replacement

## Structure rules

- Keep one canonical application tree under `apps/`.
- Do not commit ZIPs containing the full repository into the repository root. Store distributable source packages as release assets or workflow artifacts.
- Do not keep nested full project snapshots, temporary overlays, dated handoff reports or superseded implementation narratives in the main branch.
- Keep durable architecture, development, deployment, security, product and migration guidance in `docs/`.
- Use descriptive filenames based on business capabilities. The existing migration filenames are an intentional exception because they are part of database history.

## Replacement workflow

The replacement workflow is manual only and defaults to creating a pull request. It requires a trusted HTTPS archive URL, archive SHA-256, expected current commit SHA and explicit confirmation. It validates archive paths and required application markers, preserves `.git`, records a pre-replacement source archive as a workflow artifact, and does not force-push.

Bootstrap instructions: add `scripts/replace_from_archive.py` and `.github/workflows/replace-from-archive.yml` from the clean source package to the current repository first. Upload `LEXA_CLEAN_PROJECT.zip` as a GitHub Release asset (or another trusted HTTPS asset). Run the workflow from the intended target branch, provide the release asset URL and checksum, and set the expected SHA to the exact current branch head. Review and merge the generated pull request.

For a protected `main` branch, keep pull-request mode. Direct-push mode is optional and should be used only where repository policy explicitly allows it. GitHub must have `contents: write` and `pull-requests: write` for the default PR flow.
