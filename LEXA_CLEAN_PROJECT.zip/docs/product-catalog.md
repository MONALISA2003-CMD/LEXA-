# Product catalogue and Product Setup principles

This document records stable domain rules for catalogue work. It is not a claim that every planned control is already implemented.

## Catalogue model

- A product represents a product family or single sellable item. Variants are the individually sellable configurations, such as a size/color combination.
- SKU is editable during setup but must be generated or validated server-side and be unique within the correct tenant scope.
- Barcodes and manufacturer identifiers must be validated server-side and must follow the actual uniqueness policy in the schema.
- Attribute definitions and attribute values are separate from generated variant records. Variant generation should preview combinations, detect duplicates and allow excluded combinations.
- Category defaults may prefill allowed settings but must not silently override explicit product choices.

## Commercial rules

- Require a valid selling price for every saleable variant before final creation. Validation belongs in both the UI and API.
- Distinguish selling price, purchase cost and inventory valuation method. Expose only costing methods the existing valuation engine supports.
- Tax classification may be optional during product setup only if the sales-posting path blocks transactions that require a missing or invalid classification.
- Use existing currencies, price lists, rounding and decimal precision policies; do not add a parallel pricing model.

## Inventory rules

- Product creation must not create opening stock or an inventory valuation balance. Opening stock remains an explicit inventory transaction.
- Quantity, serial/IMEI and batch/lot/expiry tracking are policies that must be enforced by applicable receipt, transfer, sale, return and adjustment operations.
- Serialised units require unique individual identifiers. Lot-tracked stock must retain lot and expiry data where required.
- Changing a tracking policy on a product with stock requires a safe conversion or migration workflow.

## Setup experience

The approved experience is a five-step wizard: product identity; SKU/identifiers/variants; inventory tracking; pricing/costing/replenishment; review and save. Drafts should be offered only if the backend can persist and enforce draft state safely. Duplicate submissions must not create duplicate or partial records.

## Implementation acceptance

Test product creation through the same API used by the UI. Cover single products, manual variants, attribute-generated combinations, prices, duplicate identifiers, tenant isolation, supported costing/tracking, downstream tax enforcement and the separation between product creation and stock receipts. Keep unsupported capabilities hidden or clearly marked as unavailable.
