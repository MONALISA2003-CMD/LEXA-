from datetime import datetime, timedelta, timezone
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
API_ROOT = ROOT / "apps" / "api"
if str(API_ROOT) not in sys.path:
    sys.path.insert(0, str(API_ROOT))

from app.workspace_domain import (  # noqa: E402
    invitation_is_expired, invitation_token_digest, normalize_branch_ids, setup_progress,
)

def test_setup_progress_resumes_at_first_incomplete_required_setting():
    result = setup_progress(profile_exists=True, branch_count=1, warehouse_count=0, location_count=0, currency_configured=True)
    assert result["status"] == "IN_PROGRESS"
    assert result["resume_path"] == "/administration"
    assert result["completed_required_steps"] == 3
    assert result["required_steps"] == 7
    assert [s["key"] for s in result["steps"] if s["required"] and not s["complete"]][0] == "warehouse"

def test_setup_progress_is_complete_only_when_all_required_resources_exist():
    result = setup_progress(profile_exists=True, branch_count=1, warehouse_count=1, location_count=1, currency_configured=True, payment_method_count=1, accounting_account_count=1, accounting_mapping_count=1)
    assert result["complete"] is True
    assert result["status"] == "COMPLETE"
    assert result["resume_path"] == "/"

def test_setup_progress_does_not_use_a_client_supplied_completion_flag():
    result = setup_progress(profile_exists=False, branch_count=20, warehouse_count=20, location_count=20, currency_configured=True, payment_method_count=20, accounting_account_count=20, accounting_mapping_count=20)
    assert result["complete"] is False
    assert result["resume_path"] == "/administration"

def test_invitation_tokens_are_stored_as_one_way_sha256_digests():
    token = "a-very-long-random-token-for-test-only"
    digest = invitation_token_digest(token)
    assert len(digest) == 64 and digest != token
    assert digest == invitation_token_digest(token)
    assert digest != invitation_token_digest("a-different-random-token-for-test-only")

def test_invitation_expiry_boundary_is_closed_and_naive_values_are_utc():
    now = datetime(2026, 10, 20, 9, tzinfo=timezone.utc)
    assert invitation_is_expired(now, now)
    assert not invitation_is_expired(now + timedelta(seconds=1), now)
    assert invitation_is_expired(now - timedelta(seconds=1), now)
    assert invitation_is_expired(datetime(2026, 10, 20, 8), now)

def test_branch_ids_are_deduplicated_without_mutating_values():
    assert normalize_branch_ids(["b", "a", "b", "c"]) == ["b", "a", "c"]
