from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]


def test_canonical_application_and_ci_paths_exist():
    assert (ROOT / "apps/web/package.json").is_file()
    assert (ROOT / "apps/api/app/main.py").is_file()
    assert (ROOT / ".github/workflows/ci.yml").is_file()
    assert (ROOT / ".github/workflows/replace-from-archive.yml").is_file()
    assert (ROOT / "migrations/README.md").is_file()
    assert (ROOT / "docs/deployment.md").is_file()
    assert not (ROOT / "apps/web/components/module-foundation.tsx").exists()


def test_repository_does_not_contain_nested_full_project_snapshots():
    for name in ("source", "src", "lexa-final", "lexa_fix_audit", "lexa_v280_src", "LEXA-Phase1-2.9.1", "LEXA_PHASE4_UX_RESET_IMPLEMENTATION_2026-10-21", "overrides"):
        assert not (ROOT / name).exists(), f"stale duplicate tree remains: {name}"


def test_active_filenames_use_capability_names_not_historical_phase_names():
    for path in ROOT.rglob("*"):
        if not path.is_file() or "migrations" in path.parts or ".git" in path.parts:
            continue
        assert not re.search(r"(?:phase|stage|increment)[-_ ]?\d+", path.name, re.I), str(path.relative_to(ROOT))


def test_replacement_workflow_is_manual_and_guarded():
    workflow = (ROOT / ".github/workflows/replace-from-archive.yml").read_text()
    assert "workflow_dispatch:" in workflow
    assert "archive_sha256" in workflow
    assert "expected_head_sha" in workflow
    assert "REPLACE_ALL_FILES" in workflow
    assert "pull_request" in workflow
    assert "on: push" not in workflow


def test_historical_migration_identifiers_and_source_gaps_are_preserved():
    for name in ("027_release_convergence.sql", "030_phase3_workspace_memberships.sql", "044_phase3_password_reset_security.sql"):
        assert (ROOT / "migrations" / name).is_file()
    for name in (
        "010_phase2_catalog_intelligence.sql", "011_phase2_catalog_runtime_constraints.sql",
        "023_phase4_purchasing_core.sql", "024_phase4_purchasing_security.sql",
        "025_phase4_purchasing_permissions.sql", "026_phase4_membership_branch_integrity.sql",
    ):
        assert not (ROOT / "migrations" / name).exists()
