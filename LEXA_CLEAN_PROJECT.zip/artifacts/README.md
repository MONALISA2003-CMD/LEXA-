# Generated evidence

Replay and CI-gate evidence is generated for the exact source commit by the guarded workflows. Do not commit old generated evidence here: a historical result cannot certify a later source revision. Workflow artifacts retain the evidence and checksums for review.
