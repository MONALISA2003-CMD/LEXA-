# LEXA web application

The customer-facing web experience is a Next.js App Router application built with React. It uses the shared API client in `lib/api.ts` and the shared application shell in `components/app-shell.tsx`.

## Commands

- `npm ci` — install the lockfile-pinned dependencies.
- `npm run dev` — start local development.
- `npm test` — run frontend contract tests.
- `npm run typecheck` — run TypeScript checks.
- `npm run build` — create the production build.

Playwright acceptance tests require an explicitly configured staging environment and test credentials. Do not run write-enabled acceptance tests against production.
