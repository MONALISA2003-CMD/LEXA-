# Browser acceptance tests

These Playwright suites verify cross-page user journeys against a configured browser base URL. The default configuration must not be used to create test data in production. Write-enabled journeys require explicit staging allow-list configuration, a dedicated fixture and an authenticated test account.

Run with `npm run test:e2e`; use the focused scripts `npm run test:e2e:sales`, `npm run test:e2e:purchasing` or `npm run test:e2e:reports` as needed.
