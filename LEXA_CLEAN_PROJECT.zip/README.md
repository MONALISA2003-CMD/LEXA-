# LEXA

LEXA is a multi-tenant business operations platform for product catalogues, inventory, sales, purchasing, finance, reporting and team administration. This repository is the application source of record; old full-project snapshots and temporary implementation overlays do not belong in the main tree.

## Repository layout

- `apps/web/` — Next.js and React web application.
- `apps/api/` — FastAPI application and API tests.
- `migrations/` — ordered PostgreSQL migrations and migration-source provenance. Existing migration filenames are intentionally immutable.
- `scripts/` — source validation, migration verification, backup and staging tools.
- `tests/` — repository-level and database contract tests.
- `docs/` — current architecture, development, deployment, security and product guidance.
- `.github/workflows/ci.yml` — normal validation workflow.
- `.github/workflows/replace-from-archive.yml` — manual, checksum-verified repository replacement workflow.

## Local development

Requirements: Node.js 24, Python 3.12 or newer, and access to a PostgreSQL test database for database integration checks. Redis is required for the complete API test environment.

### Web application

```bash
cd apps/web
npm ci
npm run dev
```

### API

```bash
python -m venv .venv
. .venv/bin/activate
python -m pip install -e 'apps/api[dev]'
export PYTHONPATH=apps/api
export APP_ENV=development
export DATABASE_URL='postgresql+psycopg://user:password@localhost:5432/lexa_dev'
export REDIS_URL='redis://localhost:6379/0'
export JWT_SECRET='replace-with-a-local-development-secret'
uvicorn app.main:app --reload --app-dir apps/api
```

See [development](docs/development.md), [architecture](docs/architecture.md), [security and tenancy](docs/security-and-tenancy.md), [database migrations](docs/database-migrations.md), and [product catalogue](docs/product-catalog.md).

## Validation

```bash
python -m compileall -q apps/api scripts tests
PYTHONPATH=apps/api python -m pytest -q tests apps/api/tests
(cd apps/web && npm test && npm run typecheck && npm run build)
```

For hosted release readiness, use the repository CI workflow and the deployment-specific gates. An archive or local test result is not by itself evidence of a live deployment or production database state.

## Repository replacement

Replacement is manual only. The workflow requires a trusted HTTPS archive URL, a matching SHA-256 checksum, the expected current commit SHA and an explicit full-replacement confirmation. It defaults to a pull request and creates a pre-replacement source backup artifact. Never configure automatic replacement on every ZIP upload.
