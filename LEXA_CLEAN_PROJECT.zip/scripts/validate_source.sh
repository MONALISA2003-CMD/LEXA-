#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
export PYTHONPATH="${PYTHONPATH:-$ROOT/apps/api}"

printf '\n== Python syntax ==\n'
python -m compileall -q apps/api scripts tests

printf '\n== Repository and API tests ==\n'
python -m pytest -q tests apps/api/tests

printf '\n== Frontend contract tests ==\n'
node --test apps/web/tests/*.test.mjs

printf '\n== Migration source provenance ==\n'
python scripts/check_migration_recovery_manifest.py
python scripts/check_migration_sources.py --strict
python scripts/run_clean_migration_replay.py --plan-only

printf '\n== Frontend action audit ==\n'
node scripts/audit_frontend_actions.mjs

printf '\n== Shell syntax ==\n'
for script in scripts/*.sh; do bash -n "$script"; done

NODE_MAJOR="$(node -p 'process.versions.node.split(".")[0]')"
if [[ "$NODE_MAJOR" == "24" ]]; then
  printf '\n== Frontend typecheck and production build ==\n'
  (cd apps/web && npm ci && npm run typecheck && npm test && npm run build)
else
  echo "SKIPPED: frontend typecheck/build require Node 24.x; found $(node -v)."
  if [[ "${LEXA_REQUIRE_FULL_ACCEPTANCE:-0}" == "1" ]]; then exit 2; fi
fi

printf '\nValidation commands completed. Staging and disposable-database application checks require their explicitly configured environments.\n'
