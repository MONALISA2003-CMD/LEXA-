#!/usr/bin/env python3
"""Merge the LEXA Phase 6/7 acceptance overlay into a full source ZIP safely.

This does not upload to GitHub, edit a checkout, or install GitHub Actions workflows.
The protected workflow is exported separately for a repository maintainer.
"""
from __future__ import annotations

import argparse
from pathlib import Path, PurePosixPath
from zipfile import BadZipFile, ZIP_DEFLATED, ZipFile, ZipInfo

REQUIRED = ("apps/web/package.json", "apps/api/app/main.py")
MANUAL_WORKFLOW = "workflow_install_required/.github/workflows/lexa-ci.yml"
EXCLUDED_PREFIXES = ("workflow_install_required/",)


def safe_member(name: str) -> PurePosixPath:
    path = PurePosixPath(name)
    if path.is_absolute() or ".." in path.parts or not path.parts:
        raise ValueError(f"unsafe archive path: {name!r}")
    return path


def source_prefix(names: list[str]) -> str:
    candidates: set[str] = set()
    for member in names:
        normalized = member.rstrip("/")
        for marker in REQUIRED:
            if normalized == marker:
                candidates.add("")
            elif normalized.endswith("/" + marker):
                candidates.add(normalized[: -len("/" + marker)])
    valid = []
    for prefix in candidates:
        def has(path: str) -> bool:
            return f"{prefix}/{path}" in names if prefix else path in names
        if all(has(marker) for marker in REQUIRED):
            migration_path = f"{prefix}/migrations" if prefix else "migrations"
            if any(n.rstrip("/") == migration_path or n.startswith(migration_path + "/") for n in names):
                valid.append(prefix)
    if len(valid) != 1:
        raise ValueError(f"base ZIP must contain exactly one full LEXA source root; found {valid or 'none'}")
    return valid[0]


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("base_zip", type=Path, help="Full repository/source ZIP from the exact intended revision")
    parser.add_argument("overlay_zip", type=Path, help="LEXA_PHASE6_7_IMPLEMENTATION_OVERLAY ZIP")
    parser.add_argument("--output", type=Path, required=True, help="Merged full-source ZIP output")
    parser.add_argument("--workflow-out", type=Path, help="Optional separate output path for the protected CI workflow")
    args = parser.parse_args()

    try:
        with ZipFile(args.base_zip, "r") as base, ZipFile(args.overlay_zip, "r") as overlay:
            base_infos = [i for i in base.infolist() if not i.is_dir()]
            base_names = [safe_member(i.filename).as_posix() for i in base_infos]
            prefix = source_prefix(base_names)
            existing: dict[str, tuple[ZipInfo, bytes]] = {}
            for info, member in zip(base_infos, base_names, strict=True):
                root_member = member[len(prefix) + 1 :] if prefix else member
                if root_member:
                    existing[root_member] = (info, base.read(info.filename))

            patch: dict[str, bytes] = {}
            workflow_bytes = None
            for info in overlay.infolist():
                if info.is_dir():
                    continue
                member = safe_member(info.filename).as_posix()
                if member == MANUAL_WORKFLOW:
                    workflow_bytes = overlay.read(info.filename)
                    continue
                if any(member.startswith(p) for p in EXCLUDED_PREFIXES):
                    continue
                # Include only repo-root-relative source files from the overlay.
                patch[member] = overlay.read(info.filename)

        if not patch:
            raise ValueError("overlay contains no mergeable repository files")
        merged = dict(existing)
        for member, content in patch.items():
            merged[member] = (ZipInfo(member), content)

        args.output.parent.mkdir(parents=True, exist_ok=True)
        with ZipFile(args.output, "w", compression=ZIP_DEFLATED, compresslevel=8) as out:
            for member in sorted(merged):
                info, data = merged[member]
                new_info = ZipInfo(f"{prefix}/{member}" if prefix else member)
                new_info.compress_type = ZIP_DEFLATED
                new_info.external_attr = info.external_attr
                out.writestr(new_info, data)

        # Validate zip CRCs and required source markers remain in the merged output.
        with ZipFile(args.output, "r") as check:
            bad = check.testzip()
            out_names = [safe_member(i.filename).as_posix() for i in check.infolist()]
            out_prefix = source_prefix(out_names)
            if bad:
                raise ValueError(f"merged archive CRC failure: {bad}")
            expected = [f"{out_prefix}/{m}" if out_prefix else m for m in REQUIRED]
            missing = [m for m in expected if m not in out_names]
            if missing:
                raise ValueError(f"merged archive lost required LEXA source markers: {missing}")

        if args.workflow_out:
            if workflow_bytes is None:
                raise ValueError(f"overlay does not contain {MANUAL_WORKFLOW}")
            args.workflow_out.parent.mkdir(parents=True, exist_ok=True)
            args.workflow_out.write_bytes(workflow_bytes)

        print(f"MERGE PASS: {len(patch)} overlay files applied to {len(existing)} base files")
        print(f"Source root prefix: {prefix or '(ZIP root)'}")
        print(f"Merged full-source ZIP: {args.output}")
        if args.workflow_out:
            print(f"Protected CI workflow exported separately: {args.workflow_out}")
        print("No GitHub or hosting changes were made.")
        return 0
    except (OSError, BadZipFile, ValueError) as exc:
        parser.error(str(exc))
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
