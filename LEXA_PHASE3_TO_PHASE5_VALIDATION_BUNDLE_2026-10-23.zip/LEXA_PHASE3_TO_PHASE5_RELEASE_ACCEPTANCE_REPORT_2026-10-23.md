# LEXA Phases 3–5: Release Acceptance Report

**Date:** 23 October 2026  
**Reviewed source/deployed commit:** `ba8023775c4049fd5e505345157f91795834a6e4`  
**Overall disposition:** **Schema validation passed in isolated databases; production acceptance remains blocked by live schema drift and missing CI/E2E execution.**

## What is now verified

### Frontend build and deployments

- Vercel production deployment `dpl_nqS3iCWjXoLyYgeTQpLfffNSH8ve` is `READY` and serves `lexa-green.vercel.app` at the reviewed commit.
- Vercel build events show Next.js 16.4.0 compiled, TypeScript completed successfully, all 22 static pages generated, and deployment completed.
- Render API deployment `dep-dbddq80u01pc73cj8le0` is `live` at the same commit.
- Local regression checks on the uploaded source: **290 Python tests passed** (one existing Starlette deprecation warning), **58 frontend contract tests passed**, Python compilation passed, frontend action audit passed (29 TS/TSX files; 205 button-like controls, 48 forms, 72 links), and 47-item migration plan/hash check passed.
- The local Node install was incomplete due package-registry/network limits, so local `npm run typecheck` is not evidence; the successful Vercel build is the authoritative full production build result for this commit.

### Empty-database replay

- Replayed all **47 ordered migration inputs** from the current checked-in manifest into the dedicated empty database `lexa_clean_replay_20261023`, project `wispy-frog-93010235`, branch `br-jolly-mode-b966dwys` (PostgreSQL 18.6).
- The target was verified empty before replay (zero public tables). Production `lexa-live` was not targeted.
- Post-replay: **130 public tables; 130/130 have RLS enabled and forced; zero RLS gaps**.
- Required migration rows through 043 are present, including inventory intelligence, supplier/landed-cost, expense-correction, analytics queue, Team Chat and journal-currency guard routines.
- Phase 6/7 checks passed: replenishment table and tenant policy, stock-age index, four valid/ready movement-health indexes, six supplier/landed-cost tables with forced RLS and tenant policies, active supplier-cost uniqueness index, purchase-order `updated_at`, bill-match and supplier-return cost fields, append-only ledger/allocation grants, and bill/payment lifecycle grants.
- Phase 8 and Phase 5 checks passed: expense correction reference/index/posting routine/reporting field/tenant-safe FK/status; three Team Chat tables with forced RLS and scoped policies; sales business date/index; forced-RLS analytics queue and worker; journal currency guard and runtime-only posting grant.
- A runtime-role adversarial RLS probe created real `tenant_settings` rows for both tenants before switching to `lexa_app`; tenant A could not read tenant B's row and the cross-tenant insert was denied. Probe fixtures were removed (zero probe tenants/settings remained).
- On a separate disposable validation branch, a balanced UGX journal posted, a balanced but mixed UGX/USD journal was rejected and remained `DRAFT`, journal line immutability prevented direct deletion of posted lines, and the test fixture was rolled back via a nested subtransaction.

### Production-snapshot upgrade test

Neon branch capacity prevented creation of a new production-derived branch. An existing **non-primary test snapshot** (`br-young-base-b1mi15fs`, initially at migration 035) was used to apply migrations 036–043. The forward migrations succeeded, leaving 130 public tables, all with forced RLS and no gaps; required new tables/policies/routines/indexes and journal grants were present. That snapshot contains six tenant rows but zero sales and zero purchase orders. The production `lexa-live` branch was not changed.

## Release blockers that remain

1. **Production database schema drift is confirmed.** The live Neon project `wispy-mud-75323042`, branch `br-soft-star-b1dj2m2w` (`lexa-live`), remains at `031_phase3_auth_surface_rls` with 119 public tables. It does not have `supplier_bills`, `supplier_payments`, or the Phase 8 `expense_records.reversal_journal_entry_id` field. The Vercel and Render application source at commit `ba802…` is already deployed by automatic deployment, so do not call Phase 3–5 production-ready until the controlled production migration rollout is approved and completed.
2. **GitHub Actions CI was not executed.** The ZIP extraction workflow protects `.github/workflows/`, the remote `lexa-ci.yml` file was absent, and a direct workflow-file write returned HTTP 403. Therefore the dedicated Node 24 CI job and PostgreSQL 16 clean replay job have not run. The manual clean replay ran on PostgreSQL 18.6.
3. **Authenticated browser E2E was not run.** The Playwright sales/stock/journal and purchasing lifecycle suites intentionally require an allow-listed disposable staging host, QA storage states, and seeded disposable fixture JSON. No writes were run against production.
4. **Production migration is not approved or applied.** Applying migrations 033–043 (with 038 concurrent-index steps run outside transaction) to `lexa-live` must be a separately approved, backed-up operation. Neon refused creation of another branch because the branch limit is reached; no branch was deleted/reset to make room.
5. **Capacity acceptance remains open.** No authenticated 5,000-user or concurrent-load test, database backup/restore drill, or full staging acceptance run has been completed.

## Safe next steps

1. Free an unused Neon branch in the LEXA project (or otherwise restore branch capacity), then prepare and inspect a production-derived migration test branch before approving any production SQL.
2. Add the CI workflow through an authorized GitHub path so Node 24 typecheck/build and PostgreSQL 16 clean replay run on the exact reviewed commit.
3. Configure the isolated staging URL, disposable fixtures and QA authentication state, then run the gated authenticated sales/return/accounting and purchasing acceptance suites.
4. Only after evidence passes, schedule the production migration rollout with a verified backup and post-migration checks; do not reset or truncate the live database.

## Evidence integrity

The attached JSON records the exact reviewed source commit, 47 ordered migration inputs and the manifest SHA-256. It is derived from completed isolated SQL execution and read-only postcondition queries; it is **not** an assertion that GitHub Actions or PostgreSQL 16 CI ran. Historical byte parity for the six formally replaced SQL sources is still intentionally not claimed.
