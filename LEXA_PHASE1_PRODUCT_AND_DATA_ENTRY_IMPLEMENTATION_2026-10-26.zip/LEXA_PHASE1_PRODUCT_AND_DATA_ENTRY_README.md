# LEXA Phase 1 — product setup and critical journey patch

**Source base:** `f50fd73c2b78b29754a87cab34133d19b686b824` (`main` observed 2026-10-26). Reconcile against the latest main before applying if it has moved.

## Included implementation

- Adds `POST /api/v1/catalog/products/quick-setup` with a typed OpenAPI response and idempotency support.
- Creates a product and first sellable variant as a single database transaction, with optional barcode and price-list price in that same transaction; validates tenant-owned references and SKU/barcode conflicts; records audit events and outbox events; rolls back on failed writes.
- Improves the product data-entry form for name, category/brand, item name, SKU, base unit, costing method, optional barcode and optional selling price.
- Keeps opening stock out of product setup. Initial/received stock is entered through audited inventory adjustments and goods-receipt flows, not inferred from a catalog record.
- Adds a dedicated print-ready customer receipt derived from the authoritative sale detail, including lines, discounts/tax, branch/location, payments allocated and receivable balance.
- Surfaces linked journal debit/credit totals and balanced status; exposes tenant-scoped manual fiscal-document references in sale details. The UI expressly distinguishes LEXA's receipt from an official URA fiscal document and says manual URA references are not submitted or independently verified by LEXA.
- Appends LEXA master-logo authority overrides for app shell/mobile topbar.
- Fixes migration 048 supplier-accounting trigger references from undeclared `v_cash` to the declared `a_cash` variable.
- Adds API and frontend contract regression tests and updates disposable replay evidence.

The repository already contains guarded data-entry actions for purchase orders, receipts, supplier bills/payments, stock adjustments/counts/transfers, checkout and accounting. This patch preserves those workflows; it does not replace them with direct/unledgered table writes.

## Validation observed for this patch

- API test suite: **343 passed**, 2 dependency deprecation warnings.
- Frontend test suite: **133 passed, 0 failed**.
- TypeScript typecheck: **passed**.
- Next.js production build: **passed**.
- `git diff --check`: **passed**.
- Disposable local PostgreSQL 18 replay: **52 SQL steps passed** after the migration 048 correction. The replay checks reported RLS and runtime-role cross-tenant isolation assertions passed across 135 public tables. It used a disposable local DB and a local `psql` compatibility shim because that sandbox lacked the standard CLI; re-run the repository's standard clean replay in CI before release.

## Not done / release gates remaining

- The patch is not committed or pushed. GitHub branch creation through the connected integration was denied (HTTP 403).
- No production DB was mutated, and no staging/production deployment was triggered.
- Authenticated end-to-end tests against a staging deployment have not been run.
- No validated source SHA has yet been confirmed as deployed to both the Vercel frontend and Render API.
- Do not treat Phase 1 as release-complete until CI, standard clean migration replay, synthetic authenticated staging journey, and same-SHA deployment checks pass.

## Apply

The bundle contains a normal unified Git patch. From the stated base commit, run:

```bash
git apply --check LEXA_PHASE1_PRODUCT_AND_CRITICAL_JOURNEY.patch
git apply LEXA_PHASE1_PRODUCT_AND_CRITICAL_JOURNEY.patch
```

Then run the repository's required checks, review migration 048 through the normal migration release process, deploy only to staging, and exercise the full product → purchase order → goods receipt → inventory/cost → sale → payment/receivable → balanced journal → receipt → manual fiscal reference → analytics sequence with synthetic tenant data.
