# LEXA overlay package — 049–051

Source target: `MONALISA2003-CMD/LEXA-`, existing branch `LEXA-branch`.

This ZIP contains additive SQL migrations, a read-only end-to-end transaction trace, checkout traceability wiring, guarded workflow integration patches for receiving/returns/transfers/counts/adjustments, and offline contract tests. GitHub branch creation is blocked by connector permissions, so the ZIP is the handoff artifact.

Read `START_HERE.md` and `IMPLEMENTATION_STATUS.md` before applying. Production and backup Neon were not modified. A separate Neon replay branch was updated through migration version 051 for schema-level validation only. Full source build, full clean-replay chain, API suite, web build and authenticated E2E remain release gates and are not claimed as passed.

Database-trigger smoke tests have been run against the isolated Neon replay branch using synthetic QA tenants. They are not an authenticated application E2E test. Production Neon, backup Neon, Render and Vercel were not changed or redeployed.
