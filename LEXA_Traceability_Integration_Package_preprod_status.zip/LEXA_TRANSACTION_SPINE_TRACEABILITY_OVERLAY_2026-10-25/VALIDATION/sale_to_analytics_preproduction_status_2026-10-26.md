# LEXA sale-to-analytics / sales-accounting readiness

Updated: 2026-10-26 (UTC)

## Status: NOT GREEN — pre-production implementation gate remains open

This report separates verified isolated-schema tests from the end-to-end acceptance test that is still required. No production migration or deployment was performed.

## Verified in this pass

- Inspected the current `LEXA-branch` commerce, purchasing, inventory, and application entrypoint source through the GitHub connector.
- Confirmed the isolated Neon replay branch `LEXA-PHASE7-REPLAY-20261022 / lexa-inventory-overlay-replay-20261025` has the prior traceability schema and trigger smoke-test work recorded in `neon_replay_validation.txt`.
- Rechecked the isolated QA tenants: `LEXA-TRACEABILITY-QA-20261025` and `LEXA-BATCH-QA-20261025` currently have **0 sales, 0 payments, 0 journal entries, and 0 outbox events**. Therefore, the prior serial/batch trigger smoke tests are not evidence of a complete sale-to-analytics transaction.
- Render service `srv-dakm8k95efls73egg9a0` is still attached to `main`; recent application logs show the release schema readiness gate failing (`phase7_release_schema_not_ready`, `/ready` returns HTTP 503).
- Vercel's previously observed production deployment state `READY` is only a deployment/build status; it is not evidence that the proposed traceability integration or full financial journey is deployed and passing.
- GitHub branch creation was attempted for a pre-production work branch but denied by the integration with HTTP 403 `Resource not accessible by integration`. No source change, commit, pull request, or deployment was made.

## Sale-to-analytics acceptance matrix

| Journey segment | Current evidence | Gate status |
|---|---|---|
| Product/variant setup | Existing schema/source inspected; no fresh test product configured for a complete sale | Not proven end-to-end |
| Stock receipt | Serial/batch traceability trigger smoke tests were previously run on isolated branch | Partial pass only |
| Sale / checkout | Source inspection only; no authenticated checkout transaction exercised | Not proven |
| Inventory and cost movement | Canonical inventory-ledger and trace trigger smoke tests exist; no joined sale/COGS proof | Not proven end-to-end |
| Recorded payment / receivable | QA tenant readback has zero payment records; no allocation/remainder reconciliation run | Not proven |
| Balanced journals | QA tenant readback has zero journal entries; no debit/credit balance test for a real sale/payment | Not proven |
| LEXA receipt | No receipt artifact verified as linked to a confirmed sale in this pass | Not proven |
| Tax-supporting records | Schema/source inspected; no transaction-linked tax record acceptance test run | Not proven |
| Analytics | QA tenant readback has zero outbox events; no event-consumer/analytics refresh assertion run | Not proven |
| Retry/idempotency | Existing ledger and overlay contracts inspected; no authenticated whole-checkout retry test | Not proven end-to-end |
| Sales/POS, quotations, history, customer statements | Source inspection only; no full API/UI regression suite executed | Not proven |
| Partial/unallocated payments, credit sales, returns/refunds/credit adjustments/reversals/reconciliation | Not covered by an authenticated end-to-end acceptance suite in this pass | Not proven |
| Restricted financial access | No role-based API test suite executed in this pass | Not proven |

## Environment and safety boundaries

- Production Neon `LEXA / lexa-live` was not modified. It was previously observed at migration 047 without the serial/lot traceability schema.
- Backup Neon project was not modified.
- Isolated replay branch only: existing traceability schema/trigger QA work is retained there.
- No Render or Vercel deployment was triggered.
- No payment processor/mobile money/bank API, EFRIS/URA API, or other external tax authority integration was added.
- No production schema migration was run.

## Required next steps before calling this green

1. Restore the repository's canonical migration chain and install the source overlay in a clean checkout; GitHub write permissions must be fixed or a maintainer must apply the patch.
2. Run API tests, frontend typecheck/build, and the full disposable PostgreSQL replay.
3. Run an authenticated test journey with a unique test transaction: product setup → receipt → checkout → inventory/COGS → payment and/or receivable → balanced sale and collection journals → LEXA receipt → tax-supporting record → outbox/analytics.
4. Assert each downstream record references its originating transaction, a payment cannot create a second sale, and downstream events cannot post inventory again.
5. Retry the exact checkout and payment requests; assert one sale, one set of inventory movements, no duplicate journal/event/receipt, and stable response semantics.
6. Exercise partial payments, unallocated money, credit sale, return/refund, credit adjustment, reversal, reconciliation, customer statements, expenses/cashbook and accounting reports; reconcile customer balances and debit/credit totals to source records.
7. Test role/tenant/branch isolation for restricted financial endpoints.
8. Only after the above pass, deploy one coherent reviewed commit to non-production Render/Vercel and perform the separate pre-production release-readiness checks. Production gates remain deferred as requested.

## Conclusion

This is a truthful readiness report, not a green acceptance certificate. The existing isolated traceability schema tests are useful progress, but the complete sale-to-analytics and sales/accounting milestone is **not yet proven**. Marking it green without the authenticated transaction, journal reconciliation, event/analytics assertions, retry test, and financial access tests would be misleading.
