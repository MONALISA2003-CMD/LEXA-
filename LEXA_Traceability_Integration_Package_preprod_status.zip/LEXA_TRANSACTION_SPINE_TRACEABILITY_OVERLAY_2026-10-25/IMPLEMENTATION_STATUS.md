# LEXA implementation and validation status

Updated: 2026-10-25 (UTC)

## Source branch and infrastructure facts

- Repository: `MONALISA2003-CMD/LEXA-`; working source branch: `LEXA-branch` (branch head observed at `9e44536c01080de0cad000f51a597f1cd62118bf`). The GitHub connector rejects branch creation with HTTP 403 `Resource not accessible by integration`; source writes were not pushed. Use this ZIP on a clean local checkout of `LEXA-branch`.
- Vercel project `lexa`: latest production deployment is `READY` at `8c2ec4eb138e43089fc439a701607d33356b14a8`. A READY deployment does not prove the overlay has shipped. Render remains attached to `main` and has a different service deploy SHA.
- Render service `LEXA`: live service, branch `main`, root `apps/api`; logs continue to show `phase7_release_schema_not_ready` and `/ready` 503. The platform deployment is live, but application readiness remains red.
- Neon production primary `LEXA / lexa-live` remains at `047_analytics_forecast_history_backfill`; `tracking_mode`, serial units and lots are still absent there. The separate `LEXA-BACKUP-20261022` project remains on migration 045. Neither project was changed.

## Isolated Neon schema application completed

A child branch `lexa-inventory-overlay-replay-20261025` was created under project `LEXA-PHASE7-REPLAY-20261022` (branch id `br-solitary-brook-b9q6lj78`, parent `phase7-clean-replay`). It started at schema version 048 and has been updated in an isolated transaction with the 049/050 traceability schema and the 051 workflow guards. Read-back confirmed migration records 048–051, traceability tables and `tracking_details` columns, the three inventory triggers, and return-alias checks in the trigger functions. After schema application, isolated synthetic QA fixtures were added on this child branch solely for trigger smoke tests. It now contains the `LEXA-TRACEABILITY-QA-20261025` and `LEXA-BATCH-QA-20261025` test tenants. This was database-trigger verification—not an authenticated API/browser end-to-end test. Production and backup remain unchanged.

## What the source overlay now implements

- Migration 049: serial/IMEI register, lot/batch register, immutable per-serial/per-lot movements, tenant RLS and deferred reconciliation against canonical `inventory_transactions`.
- Migration 050: read-only transaction trace indexes.
- Migration 051: line-level tracking details; canonical receipt type `PURCHASE_RECEIPT`; serial/lot creation on receipts; provenance guard restricting supplier returns to the original goods receipt; existing sale-return `RETURN` alias; serial transfer state; lot transfer destination creation; adjustments/count reconciliation metadata.
- Guarded source patch installer: purchase-order receiving and supplier returns, sale returns, stock transfers, stock counts and adjustments now carry explicit serial/lot detail through the existing `post_ledger` path. It preserves idempotency and keeps the inventory transaction ledger as the only quantity source of truth. Checkout integration remains in `apply_transaction_spine_overlay.py`.

## Validation performed

- Python byte-compile of both installer scripts: passed.
- Static overlay contracts and tracked-workflow contracts: passed.
- Remote source-anchor preflight against `LEXA-branch` files: all required anchors found exactly once.
- Neon branch schema read-back: migration records 048–051; serial/lot registers and immutable movement tables exist; tenant RLS is enabled and forced; trace indexes exist; receipt/return/supplier-return provenance guards present.
- Isolated Neon DB trigger smoke tests passed: serial receipt → sale → duplicate-sale rejection → return; batch receipt → transfer out/in → sale → supplier return; serial and batch adjustment/count corrections; legacy standalone serial/batch receipt endpoints do not double-insert detail rows. Test fixtures remain only in the isolated replay branch.
- ZIP integrity and SHA-256 manifest: checked after packaging.

## Not run / not claimed

- The installer has not been applied to a complete local checkout because the execution environment cannot resolve GitHub, and GitHub write access returns 403. The full patched application source was therefore not compiled here, and no authenticated LEXA API or browser transaction was exercised.
- Full API pytest, TypeScript typecheck/build, clean replay of the repository's closed migration-recovery manifest, and authenticated end-to-end transaction/retry test were not run. The `clean_replay_order.json` in the repo is a historical recovery gate ending at 045 and the current branch lacks a verified complete replay input chain through 048. Do not bypass that gate.
- Render and Vercel were not redeployed: the integration is not yet in GitHub and the full build/E2E gates have not passed. Do not mark `/ready` green by weakening its schema test.
- No production migration, production database write, payment processor integration or tax authority API integration was performed.

## Next safe gate

On a clean checkout of `LEXA-branch`, run the two guarded installers in order with `--dry-run`, review the diff, then apply them. After restoring/verifying the canonical migration source chain through 048, run the full disposable PostgreSQL replay and API/web suites, then authenticated tests for receipt → sale → cost/journal/receipt trace; idempotent retries; serial and batch returns; transfers; counts; adjustments; tenant and branch isolation. Only after that should one coherent commit be deployed to Render and Vercel, followed by the final production schema/readiness gate.
