#!/usr/bin/env python3
"""Guarded LEXA overlay installer. Run from the repository root on a clean branch.

It is intentionally strict: if the expected checkout code changed, it stops rather
than doing a broad or ambiguous replacement. It never connects to deployed services.
"""
from __future__ import annotations
import argparse, hashlib, json, shutil, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OVERLAY = ROOT / "OVERLAY"

def once(src: str, old: str, new: str, label: str) -> str:
    n = src.count(old)
    if n != 1:
        raise RuntimeError(f"{label}: expected one stable source anchor, found {n}; no files written")
    return src.replace(old, new, 1)

def main() -> int:
    ap=argparse.ArgumentParser()
    ap.add_argument("--repo", type=Path, default=Path.cwd(), help="LEXA checkout root")
    ap.add_argument("--dry-run", action="store_true")
    args=ap.parse_args(); repo=args.repo.resolve()
    required=[repo/"apps/api/app/main.py",repo/"apps/api/app/routes/commerce.py",repo/"apps/web/lib/api.ts",repo/"apps/web/app/commerce/page.tsx",repo/"migrations"]
    missing=[str(p) for p in required if not p.exists()]
    if missing: print("Missing expected LEXA paths:\n"+"\n".join(missing),file=sys.stderr); return 2
    pending: dict[Path,str] = {}
    try:
        main=(repo/"apps/api/app/main.py").read_text()
        if "from .routes import transaction_trace" not in main:
            main=once(main,"from .kernel import router as kernel_router", "from .routes import transaction_trace, traceability\nfrom .kernel import router as kernel_router", "traceability router imports")
        elif "from .routes import traceability" not in main:
            main=once(main,"from .routes import transaction_trace", "from .routes import transaction_trace, traceability", "traceability router import")
        if "app.include_router(traceability.router" not in main:
            main=once(main,'app.include_router(inventory.router, prefix="/api/v1")', 'app.include_router(inventory.router, prefix="/api/v1")\napp.include_router(traceability.router, prefix="/api/v1")', "inventory traceability router registration")
        if "app.include_router(transaction_trace.router" not in main:
            main=once(main,'app.include_router(commerce.router, prefix="/api/v1")', 'app.include_router(commerce.router, prefix="/api/v1")\napp.include_router(transaction_trace.router, prefix="/api/v1")', "transaction trace router registration")
        pending[repo/"apps/api/app/main.py"]=main

        commerce=(repo/"apps/api/app/routes/commerce.py").read_text()
        if "serial_numbers: list[str]" not in commerce:
            commerce=once(commerce,
                '    discount_amount: Decimal = Field(default=Decimal("0"), ge=0)\n    tax_rate: Decimal = Field(default=Decimal("0"), ge=0, le=100)',
                '    discount_amount: Decimal = Field(default=Decimal("0"), ge=0)\n    serial_numbers: list[str] = Field(default_factory=list, max_length=200)\n    tax_rate: Decimal = Field(default=Decimal("0"), ge=0, le=100)',
                "sale line serial field")
        old_loop='''        for idx,(line,variant,_,_,_,_,_) in enumerate(validated, start=1):
            invtx=post_ledger(db,tenant_id=tenant_id,actor_user_id=actor,location_id=body.location_id,variant_id=variant.id,quantity_delta=-q(line.quantity),unit_cost=Decimal("0"),transaction_type="SALE",reference_type="sale",reference_id=sale_id,idempotency_key=f"{idempotency_key or tx.id}:inventory:{idx}",metadata={"sale_id":str(sale_id)}) if variant.track_inventory else None'''
        new_loop='''        for idx,(line,variant,_,_,_,_,_) in enumerate(validated, start=1):
            if not variant.track_inventory:
                if line.serial_numbers:
                    raise HTTPException(422,"Do not enter serial numbers for an item that does not track stock by serial.")
                invtx = None
                continue
            mode = db.execute(text("SELECT tracking_mode FROM public.product_variants WHERE tenant_id=:t AND id=:v"), {"t":str(tenant_id),"v":str(variant.id)}).scalar_one_or_none() or "QUANTITY"
            movement_metadata = {"sale_id":str(sale_id),"tracking_mode":mode}
            if mode == "SERIAL":
                requested = [str(x).strip() for x in line.serial_numbers]
                if line.quantity != line.quantity.to_integral_value() or len(requested) != int(line.quantity):
                    raise HTTPException(422,"Enter one serial number or IMEI for every unit being sold.")
                if any(not x for x in requested) or len({x.casefold() for x in requested}) != len(requested):
                    raise HTTPException(422,"Each serial number or IMEI must be filled in and unique on this sale.")
                serial_rows = db.execute(text("""
                  SELECT id,serial_number,imei FROM public.inventory_serial_units
                  WHERE tenant_id=:t AND variant_id=:v AND current_location_id=:loc AND status='IN_STOCK'
                    AND (serial_number = ANY(:values) OR imei = ANY(:values))
                  FOR UPDATE
                """), {"t":str(tenant_id),"v":str(variant.id),"loc":str(body.location_id),"values":requested}).mappings().all()
                if len(serial_rows) != len(requested):
                    raise HTTPException(409,"One or more serial numbers are not available at this stock location or have already been sold.")
                returned_values = [str(r["serial_number"]) for r in serial_rows] + [str(r["imei"]) for r in serial_rows if r["imei"]]
                if any(not any(x.casefold() == y.casefold() for y in returned_values) for x in requested):
                    raise HTTPException(409,"A serial number or IMEI could not be matched to this product option.")
                movement_metadata["serial_ids"] = [str(r["id"]) for r in serial_rows]
            elif mode == "BATCH":
                if line.serial_numbers:
                    raise HTTPException(422,"This item is tracked by batch; individual serial fields must be empty.")
                remaining = q(line.quantity); allocations = []
                lot_rows = db.execute(text("""
                  SELECT id,remaining_quantity FROM public.inventory_lots
                  WHERE tenant_id=:t AND variant_id=:v AND location_id=:loc AND status='ACTIVE'
                    AND remaining_quantity > 0 AND (expires_on IS NULL OR expires_on >= current_date)
                  ORDER BY expires_on ASC NULLS LAST, created_at, id FOR UPDATE
                """), {"t":str(tenant_id),"v":str(variant.id),"loc":str(body.location_id)}).mappings().all()
                for lot in lot_rows:
                    take = min(remaining, q(lot["remaining_quantity"]))
                    if take <= 0: continue
                    allocations.append({"lot_id":str(lot["id"]),"quantity":str(take)})
                    remaining = q(remaining-take)
                    if remaining == 0: break
                if remaining > 0:
                    raise HTTPException(409,"There is not enough unexpired batch stock to complete this sale.")
                movement_metadata["lot_allocations"] = allocations
            elif line.serial_numbers:
                raise HTTPException(422,"This product uses ordinary quantity tracking; serial numbers are not accepted.")
            invtx = post_ledger(db,tenant_id=tenant_id,actor_user_id=actor,location_id=body.location_id,
                variant_id=variant.id,quantity_delta=-q(line.quantity),unit_cost=Decimal("0"),
                transaction_type="SALE",reference_type="sale",reference_id=sale_id,
                idempotency_key=f"{idempotency_key or tx.id}:inventory:{idx}",metadata=movement_metadata)'''
        if 'movement_metadata["serial_ids"]' not in commerce:
            commerce=once(commerce,old_loop,new_loop,"checkout movement block")
        pending[repo/"apps/api/app/routes/commerce.py"]=commerce

        webapi=(repo/"apps/web/lib/api.ts").read_text()
        webapi = webapi.replace('lines:Array<{variant_id:string;quantity:string;unit_price:string;discount_amount?:string;tax_rate?:string}>', 'lines:Array<{variant_id:string;quantity:string;unit_price:string;discount_amount?:string;tax_rate?:string;serial_numbers?:string[]}>')
        # Include the additive helper modules but keep the shared API implementation intact.
        api_additions = (OVERLAY/"apps/web/lib/api.traceability.additions.ts").read_text() + "\n" + (OVERLAY/"apps/web/lib/api.transaction-trace.additions.ts").read_text()
        if "getCommerceSaleTrace(saleOrTransactionId" not in webapi:
            webapi += "\n\n// LEXA inventory traceability + end-to-end source transaction trace.\n" + api_additions
        pending[repo/"apps/web/lib/api.ts"]=webapi

        web=(repo/"apps/web/app/commerce/page.tsx").read_text()
        if "serialNumbers: string" not in web:
            web=once(web,'type CartLine = { id:string; variantId:string; quantity:string; unitPrice:string; discountAmount:string };','type CartLine = { id:string; variantId:string; quantity:string; unitPrice:string; discountAmount:string; serialNumbers:string };',"cart line serial state")
            web=once(web,'function updateCartLine(id:string, field:"quantity"|"unitPrice"|"discountAmount", value:string)', 'function updateCartLine(id:string, field:"quantity"|"unitPrice"|"discountAmount"|"serialNumbers", value:string)', "cart line field union")
            web=once(web,'return [...current, { id: crypto.randomUUID(), variantId: selectedProduct.variant_id, quantity: String(quantity), unitPrice: String(unitPrice), discountAmount:"0" }];','return [...current, { id: crypto.randomUUID(), variantId: selectedProduct.variant_id, quantity: String(quantity), unitPrice: String(unitPrice), discountAmount:"0", serialNumbers:"" }];',"new cart line serial state")
            web=once(web,'lines: cart.map((line) => ({ variant_id: line.variantId, quantity: line.quantity, unit_price: line.unitPrice, discount_amount: line.discountAmount || "0" })),','lines: cart.map((line) => ({ variant_id: line.variantId, quantity: line.quantity, unit_price: line.unitPrice, discount_amount: line.discountAmount || "0", serial_numbers: line.serialNumbers.split(",").map(x=>x.trim()).filter(Boolean) })),',"checkout serial body")
            anchor='''                      <label>Unit price<input aria-label={`Unit price ${product?.product_name || "product"}`} type="number" min="0" step="0.01" value={line.unitPrice} onChange={(e) => updateCartLine(line.id,"unitPrice",e.target.value)} required disabled={!capabilities.can_manage_price} /></label>'''
            inserted='''                      <label>Serial / IMEI numbers (serial-tracked items only)<input aria-label={`Serial / IMEI numbers ${product?.product_name || "product"}`} value={line.serialNumbers} onChange={(e)=>updateCartLine(line.id,"serialNumbers",e.target.value)} placeholder="One per unit, separated by commas" autoComplete="off" /></label>
'''+anchor
            web=once(web,anchor,inserted,"checkout serial input")
        pending[repo/"apps/web/app/commerce/page.tsx"]=web

    except RuntimeError as e:
        print(f"Preflight stopped: {e}",file=sys.stderr); return 3

    # Copy additive files/migrations only after all source anchors passed.
    copy_map = {
      OVERLAY/"apps/api/app/routes/traceability.py": repo/"apps/api/app/routes/traceability.py",
      OVERLAY/"apps/api/app/routes/transaction_trace.py": repo/"apps/api/app/routes/transaction_trace.py",
      OVERLAY/"apps/web/app/inventory/traceability/page.tsx": repo/"apps/web/app/inventory/traceability/page.tsx",
      OVERLAY/"apps/web/app/commerce/traceability/page.tsx": repo/"apps/web/app/commerce/traceability/page.tsx",
      OVERLAY/"migrations/049_phase1_inventory_traceability.sql": repo/"migrations/049_phase1_inventory_traceability.sql",
      OVERLAY/"migrations/050_transaction_spine_trace_indexes.sql": repo/"migrations/050_transaction_spine_trace_indexes.sql",
      OVERLAY/"migrations/051_tracked_inventory_workflow_integration.sql": repo/"migrations/051_tracked_inventory_workflow_integration.sql",
    }
    conflicts=[str(dst) for src,dst in copy_map.items() if dst.exists()]
    if conflicts and not args.dry_run:
        print("Existing target files would be replaced; preserve/review them before installing:\n"+"\n".join(conflicts),file=sys.stderr); return 4
    if args.dry_run:
        print("Dry-run passed. Planned source edits:")
        for p,s in pending.items(): print(f"  edit {p.relative_to(repo)} ({len(s)} chars)")
        for s,d in copy_map.items(): print(f"  add {d.relative_to(repo)} ({s.stat().st_size} bytes)")
        return 0
    for p,s in pending.items(): p.write_text(s)
    for src,dst in copy_map.items():
        dst.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(src,dst)
    print("Overlay installed on the local checkout. No remote service or database was changed.")
    print("Next: run targeted API tests, web typecheck/build, canonical clean PostgreSQL replay through 051, then the authenticated synthetic end-to-end scenario.")
    return 0
if __name__=="__main__": raise SystemExit(main())
