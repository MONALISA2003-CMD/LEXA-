#!/usr/bin/env python3
"""Strict additive source patch for canonical LEXA SERIAL/BATCH workflows.

Run after apply_transaction_spine_overlay.py from a clean LEXA feature checkout.
All source anchors are checked before any files are written. No remote service is
accessed, no deployment is triggered, and no database is changed by this script.
"""
from __future__ import annotations
import argparse, sys
from pathlib import Path


def replace_once(source: str, old: str, new: str, label: str) -> str:
    count = source.count(old)
    if count != 1:
        raise RuntimeError(f"{label}: expected one stable source anchor, found {count}; no workflow files written")
    return source.replace(old, new, 1)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo", type=Path, default=Path.cwd())
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()
    repo = args.repo.resolve()
    paths = {
        "purchasing": repo / "apps/api/app/routes/purchasing.py",
        "inventory": repo / "apps/api/app/routes/inventory.py",
        "commerce": repo / "apps/api/app/routes/commerce.py",
    }
    missing = [str(p) for p in paths.values() if not p.is_file()]
    if missing:
        print("Missing expected LEXA source files:\n" + "\n".join(missing), file=sys.stderr)
        return 2
    changes: dict[Path, str] = {}
    try:
        # PURCHASE ORDER RECEIVING + SUPPLIER RETURNS
        p = paths["purchasing"]
        src = p.read_text()
        src = replace_once(src,
            "class ReceiptLineIn(Strict):\n    purchase_order_line_id: UUID\n    received_quantity: Decimal = Field(gt=0, max_digits=20, decimal_places=6)",
            "class TraceSerialUnitIn(Strict):\n    serial_number: str = Field(min_length=1, max_length=200)\n    imei: str | None = Field(default=None, max_length=32)\n\nclass TraceLotAllocationIn(Strict):\n    lot_id: UUID\n    quantity: Decimal = Field(gt=0, max_digits=20, decimal_places=6)\n\nclass ReceiptLineIn(Strict):\n    purchase_order_line_id: UUID\n    received_quantity: Decimal = Field(gt=0, max_digits=20, decimal_places=6)\n    serial_units: list[TraceSerialUnitIn] = Field(default_factory=list, max_length=200)\n    lot_number: str | None = Field(default=None, max_length=120)\n    expires_on: date | None = None\n    manufactured_on: date | None = None",
            "receipt trace inputs")
        src = replace_once(src,
            "class PurchaseReturnLineIn(Strict):\n    purchase_receipt_line_id: UUID\n    quantity: Decimal = Field(gt=0, max_digits=20, decimal_places=6)",
            "class PurchaseReturnLineIn(Strict):\n    purchase_receipt_line_id: UUID\n    quantity: Decimal = Field(gt=0, max_digits=20, decimal_places=6)\n    serial_ids: list[UUID] = Field(default_factory=list, max_length=200)\n    lot_allocations: list[TraceLotAllocationIn] = Field(default_factory=list, max_length=200)",
            "supplier return trace inputs")
        src = replace_once(src,
            '        if not po_line: raise HTTPException(422, "Receipt line is not part of this purchase order")\n        remaining = Decimal(str(po_line["ordered_quantity"])) - Decimal(str(po_line["received_quantity"]))',
            '''        if not po_line: raise HTTPException(422, "Receipt line is not part of this purchase order")
        tracking_mode=db.execute(text("SELECT tracking_mode FROM public.product_variants WHERE tenant_id=:t AND id=:v"),{"t":str(tenant_id),"v":str(po_line["variant_id"])}).scalar_one_or_none() or "QUANTITY"
        if tracking_mode == "SERIAL":
            if line.received_quantity != line.received_quantity.to_integral_value() or len(line.serial_units) != int(line.received_quantity): raise HTTPException(422,"A serial-tracked receipt needs one unique serial/IMEI record per whole unit")
            ids=[(x.imei or x.serial_number).strip().casefold() for x in line.serial_units]
            if len(set(ids)) != len(ids) or any(not x.serial_number.strip() for x in line.serial_units): raise HTTPException(422,"Received serial numbers/IMEIs must be nonblank and unique")
            if line.lot_number or line.expires_on or line.manufactured_on: raise HTTPException(422,"Serial-tracked receipts do not accept batch fields")
        elif tracking_mode == "BATCH":
            if not line.lot_number or not line.lot_number.strip(): raise HTTPException(422,"A batch-tracked receipt requires a lot number")
            if line.serial_units: raise HTTPException(422,"Batch-tracked receipts do not accept serial numbers")
            if line.expires_on and line.manufactured_on and line.expires_on < line.manufactured_on: raise HTTPException(422,"Batch expiry cannot be before manufacture date")
        elif line.serial_units or line.lot_number or line.expires_on or line.manufactured_on: raise HTTPException(422,"Traceability details are only accepted for serial/batch-tracked products")
        remaining = Decimal(str(po_line["ordered_quantity"])) - Decimal(str(po_line["received_quantity"]))''',
            "receipt type-specific validation")
        src = replace_once(src,
            'INSERT INTO public.purchase_receipt_lines(id,tenant_id,receipt_id,purchase_order_line_id,variant_id,received_quantity,unit_cost,base_unit_cost,landed_cost_amount,variance_reason,notes) VALUES(:id,:t,:receipt,:po_line,:variant,:qty,:cost,:base,0,:reason,:notes)',
            'INSERT INTO public.purchase_receipt_lines(id,tenant_id,receipt_id,purchase_order_line_id,variant_id,received_quantity,unit_cost,base_unit_cost,landed_cost_amount,variance_reason,notes,tracking_details) VALUES(:id,:t,:receipt,:po_line,:variant,:qty,:cost,:base,0,:reason,:notes,CAST(:tracking AS jsonb))',
            "receipt tracking-details persistence")
        src = replace_once(src,
            '"reason": item.variance_reason, "notes": item.notes})',
            '"reason": item.variance_reason, "notes": item.notes, "tracking": __import__("json").dumps(({"serial_units":[x.model_dump(mode="json") for x in item.serial_units]} if item.serial_units else ({"lot_receipt":{"lot_number":item.lot_number,"expires_on":item.expires_on.isoformat() if item.expires_on else None,"manufactured_on":item.manufactured_on.isoformat() if item.manufactured_on else None}} if item.lot_number else {})))})',
            "receipt tracking-details payload")
        src = replace_once(src,
            'metadata={"receipt_number": receipt["receipt_number"], "purchase_order_id": str(order["id"]), "purchase_order_line_id": str(line["purchase_order_line_id"]), "base_unit_cost": str(line["base_unit_cost"]), "landed_cost_amount": str(landed)}, idempotency_key=f"purchasing:receipt:{receipt_id}:line:{line[\'id\']}")',
            'metadata={"receipt_number": receipt["receipt_number"], "purchase_order_id": str(order["id"]), "purchase_order_line_id": str(line["purchase_order_line_id"]), "base_unit_cost": str(line["base_unit_cost"]), "landed_cost_amount": str(landed), "tracking_mode": (db.execute(text("SELECT tracking_mode FROM public.product_variants WHERE tenant_id=:t AND id=:v"),{"t":str(tenant_id),"v":str(line["variant_id"])}).scalar_one_or_none() or "QUANTITY"), **(line.get("tracking_details") or {})}, idempotency_key=f"purchasing:receipt:{receipt_id}:line:{line[\'id\']}")',
            "receipt canonical-ledger metadata")
        src = replace_once(src,
            'INSERT INTO public.purchase_return_lines(tenant_id,purchase_return_id,purchase_receipt_line_id,variant_id,quantity,unit_cost,supplier_credit_unit_cost,reason) VALUES(:t,:r,:source,:variant,:qty,:cost,:supplier_cost,:reason)',
            'INSERT INTO public.purchase_return_lines(tenant_id,purchase_return_id,purchase_receipt_line_id,variant_id,quantity,unit_cost,supplier_credit_unit_cost,reason,tracking_details) VALUES(:t,:r,:source,:variant,:qty,:cost,:supplier_cost,:reason,CAST(:tracking AS jsonb))',
            "supplier return tracking-details persistence")
        src = replace_once(src,
            '"supplier_cost": supplier_credit_cost, "reason": item.reason})',
            '"supplier_cost": supplier_credit_cost, "reason": item.reason, "tracking": __import__("json").dumps({"serial_ids":[str(x) for x in item.serial_ids],"lot_allocations":[{"lot_id":str(x.lot_id),"quantity":str(x.quantity)} for x in item.lot_allocations]})})',
            "supplier return tracking-details payload")
        src = replace_once(src,
            'metadata={"return_number": row["return_number"], "purchase_receipt_id": str(receipt["id"]), "receipt_line_id": str(line["purchase_receipt_line_id"])}, idempotency_key=f"purchasing:return:{return_id}:line:{line[\'id\']}")',
            'metadata={"return_number": row["return_number"], "purchase_receipt_id": str(receipt["id"]), "receipt_line_id": str(line["purchase_receipt_line_id"]), "tracking_mode": (db.execute(text("SELECT tracking_mode FROM public.product_variants WHERE tenant_id=:t AND id=:v"),{"t":str(tenant_id),"v":str(line["variant_id"])}).scalar_one_or_none() or "QUANTITY"), **(line.get("tracking_details") or {})}, idempotency_key=f"purchasing:return:{return_id}:line:{line[\'id\']}")',
            "supplier return canonical-ledger metadata")
        changes[p] = src

        # SALES RETURNS: preserve original cost while identifying the returned units/lots.
        p = paths["commerce"]
        src = p.read_text()
        src = replace_once(src,
            'class ReturnLineIn(Strict):\n    sale_line_id: UUID\n    quantity: Decimal = Field(gt=0)',
            'class ReturnLineIn(Strict):\n    sale_line_id: UUID\n    quantity: Decimal = Field(gt=0)\n    serial_ids: list[UUID] = Field(default_factory=list, max_length=200)\n    lot_allocations: list[dict[str, Any]] = Field(default_factory=list, max_length=200)',
            "sale return trace inputs")
        src = replace_once(src,
            'INSERT INTO sale_return_lines(tenant_id,return_id,sale_line_id,variant_id,quantity,unit_price,discount_amount,tax_amount,line_total) VALUES(:t,:r,:sl,:v,:q,:u,:d,:tax,:total)',
            'INSERT INTO sale_return_lines(tenant_id,return_id,sale_line_id,variant_id,quantity,unit_price,discount_amount,tax_amount,line_total,tracking_details) VALUES(:t,:r,:sl,:v,:q,:u,:d,:tax,:total,CAST(:tracking AS jsonb))',
            "sale return tracking-details persistence")
        src = replace_once(src,
            '{"t":str(tenant_id),"r":str(return_id),"sl":str(req_line.sale_line_id),"v":str(line["product_variant_id"]),"q":str(req_line.quantity),"u":str(line["unit_price"]),"d":str(line_discount),"tax":str(line_tax),"total":str(line_total)})',
            '{"t":str(tenant_id),"r":str(return_id),"sl":str(req_line.sale_line_id),"v":str(line["product_variant_id"]),"q":str(req_line.quantity),"u":str(line["unit_price"]),"d":str(line_discount),"tax":str(line_tax),"total":str(line_total),"tracking":__import__("json").dumps({"serial_ids":[str(x) for x in req_line.serial_ids],"lot_allocations":req_line.lot_allocations})})',
            "sale return tracking-details payload")
        src = replace_once(src,
            'post_ledger(db,tenant_id=tenant_id,actor_user_id=actor,location_id=return_location,variant_id=line["product_variant_id"],quantity_delta=q(req_line.quantity),unit_cost=original_unit_cost,transaction_type="RETURN",reference_type="sale_return",reference_id=return_id,idempotency_key=f"{idempotency_key or return_id}:inventory:{req_line.sale_line_id}",metadata={"sale_id":str(sale_id),"return_id":str(return_id),"cost_basis":"original_sale_inventory_ledger"},allow_zero_cost_receipt=True)',
            'tracking_mode=db.execute(text("SELECT tracking_mode FROM public.product_variants WHERE tenant_id=:t AND id=:v"),{"t":str(tenant_id),"v":str(line["product_variant_id"])}).scalar_one_or_none() or "QUANTITY"\n                tracking_details=db.execute(text("SELECT tracking_details FROM public.sale_return_lines WHERE tenant_id=:t AND return_id=:r AND sale_line_id=:sl"),{"t":str(tenant_id),"r":str(return_id),"sl":str(req_line.sale_line_id)}).scalar_one_or_none() or {}\n                metadata={"sale_id":str(sale_id),"return_id":str(return_id),"cost_basis":"original_sale_inventory_ledger","tracking_mode":tracking_mode,**dict(tracking_details)}\n                post_ledger(db,tenant_id=tenant_id,actor_user_id=actor,location_id=return_location,variant_id=line["product_variant_id"],quantity_delta=q(req_line.quantity),unit_cost=original_unit_cost,transaction_type="RETURN",reference_type="sale_return",reference_id=return_id,idempotency_key=f"{idempotency_key or return_id}:inventory:{req_line.sale_line_id}",metadata=metadata,allow_zero_cost_receipt=True)',
            "sale return canonical-ledger metadata")
        changes[p] = src

        # INVENTORY ADJUSTMENTS, STOCK COUNTS, AND TRANSFERS.
        p = paths["inventory"]
        src = p.read_text()
        src = replace_once(src,
            'class AdjustmentLineIn(BaseModel):\n    variant_id: UUID\n    quantity_delta: Decimal\n    unit_cost: Decimal = Field(default=Decimal("0"), ge=0)\n    notes: str | None = None',
            'class TraceLotAllocationIn(BaseModel):\n    lot_id: UUID\n    quantity: Decimal = Field(gt=0, max_digits=20, decimal_places=6)\n\nclass TraceSerialUnitIn(BaseModel):\n    serial_number: str = Field(min_length=1, max_length=200)\n    imei: str | None = Field(default=None, max_length=32)\n\nclass AdjustmentLineIn(BaseModel):\n    variant_id: UUID\n    quantity_delta: Decimal\n    unit_cost: Decimal = Field(default=Decimal("0"), ge=0)\n    notes: str | None = None\n    serial_ids: list[UUID] = Field(default_factory=list, max_length=200)\n    serial_units: list[TraceSerialUnitIn] = Field(default_factory=list, max_length=200)\n    lot_allocations: list[TraceLotAllocationIn] = Field(default_factory=list, max_length=200)\n    lot_receipt: dict[str, Any] | None = None',
            "adjustment trace models")
        src = replace_once(src,
            'class CountLineIn(BaseModel):\n    variant_id: UUID\n    counted_quantity: Decimal | None = Field(default=None, ge=0)',
            'class CountLineIn(BaseModel):\n    variant_id: UUID\n    counted_quantity: Decimal | None = Field(default=None, ge=0)\n    serial_ids: list[UUID] = Field(default_factory=list, max_length=200)\n    serial_units: list[TraceSerialUnitIn] = Field(default_factory=list, max_length=200)\n    lot_allocations: list[TraceLotAllocationIn] = Field(default_factory=list, max_length=200)\n    lot_receipt: dict[str, Any] | None = None',
            "count trace models")
        src = replace_once(src,
            'class TransferLineIn(BaseModel):\n    variant_id: UUID; quantity: Decimal = Field(gt=0)',
            'class TransferLineIn(BaseModel):\n    variant_id: UUID; quantity: Decimal = Field(gt=0)\n    serial_ids: list[UUID] = Field(default_factory=list, max_length=200)\n    lot_allocations: list[TraceLotAllocationIn] = Field(default_factory=list, max_length=200)',
            "transfer trace models")
        src = replace_once(src,
            'for line in body.lines: db.add(InventoryTransferLine(tenant_id=tenant_id, transfer_id=row.id, variant_id=line.variant_id, requested_quantity=q(line.quantity)))',
            '''for line in body.lines:
        db.add(InventoryTransferLine(tenant_id=tenant_id, transfer_id=row.id, variant_id=line.variant_id, requested_quantity=q(line.quantity)))
        db.flush()
        detail={"serial_ids":[str(x) for x in line.serial_ids],"lot_allocations":[{"lot_id":str(x.lot_id),"quantity":str(x.quantity)} for x in line.lot_allocations]}
        db.execute(text("UPDATE public.inventory_transfer_lines SET tracking_details=CAST(:d AS jsonb) WHERE tenant_id=:t AND transfer_id=:r AND variant_id=:v"),{"d":__import__("json").dumps(detail),"t":str(tenant_id),"r":str(row.id),"v":str(line.variant_id)})''',
            "persist transfer trace details")
        src = replace_once(src,
            'post_ledger(db, tenant_id=tenant_id, actor_user_id=actor, location_id=row.location_id, variant_id=line.variant_id, quantity_delta=line.quantity_delta, unit_cost=line.unit_cost, transaction_type="ADJUSTMENT", reference_type="inventory_adjustment", reference_id=row.id, metadata={"reason_code": row.reason_code, "notes": line.notes})',
            '''tracking_details=db.execute(text("SELECT tracking_details FROM public.inventory_adjustment_lines WHERE tenant_id=:t AND adjustment_id=:r AND variant_id=:v"),{"t":str(tenant_id),"r":str(row.id),"v":str(line.variant_id)}).scalar_one_or_none() or {}
        metadata={"reason_code":row.reason_code,"notes":line.notes,"tracking_mode":(db.execute(text("SELECT tracking_mode FROM public.product_variants WHERE tenant_id=:t AND id=:v"),{"t":str(tenant_id),"v":str(line.variant_id)}).scalar_one_or_none() or "QUANTITY"),**dict(tracking_details)}
        post_ledger(db, tenant_id=tenant_id, actor_user_id=actor, location_id=row.location_id, variant_id=line.variant_id, quantity_delta=line.quantity_delta, unit_cost=line.unit_cost, transaction_type="ADJUSTMENT", reference_type="inventory_adjustment", reference_id=row.id, metadata=metadata)''',
            "adjustment canonical-ledger metadata")
        src = replace_once(src,
            'for line in body.lines:\n        db.add(InventoryAdjustmentLine(tenant_id=tenant_id, adjustment_id=row.id, variant_id=line.variant_id, quantity_delta=q(line.quantity_delta), unit_cost=q(line.unit_cost), notes=line.notes))',
            '''for line in body.lines:
        db.add(InventoryAdjustmentLine(tenant_id=tenant_id, adjustment_id=row.id, variant_id=line.variant_id, quantity_delta=q(line.quantity_delta), unit_cost=q(line.unit_cost), notes=line.notes))
        db.flush()
        detail={"serial_ids":[str(x) for x in line.serial_ids],"serial_units":[x.model_dump(mode="json") for x in line.serial_units],"lot_allocations":[{"lot_id":str(x.lot_id),"quantity":str(x.quantity)} for x in line.lot_allocations]}
        if line.lot_receipt: detail["lot_receipt"]=line.lot_receipt
        db.execute(text("UPDATE public.inventory_adjustment_lines SET tracking_details=CAST(:d AS jsonb) WHERE tenant_id=:t AND adjustment_id=:r AND variant_id=:v"),{"d":__import__("json").dumps(detail),"t":str(tenant_id),"r":str(row.id),"v":str(line.variant_id)})''',
            "persist adjustment trace details")
        src = replace_once(src,
            '        line.counted_quantity = item.counted_quantity\n        line.variance_quantity = None if item.counted_quantity is None else q(item.counted_quantity - line.expected_quantity)',
            '''        line.counted_quantity = item.counted_quantity
        line.variance_quantity = None if item.counted_quantity is None else q(item.counted_quantity - line.expected_quantity)
        detail={"serial_ids":[str(x) for x in item.serial_ids],"serial_units":[x.model_dump(mode="json") for x in item.serial_units],"lot_allocations":[{"lot_id":str(x.lot_id),"quantity":str(x.quantity)} for x in item.lot_allocations]}
        if item.lot_receipt: detail["lot_receipt"]=item.lot_receipt
        db.execute(text("UPDATE public.stock_count_lines SET tracking_details=CAST(:d AS jsonb) WHERE tenant_id=:t AND stock_count_id=:r AND variant_id=:v"),{"d":__import__("json").dumps(detail),"t":str(tenant_id),"r":str(count_id),"v":str(item.variant_id)})''',
            "persist stock count trace details")
        src = replace_once(src,
            'post_ledger(db, tenant_id=tenant_id, actor_user_id=actor, location_id=row.location_id, variant_id=line.variant_id, quantity_delta=variance, unit_cost=q(line.unit_cost), transaction_type="COUNT_RECONCILIATION", reference_type="stock_count", reference_id=row.id, metadata={"expected_quantity": str(line.expected_quantity), "counted_quantity": str(line.counted_quantity)})',
            '''tracking_details=db.execute(text("SELECT tracking_details FROM public.stock_count_lines WHERE tenant_id=:t AND stock_count_id=:r AND variant_id=:v"),{"t":str(tenant_id),"r":str(row.id),"v":str(line.variant_id)}).scalar_one_or_none() or {}
            metadata={"expected_quantity":str(line.expected_quantity),"counted_quantity":str(line.counted_quantity),"tracking_mode":(db.execute(text("SELECT tracking_mode FROM public.product_variants WHERE tenant_id=:t AND id=:v"),{"t":str(tenant_id),"v":str(line.variant_id)}).scalar_one_or_none() or "QUANTITY"),**dict(tracking_details)}
            post_ledger(db, tenant_id=tenant_id, actor_user_id=actor, location_id=row.location_id, variant_id=line.variant_id, quantity_delta=variance, unit_cost=q(line.unit_cost), transaction_type="COUNT_RECONCILIATION", reference_type="stock_count", reference_id=row.id, metadata=metadata)''',
            "count canonical-ledger metadata")
        src = replace_once(src,
            'post_ledger(db, tenant_id=tenant_id, actor_user_id=actor, location_id=row.source_location_id, variant_id=line.variant_id, quantity_delta=-remaining, unit_cost=q(bal.average_cost), transaction_type="TRANSFER_OUT", reference_type="inventory_transfer", reference_id=row.id, metadata={"destination_location_id": str(row.destination_location_id)})',
            '''tracking_details=db.execute(text("SELECT tracking_details FROM public.inventory_transfer_lines WHERE tenant_id=:t AND transfer_id=:r AND variant_id=:v"),{"t":str(tenant_id),"r":str(row.id),"v":str(line.variant_id)}).scalar_one_or_none() or {}
        metadata={"destination_location_id":str(row.destination_location_id),"tracking_mode":(db.execute(text("SELECT tracking_mode FROM public.product_variants WHERE tenant_id=:t AND id=:v"),{"t":str(tenant_id),"v":str(line.variant_id)}).scalar_one_or_none() or "QUANTITY"),**dict(tracking_details)}
        post_ledger(db, tenant_id=tenant_id, actor_user_id=actor, location_id=row.source_location_id, variant_id=line.variant_id, quantity_delta=-remaining, unit_cost=q(bal.average_cost), transaction_type="TRANSFER_OUT", reference_type="inventory_transfer", reference_id=row.id, metadata=metadata)''',
            "transfer-out canonical-ledger metadata")
        # Transfer destination receipt uses the dispatch identities and source lot facts; a lot gets a location-specific id.
        src = replace_once(src,
            'post_ledger(db, tenant_id=tenant_id, actor_user_id=actor, location_id=row.destination_location_id, variant_id=line.variant_id, quantity_delta=qty, unit_cost=q(line.unit_cost), transaction_type="TRANSFER_IN", reference_type="inventory_transfer", reference_id=row.id, metadata={"source_location_id": str(row.source_location_id)})',
            '''tracking_details=db.execute(text("SELECT tracking_details FROM public.inventory_transfer_lines WHERE tenant_id=:t AND transfer_id=:r AND variant_id=:v"),{"t":str(tenant_id),"r":str(row.id),"v":str(line.variant_id)}).scalar_one_or_none() or {}
        mode=db.execute(text("SELECT tracking_mode FROM public.product_variants WHERE tenant_id=:t AND id=:v"),{"t":str(tenant_id),"v":str(line.variant_id)}).scalar_one_or_none() or "QUANTITY"
        metadata={"source_location_id":str(row.source_location_id),"tracking_mode":mode,**dict(tracking_details)}
        if mode == "BATCH":
            allocations=(tracking_details or {}).get("lot_allocations",[]); destination_lots=[]
            for allocation in allocations:
                source_lot=db.execute(text("SELECT lot_number,expires_on,manufactured_on,unit_cost FROM public.inventory_lots WHERE tenant_id=:t AND id=:id AND variant_id=:v AND location_id=:loc"),{"t":str(tenant_id),"id":allocation["lot_id"],"v":str(line.variant_id),"loc":str(row.source_location_id)}).mappings().first()
                if not source_lot: raise HTTPException(409,"A transfer batch could not be traced back to its source lot")
                destination_lots.append({"lot_number":f"{source_lot['lot_number']}-TR-{str(row.id).replace('-', '')[:8]}","expires_on":source_lot["expires_on"].isoformat() if source_lot["expires_on"] else None,"manufactured_on":source_lot["manufactured_on"].isoformat() if source_lot["manufactured_on"] else None,"unit_cost":str(source_lot["unit_cost"]),"quantity":str(allocation["quantity"])})
            metadata["lot_receipt_allocations"]=destination_lots
        post_ledger(db, tenant_id=tenant_id, actor_user_id=actor, location_id=row.destination_location_id, variant_id=line.variant_id, quantity_delta=qty, unit_cost=q(line.unit_cost), transaction_type="TRANSFER_IN", reference_type="inventory_transfer", reference_id=row.id, metadata=metadata)''',
            "transfer-in canonical-ledger metadata")
        changes[p] = src

    except RuntimeError as exc:
        print(f"Preflight stopped: {exc}", file=sys.stderr)
        return 3

    # All source anchors passed. Write the three changed files only after full preflight.
    if args.dry_run:
        print("Dry-run passed. Planned workflow edits:")
        for path, content in changes.items(): print(f"  {path.relative_to(repo)}: {len(content)} chars")
        return 0
    for path, content in changes.items(): path.write_text(content)
    print("Tracked workflow source edits applied. Next run API tests, web typecheck/build and disposable PostgreSQL replay.")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
