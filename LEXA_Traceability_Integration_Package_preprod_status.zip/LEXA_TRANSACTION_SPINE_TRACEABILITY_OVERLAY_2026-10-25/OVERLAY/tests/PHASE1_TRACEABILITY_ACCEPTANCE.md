# Phase 1 traceability acceptance test matrix

| Area | Test | Expected result |
|---|---|---|
| Tenant security | Tenant B reads Tenant A serial/lot by UUID | 404/empty; no row information leaked |
| Tenant security | Tenant B posts a receipt with Tenant A location/variant | Rejected; no ledger row committed |
| Mode configuration | Change to SERIAL while existing on-hand quantity is non-zero | 409; no mode change |
| Serial receipt | Receive N unique serials with unit cost | One quantity-ledger receipt of N and N registered serials in one transaction |
| Serial receipt | Duplicate serial or IMEI | Rejected; no partial balance/register writes |
| Serial sale | Sell one in-stock serial | One linked negative movement; serial becomes SOLD |
| Serial sale | Sell the same serial concurrently/twice | One transaction succeeds; the other fails; quantity is not oversold |
| Serial sale | Serial belongs to another variant/location | Rejected |
| Serial return | Return a unit not sold by the tenant | Rejected |
| Batch receipt | Receive quantity with lot and expiry | Balance, lot row and lot movement agree |
| Batch sale | Several lots with a FEFO allocation | Earliest valid expiry is consumed first; allocated sum equals sale quantity |
| Batch sale | Use expired, recalled, depleted or wrong-location lot | Rejected |
| Idempotency | Retry the same request with the same key and body | Same response; no duplicate movement |
| Idempotency | Reuse a key with a changed body | 409; no second movement |
| Ledger reconstruction | Sum each variant/location's movements in time order | Matches balance and every recorded `balance_after` |
| Auditability | Correct a posted receipt or count | New reversal/correction movement; no editing/deleting movement history |
| Existing flows | Receipt, transfer, count, sale return and adjustment on tracked variant | Each command passes identity allocations or fails closed; no quantity-only shortcut |
