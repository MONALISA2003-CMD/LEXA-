from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
overlay=ROOT/"OVERLAY"
api=(overlay/"apps/api/app/routes/transaction_trace.py").read_text()
sql=(overlay/"migrations/049_phase1_inventory_traceability.sql").read_text()
idx=(overlay/"migrations/050_transaction_spine_trace_indexes.sql").read_text()
installer=(ROOT/"APPLY/apply_transaction_spine_overlay.py").read_text()
page=(overlay/"apps/web/app/commerce/traceability/page.tsx").read_text()
checks={
 "trace endpoint is read-only": not any(x in api.upper() for x in ("INSERT INTO", "UPDATE PUBLIC.", "DELETE FROM")),
 "trace links the business source transaction to the sale": "bt.id=s.transaction_id" in api and "reference_id=:sale_id" in api,
 "balanced journal totals are computed": "SUM(jl.debit)" in api and "SUM(jl.credit)" in api and 'journal["balanced"]' in api,
 "audit log and outbox included": "AuditLog" in api and "OutboxEvent" in api,
 "tenant and branch guards exist": "tenant_id=:t" in api and "ensure_branch_access" in api and "ensure_location_access" in api,
 "serial/IMEI uniqueness constraints exist": "UNIQUE (tenant_id, variant_id, serial_number)" in sql and "UNIQUE (tenant_id, imei)" in sql,
 "trace detail movement append-only": "prevent_inventory_trace_movement_mutation" in sql,
 "detail ledger reconciles at commit": "DEFERRABLE INITIALLY DEFERRED" in sql and "check_inventory_traceability_quantity" in sql,
 "FEFO allocation present in installer": "ORDER BY expires_on ASC NULLS LAST" in installer,
 "checkout uses serial IDs in inventory metadata": 'movement_metadata["serial_ids"]' in installer,
 "trace screen makes no downstream writes": "never records another sale" in page,
 "trace index migration is additive": "CREATE INDEX IF NOT EXISTS" in idx and "INSERT INTO public.schema_migrations" in idx,
}
for label,ok in checks.items(): print(("PASS" if ok else "FAIL")+" | "+label)
if not all(checks.values()): raise SystemExit(1)
