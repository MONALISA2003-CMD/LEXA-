"""Offline contracts for the guarded serial/batch workflow overlay."""
from pathlib import Path
ROOT = Path(__file__).resolve().parents[2]
SQL = (ROOT / "OVERLAY/migrations/051_tracked_inventory_workflow_integration.sql").read_text()
INSTALL = (ROOT / "APPLY/apply_tracked_workflow_integration.py").read_text()
checks = {
    "canonical purchase receipt is accepted": "'PURCHASE_RECEIPT'" in SQL and "purchase_receipt_lines ADD COLUMN" in SQL,
    "legacy standalone trace receipt is not double-inserted": "NEW.transaction_type='TRACEABLE_RECEIPT'" in SQL and "A traceable receipt must increase stock." in SQL,
    "clean replay reuses existing trigger registrations safely": "CREATE OR REPLACE FUNCTION public.guard_tracked_inventory_sale()" in SQL and "CREATE OR REPLACE FUNCTION public.apply_inventory_traceability_movement()" in SQL and "CREATE TRIGGER trg_guard_tracked_inventory_sale" not in SQL,
    "serial receipts create individual serial units": "INSERT INTO public.inventory_serial_units" in SQL and "serial_units" in SQL,
    "batch receipts create location-bound lots": "INSERT INTO public.inventory_lots" in SQL and "expires_on" in SQL,
    "supplier returns link serial/lot allocation details": "purchase_return_lines ADD COLUMN" in SQL and "'PURCHASE_RETURN'" in SQL,
    "supplier returns must match the originating receipt": "Returned serial does not belong to the selected goods receipt." in SQL and "Returned batch does not belong to the selected goods receipt." in SQL,
    "sale returns preserve the canonical RETURN transaction alias": "'RETURN' THEN 'SALE_RETURN'" in SQL,
    "serials cannot be reused in one movement": "A serial cannot be repeated" in SQL,
    "serial returns tie to their source sale": "Returned serial does not belong to this sale" in SQL,
    "transfer-out serials enter transit": "WHEN 'TRANSFER_OUT' THEN 'IN_TRANSIT'" in SQL,
    "transfer-in batch lots are recreated at destination": "lot_receipt_allocations" in SQL,
    "counts and adjustments accept exact identities": "inventory_adjustment_lines ADD COLUMN" in SQL and "stock_count_lines ADD COLUMN" in SQL,
    "detail quantity reconciliation remains deferred": "DEFERRABLE INITIALLY DEFERRED" in (ROOT / "OVERLAY/migrations/049_phase1_inventory_traceability.sql").read_text(),
    "canonical purchasing endpoint posts tracked details": "receipt canonical-ledger metadata" in INSTALL,
    "canonical supplier return endpoint posts tracked details": "supplier return canonical-ledger metadata" in INSTALL,
    "canonical sale return endpoint passes exact serial/lot data": "sale return canonical-ledger metadata" in INSTALL,
    "transfer dispatch and receipt use canonical ledger": "transfer-out canonical-ledger metadata" in INSTALL and "transfer-in canonical-ledger metadata" in INSTALL,
    "count and adjustment use canonical ledger": "count canonical-ledger metadata" in INSTALL and "adjustment canonical-ledger metadata" in INSTALL,
    "installer preflights before writing files": "All source anchors passed. Write the three changed files only after full preflight." in INSTALL,
}
for label, ok in checks.items(): print(("PASS" if ok else "FAIL") + " | " + label)
if not all(checks.values()): raise SystemExit(1)
