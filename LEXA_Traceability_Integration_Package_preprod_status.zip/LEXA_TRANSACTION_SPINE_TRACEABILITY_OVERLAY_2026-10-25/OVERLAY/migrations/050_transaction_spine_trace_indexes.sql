-- LEXA Phase 2: speed up read-only source-transaction tracing.
-- Additive only; no source transaction, payment, stock or journal rows are changed.
-- Apply only after the canonical 048 + 049 migrations on a disposable database first.
BEGIN;
CREATE INDEX IF NOT EXISTS inventory_transactions_source_transaction_trace_idx
  ON public.inventory_transactions (tenant_id, source_transaction_id, occurred_at, id)
  WHERE source_transaction_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS inventory_transactions_reference_trace_idx
  ON public.inventory_transactions (tenant_id, reference_type, reference_id, occurred_at, id);
CREATE INDEX IF NOT EXISTS transaction_lines_source_trace_idx
  ON public.transaction_lines (tenant_id, transaction_id, line_no, id);
CREATE INDEX IF NOT EXISTS payments_transaction_trace_idx
  ON public.payments (tenant_id, transaction_id, paid_at, id);
CREATE INDEX IF NOT EXISTS payment_allocations_sale_trace_idx
  ON public.payment_allocations (tenant_id, sale_id, payment_id, id)
  WHERE sale_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS journal_entries_source_trace_idx
  ON public.journal_entries (tenant_id, source_type, source_id, entry_date, id);
INSERT INTO public.schema_migrations(version)
VALUES ('050_transaction_spine_trace_indexes')
ON CONFLICT (version) DO NOTHING;
COMMIT;
