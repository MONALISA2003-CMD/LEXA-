-- LEXA Phase 1: serialized and batch/lot inventory.
-- Forward-only additive migration. Apply to a disposable PostgreSQL database first.
-- The existing inventory_transactions table remains the quantity source of truth.

BEGIN;

ALTER TABLE public.product_variants
  ADD COLUMN IF NOT EXISTS tracking_mode text NOT NULL DEFAULT 'QUANTITY';

DO $$ BEGIN
  ALTER TABLE public.product_variants
    ADD CONSTRAINT product_variants_tracking_mode_check
    CHECK (tracking_mode IN ('QUANTITY','SERIAL','BATCH'));
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

CREATE TABLE IF NOT EXISTS public.inventory_serial_units (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  variant_id uuid NOT NULL REFERENCES public.product_variants(id) ON DELETE RESTRICT,
  current_location_id uuid REFERENCES public.locations(id) ON DELETE RESTRICT,
  serial_number text NOT NULL,
  imei text,
  status text NOT NULL DEFAULT 'IN_STOCK'
    CHECK (status IN ('IN_STOCK','SOLD','IN_TRANSIT','QUARANTINED','WRITTEN_OFF')),
  received_transaction_id uuid,
  sold_transaction_id uuid,
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT inventory_serial_number_nonblank CHECK (length(btrim(serial_number)) > 0),
  CONSTRAINT inventory_serial_tenant_variant_id UNIQUE (tenant_id, variant_id, serial_number),
  CONSTRAINT inventory_serial_tenant_imei_id UNIQUE (tenant_id, imei)
);
CREATE INDEX IF NOT EXISTS inventory_serial_units_lookup_idx
  ON public.inventory_serial_units (tenant_id, variant_id, current_location_id, status);
CREATE INDEX IF NOT EXISTS inventory_serial_units_imei_idx
  ON public.inventory_serial_units (tenant_id, imei) WHERE imei IS NOT NULL;

CREATE TABLE IF NOT EXISTS public.inventory_lots (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  variant_id uuid NOT NULL REFERENCES public.product_variants(id) ON DELETE RESTRICT,
  location_id uuid NOT NULL REFERENCES public.locations(id) ON DELETE RESTRICT,
  lot_number text NOT NULL,
  expires_on date,
  manufactured_on date,
  received_quantity numeric(20,6) NOT NULL CHECK (received_quantity > 0),
  remaining_quantity numeric(20,6) NOT NULL CHECK (remaining_quantity >= 0),
  unit_cost numeric(20,6) NOT NULL CHECK (unit_cost >= 0),
  status text NOT NULL DEFAULT 'ACTIVE' CHECK (status IN ('ACTIVE','QUARANTINED','EXPIRED','DEPLETED','RECALLED')),
  received_transaction_id uuid,
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT inventory_lot_nonblank CHECK (length(btrim(lot_number)) > 0),
  CONSTRAINT inventory_lot_quantity_bounds CHECK (remaining_quantity <= received_quantity),
  CONSTRAINT inventory_lot_identity UNIQUE (tenant_id, variant_id, location_id, lot_number)
);
CREATE INDEX IF NOT EXISTS inventory_lots_fefo_idx
  ON public.inventory_lots (tenant_id, variant_id, location_id, expires_on, created_at)
  WHERE status = 'ACTIVE' AND remaining_quantity > 0;

-- Links every tracked-unit change to the immutable quantity-ledger movement.
CREATE TABLE IF NOT EXISTS public.inventory_serial_movements (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  serial_unit_id uuid NOT NULL REFERENCES public.inventory_serial_units(id) ON DELETE RESTRICT,
  inventory_transaction_id uuid NOT NULL REFERENCES public.inventory_transactions(id) ON DELETE RESTRICT,
  movement_type text NOT NULL CHECK (movement_type IN ('RECEIPT','SALE','SALE_RETURN','TRANSFER_OUT','TRANSFER_IN','ADJUSTMENT','COUNT_RECONCILIATION','QUARANTINE','WRITE_OFF')),
  from_status text,
  to_status text NOT NULL,
  from_location_id uuid REFERENCES public.locations(id) ON DELETE RESTRICT,
  to_location_id uuid REFERENCES public.locations(id) ON DELETE RESTRICT,
  occurred_at timestamptz NOT NULL DEFAULT now(),
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  UNIQUE (tenant_id, serial_unit_id, inventory_transaction_id)
);
CREATE INDEX IF NOT EXISTS inventory_serial_movements_history_idx
  ON public.inventory_serial_movements (tenant_id, serial_unit_id, occurred_at, id);

CREATE TABLE IF NOT EXISTS public.inventory_lot_movements (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  lot_id uuid NOT NULL REFERENCES public.inventory_lots(id) ON DELETE RESTRICT,
  inventory_transaction_id uuid NOT NULL REFERENCES public.inventory_transactions(id) ON DELETE RESTRICT,
  quantity_delta numeric(20,6) NOT NULL CHECK (quantity_delta <> 0),
  remaining_after numeric(20,6) NOT NULL CHECK (remaining_after >= 0),
  movement_type text NOT NULL CHECK (movement_type IN ('RECEIPT','SALE','SALE_RETURN','TRANSFER_OUT','TRANSFER_IN','ADJUSTMENT','COUNT_RECONCILIATION','SUPPLIER_RETURN','WRITE_OFF')),
  occurred_at timestamptz NOT NULL DEFAULT now(),
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  UNIQUE (tenant_id, lot_id, inventory_transaction_id)
);
CREATE INDEX IF NOT EXISTS inventory_lot_movements_history_idx
  ON public.inventory_lot_movements (tenant_id, lot_id, occurred_at, id);

-- Composite tenant keys keep a movement's tenant, variant and location aligned.
-- These constraints prevent an accidental cross-tenant reference even if a handler
-- forgets a filter. RLS is still required for row-level read/write isolation.
DO $$ BEGIN
  ALTER TABLE public.product_variants ADD CONSTRAINT product_variants_tenant_id_pair_unique UNIQUE (tenant_id,id);
EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN
  ALTER TABLE public.locations ADD CONSTRAINT locations_tenant_id_pair_unique UNIQUE (tenant_id,id);
EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN
  ALTER TABLE public.inventory_serial_units
    ADD CONSTRAINT inventory_serial_variant_tenant_fk
    FOREIGN KEY (tenant_id, variant_id) REFERENCES public.product_variants(tenant_id, id) NOT VALID;
EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN
  ALTER TABLE public.inventory_serial_units
    ADD CONSTRAINT inventory_serial_location_tenant_fk
    FOREIGN KEY (tenant_id, current_location_id) REFERENCES public.locations(tenant_id, id) NOT VALID;
EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN
  ALTER TABLE public.inventory_lots
    ADD CONSTRAINT inventory_lot_variant_tenant_fk
    FOREIGN KEY (tenant_id, variant_id) REFERENCES public.product_variants(tenant_id, id) NOT VALID;
EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN
  ALTER TABLE public.inventory_lots
    ADD CONSTRAINT inventory_lot_location_tenant_fk
    FOREIGN KEY (tenant_id, location_id) REFERENCES public.locations(tenant_id, id) NOT VALID;
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

-- Default-deny unless the existing app database role has tenant context set. The
-- API's existing DB-role/RLS bootstrap must set app.tenant_id to the active tenant.
DO $$ DECLARE tbl text; BEGIN
  FOREACH tbl IN ARRAY ARRAY['inventory_serial_units','inventory_lots','inventory_serial_movements','inventory_lot_movements'] LOOP
    EXECUTE format('ALTER TABLE public.%I ENABLE ROW LEVEL SECURITY', tbl);
    EXECUTE format('ALTER TABLE public.%I FORCE ROW LEVEL SECURITY', tbl);
    EXECUTE format('DROP POLICY IF EXISTS %I ON public.%I', tbl || '_tenant_isolation', tbl);
    EXECUTE format(
      'CREATE POLICY %I ON public.%I USING (tenant_id = NULLIF(current_setting(''app.tenant_id'', true), '''')::uuid) WITH CHECK (tenant_id = NULLIF(current_setting(''app.tenant_id'', true), '''')::uuid)',
      tbl || '_tenant_isolation', tbl
    );
  END LOOP;
END $$;

-- Immutable-history guard: users may append movements, but cannot rewrite or erase them.
CREATE OR REPLACE FUNCTION public.prevent_inventory_trace_movement_mutation()
RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  RAISE EXCEPTION 'Inventory traceability history is append-only; post a correcting movement instead.';
END $$;
DROP TRIGGER IF EXISTS trg_inventory_serial_movement_immutable ON public.inventory_serial_movements;
CREATE TRIGGER trg_inventory_serial_movement_immutable
  BEFORE UPDATE OR DELETE ON public.inventory_serial_movements
  FOR EACH ROW EXECUTE FUNCTION public.prevent_inventory_trace_movement_mutation();
DROP TRIGGER IF EXISTS trg_inventory_lot_movement_immutable ON public.inventory_lot_movements;
CREATE TRIGGER trg_inventory_lot_movement_immutable
  BEFORE UPDATE OR DELETE ON public.inventory_lot_movements
  FOR EACH ROW EXECUTE FUNCTION public.prevent_inventory_trace_movement_mutation();

-- Database-level sale guard. A serial-controlled item cannot be sold through the
-- quantity-only path. Checkout must pass serial_ids in inventory transaction metadata;
-- the API route validates/consumes them atomically before commit (see integration guide).
CREATE OR REPLACE FUNCTION public.guard_tracked_inventory_sale()
RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE mode text;
DECLARE unit_ids jsonb;
DECLARE lot_allocations jsonb;
DECLARE item jsonb;
DECLARE unit_row record;
DECLARE lot_row record;
DECLARE requested numeric;
DECLARE expected_status text;
BEGIN
  SELECT tracking_mode INTO mode FROM public.product_variants
    WHERE tenant_id = NEW.tenant_id AND id = NEW.variant_id;
  IF mode IS NULL THEN
    RAISE EXCEPTION 'Inventory movement references a product option outside its business.';
  END IF;

  IF mode = 'SERIAL' AND NEW.transaction_type NOT IN ('TRACEABLE_RECEIPT','SALE','SALE_RETURN','TRANSFER_OUT','TRANSFER_IN') THEN
    RAISE EXCEPTION 'This serial-tracked item must be processed through a workflow that records the individual serial numbers.';
  END IF;
  IF mode = 'BATCH' AND NEW.transaction_type NOT IN ('TRACEABLE_RECEIPT','SALE','SALE_RETURN','TRANSFER_OUT','TRANSFER_IN') THEN
    RAISE EXCEPTION 'This batch-tracked item must be processed through a workflow that records its lot allocations.';
  END IF;

  IF mode = 'SERIAL' AND NEW.transaction_type IN ('SALE','SALE_RETURN','TRANSFER_OUT','TRANSFER_IN') THEN
    unit_ids := COALESCE(NEW.metadata->'serial_ids', '[]'::jsonb);
    IF jsonb_typeof(unit_ids) <> 'array' OR jsonb_array_length(unit_ids) <> abs(NEW.quantity_delta) THEN
      RAISE EXCEPTION 'Serial-controlled stock requires exactly one selected serial for each whole unit.';
    END IF;
    IF NEW.quantity_delta <> trunc(NEW.quantity_delta) THEN
      RAISE EXCEPTION 'Serial-controlled stock must move in whole units.';
    END IF;
    expected_status := CASE NEW.transaction_type
      WHEN 'SALE' THEN 'IN_STOCK'
      WHEN 'TRANSFER_OUT' THEN 'IN_STOCK'
      WHEN 'TRANSFER_IN' THEN 'IN_TRANSIT'
      WHEN 'SALE_RETURN' THEN 'SOLD'
    END;
    FOR item IN SELECT value FROM jsonb_array_elements(unit_ids) LOOP
      IF (item #>> '{}') IS NULL OR btrim(item #>> '{}') = '' THEN
        RAISE EXCEPTION 'Serial id cannot be blank.';
      END IF;
      SELECT id,status,current_location_id,variant_id INTO unit_row
        FROM public.inventory_serial_units
        WHERE tenant_id=NEW.tenant_id AND id=(item #>> '{}')::uuid
        FOR UPDATE;
      IF NOT FOUND OR unit_row.variant_id <> NEW.variant_id OR unit_row.status <> expected_status THEN
        RAISE EXCEPTION 'One or more serial numbers are unavailable, already sold, or belong to another product option.';
      END IF;
      IF NEW.transaction_type IN ('SALE','TRANSFER_OUT') AND unit_row.current_location_id IS DISTINCT FROM NEW.location_id THEN
        RAISE EXCEPTION 'A selected serial number is not available at this stock location.';
      END IF;
    END LOOP;
  END IF;

  IF mode = 'BATCH' AND NEW.transaction_type IN ('SALE','SALE_RETURN','TRANSFER_OUT','TRANSFER_IN') THEN
    lot_allocations := COALESCE(NEW.metadata->'lot_allocations', '[]'::jsonb);
    IF jsonb_typeof(lot_allocations) <> 'array' OR jsonb_array_length(lot_allocations) = 0 THEN
      RAISE EXCEPTION 'Batch-controlled stock requires lot allocations for this movement.';
    END IF;
    SELECT COALESCE(sum((x->>'quantity')::numeric),0) INTO requested
      FROM jsonb_array_elements(lot_allocations) x;
    IF abs(NEW.quantity_delta) <> requested THEN
      RAISE EXCEPTION 'Lot allocation quantities must equal the stock movement quantity.';
    END IF;
    FOR item IN SELECT value FROM jsonb_array_elements(lot_allocations) LOOP
      IF COALESCE((item->>'quantity')::numeric,0) <= 0 THEN
        RAISE EXCEPTION 'Lot allocation quantity must be positive.';
      END IF;
      SELECT id,remaining_quantity,expires_on,status,location_id,variant_id INTO lot_row
        FROM public.inventory_lots
        WHERE tenant_id=NEW.tenant_id AND id=(item->>'lot_id')::uuid
        FOR UPDATE;
      IF NOT FOUND OR lot_row.variant_id <> NEW.variant_id OR lot_row.location_id <> NEW.location_id THEN
        RAISE EXCEPTION 'One or more lots do not belong to this product option and stock location.';
      END IF;
      IF NEW.transaction_type IN ('SALE','TRANSFER_OUT') THEN
        IF lot_row.status <> 'ACTIVE' OR (lot_row.expires_on IS NOT NULL AND lot_row.expires_on < current_date) THEN
          RAISE EXCEPTION 'Expired or unavailable batches cannot be sold or transferred.';
        END IF;
        IF lot_row.remaining_quantity < (item->>'quantity')::numeric THEN
          RAISE EXCEPTION 'The selected batch does not have enough stock.';
        END IF;
      END IF;
    END LOOP;
  END IF;
  RETURN NEW;
END $$;

CREATE OR REPLACE FUNCTION public.apply_inventory_traceability_movement()
RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE mode text;
DECLARE item jsonb;
DECLARE unit_row record;
DECLARE lot_row record;
DECLARE delta numeric;
DECLARE new_status text;
DECLARE old_status text;
DECLARE old_location uuid;
DECLARE new_location uuid;
DECLARE move_type text;
BEGIN
  SELECT tracking_mode INTO mode FROM public.product_variants
    WHERE tenant_id=NEW.tenant_id AND id=NEW.variant_id;

  IF mode = 'SERIAL' AND NEW.transaction_type NOT IN ('TRACEABLE_RECEIPT','SALE','SALE_RETURN','TRANSFER_OUT','TRANSFER_IN') THEN
    RAISE EXCEPTION 'This serial-tracked item must be processed through a workflow that records the individual serial numbers.';
  END IF;
  IF mode = 'BATCH' AND NEW.transaction_type NOT IN ('TRACEABLE_RECEIPT','SALE','SALE_RETURN','TRANSFER_OUT','TRANSFER_IN') THEN
    RAISE EXCEPTION 'This batch-tracked item must be processed through a workflow that records its lot allocations.';
  END IF;

  IF mode = 'SERIAL' AND NEW.transaction_type IN ('SALE','SALE_RETURN','TRANSFER_OUT','TRANSFER_IN') THEN
    FOR item IN SELECT value FROM jsonb_array_elements(COALESCE(NEW.metadata->'serial_ids','[]'::jsonb)) LOOP
      SELECT id,status,current_location_id INTO unit_row FROM public.inventory_serial_units
        WHERE tenant_id=NEW.tenant_id AND id=(item #>> '{}')::uuid FOR UPDATE;
      old_status := unit_row.status;
      old_location := unit_row.current_location_id;
      new_status := CASE NEW.transaction_type
        WHEN 'SALE' THEN 'SOLD'
        WHEN 'SALE_RETURN' THEN 'IN_STOCK'
        WHEN 'TRANSFER_OUT' THEN 'IN_TRANSIT'
        WHEN 'TRANSFER_IN' THEN 'IN_STOCK'
      END;
      new_location := CASE WHEN new_status IN ('SOLD','IN_TRANSIT') THEN NULL ELSE NEW.location_id END;
      UPDATE public.inventory_serial_units SET status=new_status,current_location_id=new_location,
        sold_transaction_id=CASE WHEN NEW.transaction_type='SALE' THEN NEW.id WHEN NEW.transaction_type='SALE_RETURN' THEN NULL ELSE sold_transaction_id END,
        updated_at=now()
        WHERE tenant_id=NEW.tenant_id AND id=unit_row.id;
      move_type := NEW.transaction_type;
      INSERT INTO public.inventory_serial_movements(tenant_id,serial_unit_id,inventory_transaction_id,movement_type,from_status,to_status,from_location_id,to_location_id,metadata)
      VALUES(NEW.tenant_id,unit_row.id,NEW.id,move_type,old_status,new_status,old_location,new_location,COALESCE(NEW.metadata,'{}'::jsonb));
    END LOOP;
  END IF;

  IF mode = 'BATCH' AND NEW.transaction_type IN ('SALE','SALE_RETURN','TRANSFER_OUT','TRANSFER_IN') THEN
    FOR item IN SELECT value FROM jsonb_array_elements(COALESCE(NEW.metadata->'lot_allocations','[]'::jsonb)) LOOP
      SELECT id,remaining_quantity,status INTO lot_row FROM public.inventory_lots
        WHERE tenant_id=NEW.tenant_id AND id=(item->>'lot_id')::uuid FOR UPDATE;
      delta := (item->>'quantity')::numeric;
      IF NEW.transaction_type IN ('SALE','TRANSFER_OUT') THEN delta := -delta; END IF;
      UPDATE public.inventory_lots SET remaining_quantity=remaining_quantity+delta,
        status=CASE WHEN remaining_quantity+delta=0 THEN 'DEPLETED' WHEN remaining_quantity+delta>0 THEN 'ACTIVE' ELSE status END,
        updated_at=now()
        WHERE tenant_id=NEW.tenant_id AND id=lot_row.id;
      INSERT INTO public.inventory_lot_movements(tenant_id,lot_id,inventory_transaction_id,quantity_delta,remaining_after,movement_type,metadata)
      SELECT NEW.tenant_id,id,NEW.id,delta,remaining_quantity,NEW.transaction_type,COALESCE(NEW.metadata,'{}'::jsonb)
        FROM public.inventory_lots WHERE tenant_id=NEW.tenant_id AND id=lot_row.id;
    END LOOP;
  END IF;
  RETURN NEW;
END $$;

DROP TRIGGER IF EXISTS trg_guard_tracked_inventory_sale ON public.inventory_transactions;
CREATE TRIGGER trg_guard_tracked_inventory_sale
  BEFORE INSERT ON public.inventory_transactions
  FOR EACH ROW EXECUTE FUNCTION public.guard_tracked_inventory_sale();
DROP TRIGGER IF EXISTS trg_apply_inventory_traceability_movement ON public.inventory_transactions;
CREATE TRIGGER trg_apply_inventory_traceability_movement
  AFTER INSERT ON public.inventory_transactions
  FOR EACH ROW EXECUTE FUNCTION public.apply_inventory_traceability_movement();

-- At commit time, detail ledgers must explain the same quantity as the canonical
-- inventory ledger. The detail insert can occur after the inventory_transactions
-- insert because this check is deferred to transaction commit.
CREATE OR REPLACE FUNCTION public.check_inventory_traceability_quantity()
RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE mode text;
DECLARE detail_quantity numeric;
BEGIN
  SELECT tracking_mode INTO mode FROM public.product_variants
    WHERE tenant_id=NEW.tenant_id AND id=NEW.variant_id;
  IF mode='SERIAL' THEN
    SELECT count(*) INTO detail_quantity FROM public.inventory_serial_movements
      WHERE tenant_id=NEW.tenant_id AND inventory_transaction_id=NEW.id;
    IF detail_quantity <> abs(NEW.quantity_delta) THEN
      RAISE EXCEPTION 'Serial movement count (%) does not reconcile to inventory ledger quantity (%).', detail_quantity, abs(NEW.quantity_delta);
    END IF;
  ELSIF mode='BATCH' THEN
    SELECT COALESCE(sum(quantity_delta),0) INTO detail_quantity FROM public.inventory_lot_movements
      WHERE tenant_id=NEW.tenant_id AND inventory_transaction_id=NEW.id;
    IF detail_quantity <> NEW.quantity_delta THEN
      RAISE EXCEPTION 'Lot movement quantity (%) does not reconcile to inventory ledger quantity (%).', detail_quantity, NEW.quantity_delta;
    END IF;
  END IF;
  RETURN NULL;
END $$;
DROP TRIGGER IF EXISTS trg_inventory_trace_quantity_reconcile ON public.inventory_transactions;
CREATE CONSTRAINT TRIGGER trg_inventory_trace_quantity_reconcile
  AFTER INSERT ON public.inventory_transactions
  DEFERRABLE INITIALLY DEFERRED
  FOR EACH ROW EXECUTE FUNCTION public.check_inventory_traceability_quantity();

INSERT INTO public.schema_migrations(version)
VALUES ('049_phase1_inventory_traceability')
ON CONFLICT (version) DO NOTHING;

COMMIT;
