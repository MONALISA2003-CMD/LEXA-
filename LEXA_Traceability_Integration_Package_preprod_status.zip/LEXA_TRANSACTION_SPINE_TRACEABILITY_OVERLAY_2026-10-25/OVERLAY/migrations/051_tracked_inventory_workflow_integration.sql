-- LEXA migration 051: connect the traceability detail ledgers to canonical business workflows.
-- Designed for a clean replay after 048, 049 and 050. Never bypasses inventory_transactions.
BEGIN;

ALTER TABLE public.purchase_receipt_lines ADD COLUMN IF NOT EXISTS tracking_details jsonb NOT NULL DEFAULT '{}'::jsonb;
ALTER TABLE public.purchase_return_lines ADD COLUMN IF NOT EXISTS tracking_details jsonb NOT NULL DEFAULT '{}'::jsonb;
ALTER TABLE public.sale_return_lines ADD COLUMN IF NOT EXISTS tracking_details jsonb NOT NULL DEFAULT '{}'::jsonb;
ALTER TABLE public.inventory_transfer_lines ADD COLUMN IF NOT EXISTS tracking_details jsonb NOT NULL DEFAULT '{}'::jsonb;
ALTER TABLE public.inventory_adjustment_lines ADD COLUMN IF NOT EXISTS tracking_details jsonb NOT NULL DEFAULT '{}'::jsonb;
ALTER TABLE public.stock_count_lines ADD COLUMN IF NOT EXISTS tracking_details jsonb NOT NULL DEFAULT '{}'::jsonb;

-- Canonical receipt and supplier-return transaction types must pass the guard.
ALTER TABLE public.inventory_serial_movements DROP CONSTRAINT IF EXISTS inventory_serial_movements_movement_type_check;
ALTER TABLE public.inventory_serial_movements ADD CONSTRAINT inventory_serial_movements_movement_type_check
  CHECK (movement_type IN ('RECEIPT','PURCHASE_RECEIPT','SALE','SALE_RETURN','PURCHASE_RETURN','TRANSFER_OUT','TRANSFER_IN','ADJUSTMENT','COUNT_RECONCILIATION','QUARANTINE','WRITE_OFF'));
ALTER TABLE public.inventory_lot_movements DROP CONSTRAINT IF EXISTS inventory_lot_movements_movement_type_check;
ALTER TABLE public.inventory_lot_movements ADD CONSTRAINT inventory_lot_movements_movement_type_check
  CHECK (movement_type IN ('RECEIPT','PURCHASE_RECEIPT','SALE','SALE_RETURN','TRANSFER_OUT','TRANSFER_IN','ADJUSTMENT','COUNT_RECONCILIATION','SUPPLIER_RETURN','PURCHASE_RETURN','WRITE_OFF'));

-- Validate traced operations before the canonical quantity ledger accepts a movement.
CREATE OR REPLACE FUNCTION public.guard_tracked_inventory_sale()
RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE
 mode text; ids jsonb; items jsonb; item jsonb; serial_row record; lot_row record;
 qty numeric; receipt_units jsonb; transfer_lots jsonb; sold_reference uuid;
BEGIN
 SELECT tracking_mode INTO mode FROM public.product_variants WHERE tenant_id=NEW.tenant_id AND id=NEW.variant_id;
 IF mode IS NULL THEN RAISE EXCEPTION 'Inventory movement references a product option outside its business.'; END IF;
 IF mode='QUANTITY' THEN RETURN NEW; END IF;
 IF mode='SERIAL' THEN
  IF NEW.quantity_delta<>trunc(NEW.quantity_delta) THEN RAISE EXCEPTION 'Serial-controlled stock must move in whole units.'; END IF;
  IF NEW.transaction_type='PURCHASE_RECEIPT' OR (NEW.transaction_type IN ('ADJUSTMENT','COUNT_RECONCILIATION') AND NEW.quantity_delta>0) THEN
   receipt_units:=COALESCE(NEW.metadata->'serial_units',NEW.metadata->'serial_numbers','[]'::jsonb);
   IF jsonb_typeof(receipt_units)<>'array' OR jsonb_array_length(receipt_units)<>NEW.quantity_delta THEN RAISE EXCEPTION 'Serial receipt/positive correction requires one unique serial for every received unit.'; END IF;
   FOR item IN SELECT value FROM jsonb_array_elements(receipt_units) LOOP
    IF COALESCE(NULLIF(btrim(CASE WHEN jsonb_typeof(item)='string' THEN item#>>'{}' ELSE item->>'serial_number' END),''),'')='' THEN RAISE EXCEPTION 'Serial number cannot be blank.'; END IF;
   END LOOP;
  ELSIF NEW.transaction_type='TRACEABLE_RECEIPT' THEN
   IF NEW.quantity_delta<=0 THEN RAISE EXCEPTION 'A traceable receipt must increase stock.'; END IF;
  ELSIF NEW.transaction_type IN ('SALE','TRANSFER_OUT','PURCHASE_RETURN','ADJUSTMENT','COUNT_RECONCILIATION','SALE_RETURN','RETURN','TRANSFER_IN') THEN
   ids:=COALESCE(NEW.metadata->'serial_ids','[]'::jsonb);
   IF jsonb_typeof(ids)<>'array' OR jsonb_array_length(ids)<>abs(NEW.quantity_delta) THEN RAISE EXCEPTION 'Serial-controlled movements require one selected serial per whole unit.'; END IF;
   IF (SELECT count(DISTINCT value::text) FROM jsonb_array_elements(ids))<>jsonb_array_length(ids) THEN RAISE EXCEPTION 'A serial cannot be repeated in one inventory movement.'; END IF;
   FOR item IN SELECT value FROM jsonb_array_elements(ids) LOOP
    SELECT id,status,current_location_id,variant_id,sold_transaction_id,received_transaction_id INTO serial_row FROM public.inventory_serial_units WHERE tenant_id=NEW.tenant_id AND id=(item#>>'{}')::uuid FOR UPDATE;
    IF NOT FOUND OR serial_row.variant_id<>NEW.variant_id THEN RAISE EXCEPTION 'Selected serial is unavailable or belongs to another product.'; END IF;
    IF NEW.transaction_type IN ('SALE','TRANSFER_OUT','PURCHASE_RETURN','ADJUSTMENT','COUNT_RECONCILIATION') AND (NEW.quantity_delta>=0 OR serial_row.status<>'IN_STOCK' OR serial_row.current_location_id IS DISTINCT FROM NEW.location_id) THEN RAISE EXCEPTION 'Selected serial is not in stock at this location.'; END IF;
    IF NEW.transaction_type='PURCHASE_RETURN' AND NEW.metadata ? 'purchase_receipt_id' THEN
      SELECT reference_id INTO sold_reference FROM public.inventory_transactions WHERE tenant_id=NEW.tenant_id AND id=serial_row.received_transaction_id AND reference_type='purchase_receipt';
      IF sold_reference IS DISTINCT FROM (NEW.metadata->>'purchase_receipt_id')::uuid THEN RAISE EXCEPTION 'Returned serial does not belong to the selected goods receipt.'; END IF;
    END IF;
    IF NEW.transaction_type IN ('SALE_RETURN','RETURN') AND (NEW.quantity_delta<=0 OR serial_row.status<>'SOLD') THEN RAISE EXCEPTION 'Only sold serials may be returned to stock.'; END IF;
    IF NEW.transaction_type IN ('SALE_RETURN','RETURN') AND NEW.metadata ? 'sale_id' THEN
      SELECT reference_id INTO sold_reference FROM public.inventory_transactions WHERE tenant_id=NEW.tenant_id AND id=serial_row.sold_transaction_id AND reference_type='sale';
      IF sold_reference IS DISTINCT FROM (NEW.metadata->>'sale_id')::uuid THEN RAISE EXCEPTION 'Returned serial does not belong to this sale.'; END IF;
    END IF;
    IF NEW.transaction_type='TRANSFER_IN' AND (NEW.quantity_delta<=0 OR serial_row.status<>'IN_TRANSIT') THEN RAISE EXCEPTION 'Only in-transit serials may be received.'; END IF;
   END LOOP;
   IF NEW.transaction_type IN ('SALE_RETURN','RETURN','TRANSFER_IN') AND NEW.quantity_delta<=0 THEN RAISE EXCEPTION 'Return/transfer-in must increase stock.'; END IF;
   IF NEW.transaction_type IN ('SALE','TRANSFER_OUT','PURCHASE_RETURN','ADJUSTMENT','COUNT_RECONCILIATION') AND NEW.quantity_delta>=0 THEN RAISE EXCEPTION 'Outbound tracked movement must reduce stock.'; END IF;
  ELSE RAISE EXCEPTION 'Unsupported serial inventory movement type: %',NEW.transaction_type;
  END IF;
 ELSIF mode='BATCH' THEN
  IF NEW.transaction_type='PURCHASE_RECEIPT' OR (NEW.transaction_type IN ('ADJUSTMENT','COUNT_RECONCILIATION') AND NEW.quantity_delta>0 AND NEW.metadata ? 'lot_receipt') THEN
   IF COALESCE(NULLIF(btrim(NEW.metadata->'lot_receipt'->>'lot_number'),''),'')='' THEN RAISE EXCEPTION 'Batch receipt requires a lot number.'; END IF;
  ELSIF NEW.transaction_type='TRACEABLE_RECEIPT' THEN
   IF NEW.quantity_delta<=0 OR COALESCE(NULLIF(btrim(NEW.metadata->>'lot_number'),''),'')='' THEN RAISE EXCEPTION 'A traceable batch receipt requires a positive quantity and lot number.'; END IF;
  ELSIF NEW.transaction_type='TRANSFER_IN' THEN
   transfer_lots:=COALESCE(NEW.metadata->'lot_receipt_allocations','[]'::jsonb);
   IF jsonb_typeof(transfer_lots)<>'array' OR jsonb_array_length(transfer_lots)=0 THEN RAISE EXCEPTION 'Batch transfer receipt requires destination lot allocations.'; END IF;
   SELECT COALESCE(sum((value->>'quantity')::numeric),0) INTO qty FROM jsonb_array_elements(transfer_lots);
   IF qty<>NEW.quantity_delta THEN RAISE EXCEPTION 'Destination lot allocation does not reconcile to transfer quantity.'; END IF;
  ELSE
   items:=COALESCE(NEW.metadata->'lot_allocations','[]'::jsonb);
   IF jsonb_typeof(items)<>'array' OR jsonb_array_length(items)=0 THEN RAISE EXCEPTION 'Batch movement requires specific lot allocations.'; END IF;
   SELECT COALESCE(sum((value->>'quantity')::numeric),0) INTO qty FROM jsonb_array_elements(items);
   IF qty<>abs(NEW.quantity_delta) THEN RAISE EXCEPTION 'Lot allocations must reconcile to inventory ledger quantity.'; END IF;
   FOR item IN SELECT value FROM jsonb_array_elements(items) LOOP
    IF COALESCE((item->>'quantity')::numeric,0)<=0 THEN RAISE EXCEPTION 'Lot allocation quantity must be positive.'; END IF;
    SELECT id,remaining_quantity,status,location_id,variant_id,expires_on,received_transaction_id INTO lot_row FROM public.inventory_lots WHERE tenant_id=NEW.tenant_id AND id=(item->>'lot_id')::uuid FOR UPDATE;
    IF NOT FOUND OR lot_row.variant_id<>NEW.variant_id OR lot_row.location_id<>NEW.location_id THEN RAISE EXCEPTION 'Lot does not belong to this variant and location.'; END IF;
    IF NEW.transaction_type='PURCHASE_RETURN' AND NEW.metadata ? 'purchase_receipt_id' THEN
      SELECT reference_id INTO sold_reference FROM public.inventory_transactions WHERE tenant_id=NEW.tenant_id AND id=lot_row.received_transaction_id AND reference_type='purchase_receipt';
      IF sold_reference IS DISTINCT FROM (NEW.metadata->>'purchase_receipt_id')::uuid THEN RAISE EXCEPTION 'Returned batch does not belong to the selected goods receipt.'; END IF;
    END IF;
    IF NEW.quantity_delta<0 AND (lot_row.status NOT IN ('ACTIVE','DEPLETED') OR lot_row.remaining_quantity<(item->>'quantity')::numeric OR (lot_row.expires_on IS NOT NULL AND lot_row.expires_on<current_date)) THEN RAISE EXCEPTION 'Lot is expired/unavailable or does not have sufficient stock.'; END IF;
   END LOOP;
  END IF;
 END IF;
 RETURN NEW;
END $$;

-- Append-only serial/lot detail movements are created alongside each canonical ledger transaction.
CREATE OR REPLACE FUNCTION public.apply_inventory_traceability_movement()
RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE
 mode text; item jsonb; serial_row record; lot_row record; unit_id uuid; serial_no text; imei_no text;
 lot_id uuid; lot_number text; qty numeric; delta numeric; old_status text; old_loc uuid;
 new_status text; new_loc uuid; mov_type text;
BEGIN
 SELECT tracking_mode INTO mode FROM public.product_variants WHERE tenant_id=NEW.tenant_id AND id=NEW.variant_id;
 IF mode='QUANTITY' THEN RETURN NEW; END IF;
 IF mode='SERIAL' THEN
  IF NEW.transaction_type='PURCHASE_RECEIPT' OR (NEW.transaction_type IN ('ADJUSTMENT','COUNT_RECONCILIATION') AND NEW.quantity_delta>0) THEN
   FOR item IN SELECT value FROM jsonb_array_elements(COALESCE(NEW.metadata->'serial_units',NEW.metadata->'serial_numbers','[]'::jsonb)) LOOP
    serial_no:=CASE WHEN jsonb_typeof(item)='string' THEN item#>>'{}' ELSE item->>'serial_number' END;
    imei_no:=CASE WHEN jsonb_typeof(item)='object' THEN item->>'imei' ELSE NULL END;
    INSERT INTO public.inventory_serial_units(tenant_id,variant_id,current_location_id,serial_number,imei,status,received_transaction_id,metadata)
     VALUES(NEW.tenant_id,NEW.variant_id,NEW.location_id,serial_no,imei_no,'IN_STOCK',NEW.id,COALESCE(CASE WHEN jsonb_typeof(item)='object' THEN item->'metadata' END,'{}'::jsonb)) RETURNING id INTO unit_id;
    mov_type:=CASE WHEN NEW.transaction_type IN ('ADJUSTMENT','COUNT_RECONCILIATION') THEN NEW.transaction_type ELSE 'PURCHASE_RECEIPT' END;
    INSERT INTO public.inventory_serial_movements(tenant_id,serial_unit_id,inventory_transaction_id,movement_type,to_status,to_location_id,metadata)
     VALUES(NEW.tenant_id,unit_id,NEW.id,mov_type,'IN_STOCK',NEW.location_id,NEW.metadata);
   END LOOP;
  ELSE
   FOR item IN SELECT value FROM jsonb_array_elements(COALESCE(NEW.metadata->'serial_ids','[]'::jsonb)) LOOP
    SELECT id,status,current_location_id,sold_transaction_id INTO serial_row FROM public.inventory_serial_units WHERE tenant_id=NEW.tenant_id AND id=(item#>>'{}')::uuid FOR UPDATE;
    old_status:=serial_row.status; old_loc:=serial_row.current_location_id;
    new_status:=CASE NEW.transaction_type WHEN 'SALE' THEN 'SOLD' WHEN 'TRANSFER_OUT' THEN 'IN_TRANSIT' WHEN 'TRANSFER_IN' THEN 'IN_STOCK' WHEN 'SALE_RETURN' THEN 'IN_STOCK' WHEN 'RETURN' THEN 'IN_STOCK' WHEN 'PURCHASE_RETURN' THEN 'WRITTEN_OFF' WHEN 'ADJUSTMENT' THEN 'WRITTEN_OFF' WHEN 'COUNT_RECONCILIATION' THEN 'WRITTEN_OFF' ELSE old_status END;
    new_loc:=CASE WHEN new_status IN ('SOLD','IN_TRANSIT','WRITTEN_OFF','QUARANTINED') THEN NULL ELSE NEW.location_id END;
    UPDATE public.inventory_serial_units SET status=new_status,current_location_id=new_loc,
      sold_transaction_id=CASE WHEN NEW.transaction_type='SALE' THEN NEW.id WHEN NEW.transaction_type IN ('SALE_RETURN','RETURN') THEN NULL ELSE sold_transaction_id END,updated_at=now()
      WHERE tenant_id=NEW.tenant_id AND id=serial_row.id;
    mov_type:=CASE NEW.transaction_type WHEN 'PURCHASE_RETURN' THEN 'PURCHASE_RETURN' WHEN 'RETURN' THEN 'SALE_RETURN' ELSE NEW.transaction_type END;
    INSERT INTO public.inventory_serial_movements(tenant_id,serial_unit_id,inventory_transaction_id,movement_type,from_status,to_status,from_location_id,to_location_id,metadata)
     VALUES(NEW.tenant_id,serial_row.id,NEW.id,mov_type,old_status,new_status,old_loc,new_loc,NEW.metadata);
   END LOOP;
  END IF;
 ELSIF mode='BATCH' THEN
  IF NEW.transaction_type='PURCHASE_RECEIPT' OR (NEW.transaction_type IN ('ADJUSTMENT','COUNT_RECONCILIATION') AND NEW.quantity_delta>0 AND NEW.metadata ? 'lot_receipt') THEN
   item:=NEW.metadata->'lot_receipt';
   INSERT INTO public.inventory_lots(tenant_id,variant_id,location_id,lot_number,expires_on,manufactured_on,received_quantity,remaining_quantity,unit_cost,status,received_transaction_id,metadata)
    VALUES(NEW.tenant_id,NEW.variant_id,NEW.location_id,item->>'lot_number',NULLIF(item->>'expires_on','')::date,NULLIF(item->>'manufactured_on','')::date,NEW.quantity_delta,NEW.quantity_delta,COALESCE(NULLIF(item->>'unit_cost','')::numeric,NEW.unit_cost),'ACTIVE',NEW.id,NEW.metadata) RETURNING id INTO lot_id;
   mov_type:=CASE WHEN NEW.transaction_type IN ('ADJUSTMENT','COUNT_RECONCILIATION') THEN NEW.transaction_type ELSE 'PURCHASE_RECEIPT' END;
   INSERT INTO public.inventory_lot_movements(tenant_id,lot_id,inventory_transaction_id,quantity_delta,remaining_after,movement_type,metadata)
    VALUES(NEW.tenant_id,lot_id,NEW.id,NEW.quantity_delta,NEW.quantity_delta,mov_type,NEW.metadata);
  ELSIF NEW.transaction_type='TRANSFER_IN' THEN
   FOR item IN SELECT value FROM jsonb_array_elements(NEW.metadata->'lot_receipt_allocations') LOOP
    qty:=(item->>'quantity')::numeric; lot_number:=item->>'lot_number';
    INSERT INTO public.inventory_lots(tenant_id,variant_id,location_id,lot_number,expires_on,manufactured_on,received_quantity,remaining_quantity,unit_cost,status,received_transaction_id,metadata)
     VALUES(NEW.tenant_id,NEW.variant_id,NEW.location_id,lot_number,NULLIF(item->>'expires_on','')::date,NULLIF(item->>'manufactured_on','')::date,qty,qty,COALESCE(NULLIF(item->>'unit_cost','')::numeric,NEW.unit_cost),'ACTIVE',NEW.id,NEW.metadata) RETURNING id INTO lot_id;
    INSERT INTO public.inventory_lot_movements(tenant_id,lot_id,inventory_transaction_id,quantity_delta,remaining_after,movement_type,metadata)
     VALUES(NEW.tenant_id,lot_id,NEW.id,qty,qty,'TRANSFER_IN',NEW.metadata);
   END LOOP;
  ELSE
   FOR item IN SELECT value FROM jsonb_array_elements(NEW.metadata->'lot_allocations') LOOP
    SELECT id,remaining_quantity,status INTO lot_row FROM public.inventory_lots WHERE tenant_id=NEW.tenant_id AND id=(item->>'lot_id')::uuid FOR UPDATE;
    qty:=(item->>'quantity')::numeric; delta:=CASE WHEN NEW.quantity_delta<0 THEN -qty ELSE qty END;
    UPDATE public.inventory_lots SET remaining_quantity=remaining_quantity+delta,status=CASE WHEN remaining_quantity+delta=0 THEN 'DEPLETED' ELSE 'ACTIVE' END,updated_at=now()
      WHERE tenant_id=NEW.tenant_id AND id=lot_row.id;
    INSERT INTO public.inventory_lot_movements(tenant_id,lot_id,inventory_transaction_id,quantity_delta,remaining_after,movement_type,metadata)
     SELECT NEW.tenant_id,id,NEW.id,delta,remaining_quantity,CASE NEW.transaction_type WHEN 'PURCHASE_RETURN' THEN 'SUPPLIER_RETURN' WHEN 'RETURN' THEN 'SALE_RETURN' ELSE NEW.transaction_type END,NEW.metadata
       FROM public.inventory_lots WHERE tenant_id=NEW.tenant_id AND id=lot_row.id;
   END LOOP;
  END IF;
 END IF;
 RETURN NEW;
END $$;

INSERT INTO public.schema_migrations(version)
VALUES ('051_tracked_inventory_workflow_integration')
ON CONFLICT (version) DO NOTHING;
COMMIT;
