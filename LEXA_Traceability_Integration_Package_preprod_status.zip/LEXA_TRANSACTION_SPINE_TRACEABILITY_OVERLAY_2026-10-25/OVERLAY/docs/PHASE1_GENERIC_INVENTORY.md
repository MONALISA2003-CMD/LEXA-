# LEXA Phase 1 — Generic business setup, catalogue and inventory

## What this overlay adds

- Product-option tracking mode: `QUANTITY`, `SERIAL`, or `BATCH`.
- Tenant-scoped serial/IMEI register and batch/lot register with expiry/manufacture dates.
- Append-only serial/lot movement history tied to `inventory_transactions`.
- Database fail-closed checks: a serial-controlled sale or transfer must name the actual units; a unit must be available at the right location; a sold unit cannot be sold again. Batch outbound movements must include lot allocations whose quantities equal the ledger movement, must belong to the correct location/product, and cannot consume expired lots.
- A user-facing web screen for selecting tracking mode and receiving serial/batch inventory through `post_ledger`, plus searchable traceability registers.

## Existing LEXA foundations reused

This is an additive extension of LEXA's existing `business_profiles`, `branches`, `warehouses`, `locations`, `categories`, `products`, `product_variants`, `product_attribute_definitions`, `product_attribute_values`, `barcodes`, `price_lists`, `product_prices`, `inventory_balances`, `inventory_transactions`, stock counts, adjustments, transfers, purchasing receipts and commerce sales. Do not create duplicate base entities.

## Install into the full repository

1. Copy `migrations/049_phase1_inventory_traceability.sql` to the repository's `migrations/` directory.
2. Copy `apps/api/app/routes/traceability.py` to the same path in the API package.
3. Register the router in `apps/api/app/main.py`:

   ```python
   from .routes import traceability
   app.include_router(traceability.router, prefix="/api/v1")
   ```

4. Append the exports from `apps/web/lib/api.traceability.additions.ts` to the existing `apps/web/lib/api.ts`. This reuses the shared authenticated API client and CSRF/session conventions.
5. Copy `apps/web/app/inventory/traceability/page.tsx` to the same web path. Add a navigation item pointing to `/inventory/traceability` from the existing inventory navigation (do not expose it to users who lack `catalog.read`/`inventory.read`).
6. Confirm the database's tenant context is set to `app.tenant_id` before applying the new RLS tables. If LEXA's current `apply_application_role()` uses a differently named tenant GUC, change the four policies in migration 049 to match that exact contract before apply. Do not bypass RLS or use a superuser to validate isolation.
7. Review generated diff, then apply this migration only to a fresh disposable PostgreSQL database. The migration is additive, but it's not a substitute for a clean migration replay.

## Critical checkout/receiving integration required before production

The database deliberately rejects tracked sales/transfers that omit identity allocations, but full business workflows must pass those allocations:

- **Checkout:** extend `SaleLineIn` in `routes/commerce.py` with `serial_ids: list[UUID]` and optional batch allocations. For a SERIAL line, require serial count to equal sale quantity, validate tenant/variant/location and `IN_STOCK`, then pass `{"serial_ids": [...], "sale_id": ...}` as the `metadata` to `post_ledger`. Keep sale, payment, serial state transition and quantity ledger movement in one database transaction. Never accept a serial ID without checking it belongs to the selected variant and stock location.
- **Batch sale:** before `post_ledger`, allocate from `inventory_lots` ordered by `expires_on ASC NULLS LAST, created_at, id` (FEFO—first expiry first out), lock rows `FOR UPDATE`, ignore expired/non-active/empty lots, pass `lot_allocations: [{"lot_id":"...","quantity":"..."}]` and make the sum equal the sold quantity. The database trigger decrements lots and appends their movements.
- **Purchasing receipts:** extend `ReceiptLineIn` and the posting loop so a SERIAL line supplies one serial/IMEI per received unit; a BATCH line supplies a lot number/date and creates the lot against the same receipt transaction. Do not let a generic quantity-only receipt post to a tracked variant.
- **Transfers and returns:** include exact serial IDs or lot allocations in both the source and destination movement. Transfer operations must move the same identities `IN_STOCK -> IN_TRANSIT -> IN_STOCK`; returns must verify the original sold serial or lot and then append a return movement. Do not substitute an aggregate quantity adjustment.
- **Counts/adjustments:** identity-tracked counts must record the physical serial set or lot quantities, compare that set to the register and post explicit differences. Do not change the register without a linked ledger transaction.

The guard makes omission unsafe rather than silently corrupting traceable inventory. Until these existing commerce/purchasing/transfer workflows are wired to identity allocations and covered by staging tests, keep SERIAL/BATCH checkout workflows disabled for production users.

## Release gates

- Rebuild `on_hand` from `inventory_transactions` and compare every `(tenant_id, location_id, variant_id)` balance to `inventory_balances`.
- Rebuild each serial's current state/location from `inventory_serial_movements`; no serial may have more than one current owner/location and no second SALE may consume `SOLD` stock.
- Rebuild each lot balance from `inventory_lot_movements`; compare it with `inventory_lots.remaining_quantity` and the location's quantity ledger.
- Exercise FEFO, lot expiry, duplicate IMEI, duplicate serial, duplicate idempotency key, concurrent checkout, partial transfer/receipt, return, adjustment and stock count scenarios.
- Prove tenant A and tenant B cannot read or mutate each other's rows via direct API calls, not only by hiding UI links.
- Check `GET /api/v1/inventory/integrity` stays healthy after each test scenario.

## Important distinction

The provided traceability screen and receiving APIs are a focused implementation overlay. They do **not** mean every existing purchasing, POS, return, transfer, count and adjustment path has already been wired to use serial/lot allocations. Do not mark the phase complete until those integrations and the clean PostgreSQL + authenticated end-to-end tests pass.
