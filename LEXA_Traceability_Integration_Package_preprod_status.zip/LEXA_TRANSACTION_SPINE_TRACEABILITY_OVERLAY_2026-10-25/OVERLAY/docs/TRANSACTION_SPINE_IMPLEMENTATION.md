# Transaction spine: traceability and acceptance

## Source transaction contract

A sale is the source operation. Use the existing idempotent checkout endpoint—do not create a second sale when money is recorded later. Inventory movements refer to the sale source record; payment rows and allocations link to the sale's business transaction; receivables link to the sale; journal entries link by source type/source ID. The new trace screen only reads these links and never posts a movement, payment, journal or analytics event.

`/api/v1/transaction-trace/sales/{sale_id_or_transaction_id}` returns:

- source transaction and LEXA receipt/reference;
- transaction lines and recorded tax support (rate, amount and tax metadata);
- the stock/cost movements, their balance-after, source references and positive prior receipts for the sold items;
- recorded payments and allocations, customer receivables and return/credit-note rows;
- each matching journal's summed debits, credits, difference and `balanced` result;
- matching audit-log and outbox records for the sale and source transaction;
- totals derived from those linked records. It does not re-run business effects to produce the trace.

The route is tenant-scoped and re-checks branch/location access. Missing access appears as not found/forbidden, not a cross-tenant data leak.

## Inventory rules

- `QUANTITY`: keep existing quantity ledger behavior.
- `SERIAL`: checkout requires one available serial/IMEI per whole unit; the canonical ledger insert and serial status/movement trigger happen in the same database transaction. Locked serial rows prevent concurrent double sale.
- `BATCH`: checkout locks active non-expired lot rows and allocates FEFO; the allocation quantity must equal the negative movement. The DB trigger updates lot balances and appends lot movement history.
- Receiving through the traceability API posts one positive canonical ledger movement and stores all serial/lot details against that movement. The deferred SQL constraint rejects a commit when the detail movements do not reconcile to the quantity ledger.
- Corrections are new movements; detail history is append-only.

## Tests required before Phase 2 completion

1. Create synthetic business/branch/warehouse/location, category/subcategory, product, variant/SKU/barcode, attribute definition/value and price list/price.
2. Receive ordinary quantity and verify `SUM(quantity_delta)` reconstructs `inventory_balances.on_hand`, and `balance_after` matches each movement.
3. Receive serial/IMEI units; reject duplicate serial/IMEI; sell one serial; retry with same idempotency key and payload; retry a competing sale for same serial and prove only one commits.
4. Receive two lots with distinct expiry dates; sell across both and prove earlier valid expiry is consumed first. Reject expired, depleted and insufficient lot allocations.
5. Complete one sale with a recorded payment and one credit sale with a receivable. Verify exactly one sale, exactly once stock movements, a receipt/reference, tax support lines, payments/receivable, balanced sale/payment/COGS journals, audit/outbox rows and the same totals in analytics read models.
6. Record money against an existing sale/receivable; assert the operation does not insert a second `sales` or inventory row.
7. Prove a tenant and a user without branch membership cannot read or mutate another branch's stock.
8. Integrate and test traceable receiving via purchase orders, returns, transfers, stock counts and stock adjustments before allowing SERIAL/BATCH stock to use those workflows.

## Scope guard

No EFRIS/URA API, external payment API or payment gateway belongs in this phase. Tax support means locally stored tax amounts/rates and fiscal-document references for later human review, not tax-authority submission.
