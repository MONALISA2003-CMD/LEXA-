"use client";
import { useState, type FormEvent } from "react";
import { AppShell } from "../../../components/app-shell";
import { getCommerceSaleTrace, type CommerceSaleTrace, userFacingError } from "../../../lib/api";

const value = (row: Record<string, unknown>, key: string) => {
  const v = row[key];
  if (v === null || v === undefined || v === "") return "—";
  if (typeof v === "object") return JSON.stringify(v);
  return String(v);
};
function Register({ title, rows, fields }: { title: string; rows: Array<Record<string, unknown>>; fields: Array<[string,string]> }) {
  return <section className="panel"><div className="panel-head"><div><h2>{title}</h2><p>{rows.length} linked record(s)</p></div></div>{rows.length ? <div className="data-table-wrap"><table className="data-table"><thead><tr>{fields.map(([key,label])=><th key={key}>{label}</th>)}</tr></thead><tbody>{rows.map((row,i)=><tr key={String(row.id || row.inventory_transaction_id || row.payment_id || i)}>{fields.map(([key,label])=><td key={key}>{value(row,key)}</td>)}</tr>)}</tbody></table></div> : <div className="empty-inline">No linked records found for this step yet.</div>}</section>;
}
export default function TransactionTraceabilityPage() {
  const [id,setId] = useState(""); const [trace,setTrace] = useState<CommerceSaleTrace|null>(null); const [busy,setBusy]=useState(false); const [error,setError]=useState("");
  async function load(e: FormEvent) { e.preventDefault(); if(!id.trim()) return; setBusy(true); setError(""); try { setTrace(await getCommerceSaleTrace(id.trim())); } catch(err) { setTrace(null); setError(userFacingError(err,"LEXA could not find the sale or load its complete trace. Check the reference and your access.")); } finally {setBusy(false);} }
  const obj=(x: unknown): Record<string,unknown> => (x && typeof x === "object" ? x as Record<string,unknown> : {});
  return <AppShell title="Follow a transaction" eyebrow="Business records">
    <section className="panel form-panel"><div><div className="detail-kicker">TRANSACTION JOURNEY</div><h2>Follow one sale from start to finish</h2><p>Enter a LEXA sale ID or source-transaction ID. This page reads linked records only; it never records another sale or changes stock.</p></div><form className="form-grid" onSubmit={load}><label>Sale or transaction reference<input value={id} onChange={e=>setId(e.target.value)} placeholder="Paste sale ID or transaction ID" required /></label><div className="form-actions"><button className="button button-dark" type="submit" disabled={busy}>{busy?"Following records…":"Follow transaction"}</button></div></form>{error&&<div className="notice notice-error" role="alert">{error}</div>}</section>
    {trace&&<>
      <section className="panel"><div className="panel-head"><div><h2>Transaction overview</h2><p>LEXA receipt reference: <strong>{trace.receipt.reference || "Reference not available"}</strong></p></div></div><div className="metric-strip"><div><span>Sale total</span><strong>{trace.summary.sale_total}</strong></div><div><span>Tax recorded</span><strong>{trace.summary.tax_total}</strong></div><div><span>Payments allocated</span><strong>{trace.summary.recorded_payments_allocated}</strong></div><div><span>Still owed</span><strong>{trace.summary.open_receivable_balance}</strong></div></div><div className="workflow-list"><div className="workflow-row"><strong>Stock movements</strong><span>{trace.summary.stock_movements}</span></div><div className="workflow-row"><strong>Balanced journals</strong><span>{trace.summary.balanced_journals}</span></div><div className="workflow-row"><strong>Unbalanced journals</strong><span className={trace.summary.unbalanced_journals?"number-danger":"number-good"}>{trace.summary.unbalanced_journals}</span></div></div><p className="muted-copy">{trace.reporting_note}</p></section>
      <Register title="Product and tax-supporting lines" rows={trace.product_and_tax_lines.map(obj)} fields={[["line_no","Line"],["description","Item"],["quantity","Quantity"],["unit_price","Unit price"],["tax_rate","Tax rate"],["tax_amount","Tax amount"],["line_total","Line total"],["metadata","Tax details"]]} />
      <Register title="Stock and cost movements" rows={trace.inventory_cost_movements.map(obj)} fields={[["occurred_at","Time"],["product_name","Product"],["sku","Product code"],["transaction_type","Movement"],["quantity_delta","Quantity change"],["unit_cost","Unit cost"],["total_cost","Cost value"],["balance_after","Stock after"],["source_transaction_id","Source transaction"]]} />
      <Register title="Earlier positive stock receipts for these items" rows={trace.prior_receipts_for_sale_items.map(obj)} fields={[["occurred_at","Received at"],["product_name","Product"],["sku","Product code"],["receipt_number","Delivery reference"],["quantity_delta","Quantity received"],["unit_cost","Unit cost"],["total_cost","Cost value"]]} />
      <Register title="Recorded payments and allocations" rows={trace.recorded_payments_and_allocations.map(obj)} fields={[["payment_id","Payment ID"],["payment_status","Payment status"],["recorded_amount","Amount recorded"],["allocated_amount","Amount allocated"],["method","Method recorded"],["reference","Receipt / reference"]]} />
      <Register title="Customer balances" rows={trace.receivables.map(obj)} fields={[["id","Balance ID"],["original_amount","Original amount"],["paid_amount","Paid"],["adjustment_amount","Adjusted"],["balance","Still owed"],["status","Status"]]} />
      <Register title="Accounting journals" rows={trace.journals.map(obj)} fields={[["entry_date","Date"],["entry_role","Purpose"],["reference","Reference"],["status","Status"],["debit_total","Debits"],["credit_total","Credits"],["difference","Difference"],["balanced","Balanced"]]} />
      <Register title="Returns / credit notes" rows={trace.returns_and_credit_notes.map(obj)} fields={[["created_at","Date"],["id","Return ID"],["reason","Reason"],["total","Value"],["status","Status"]]} />
      <Register title="Audit history" rows={trace.audit_records.map(obj)} fields={[["created_at","Time"],["action","Action"],["target_type","Record type"],["outcome","Outcome"],["correlation_id","Correlation ID"]]} />
      <Register title="Linked events" rows={trace.events.map(obj)} fields={[["occurred_at","Time"],["event_type","Event"],["aggregate_type","Record type"],["aggregate_id","Record ID"]]} />
    </>}
  </AppShell>;
}
