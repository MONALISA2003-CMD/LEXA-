"use client";

import { useEffect, useMemo, useState, type FormEvent } from "react";
import { AppShell } from "../../../components/app-shell";
import { getTraceabilityVariants, getLocations, getTraceabilitySerials, getTraceabilityLots, setVariantTrackingMode, receiveSerialStock, receiveBatchStock, type TraceabilityVariant, type TraceabilitySerial, type TraceabilityLot, type Location } from "../../../lib/api";

const inputStyle = { width: "100%", minHeight: 42, padding: "10px 12px", border: "1px solid var(--border, #d7dbe2)", borderRadius: 9, background: "var(--surface, #fff)", color: "inherit" } as const;
const panelStyle = { border: "1px solid var(--border, #e1e5eb)", borderRadius: 14, padding: 18, minWidth: 0 } as const;

export default function InventoryTraceabilityPage() {
  const [variants, setVariants] = useState<TraceabilityVariant[]>([]);
  const [locations, setLocations] = useState<Location[]>([]);
  const [serials, setSerials] = useState<TraceabilitySerial[]>([]);
  const [lots, setLots] = useState<TraceabilityLot[]>([]);
  const [variantId, setVariantId] = useState("");
  const [locationId, setLocationId] = useState("");
  const [mode, setMode] = useState<"QUANTITY" | "SERIAL" | "BATCH">("QUANTITY");
  const [serialNumbers, setSerialNumbers] = useState("");
  const [imeis, setImeis] = useState("");
  const [unitCost, setUnitCost] = useState("");
  const [reference, setReference] = useState("");
  const [lotNumber, setLotNumber] = useState("");
  const [quantity, setQuantity] = useState("1");
  const [expiry, setExpiry] = useState("");
  const [manufactured, setManufactured] = useState("");
  const [search, setSearch] = useState("");
  const [busy, setBusy] = useState(false);
  const [loading, setLoading] = useState(true);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const selected = useMemo(() => variants.find(v => v.variant_id === variantId), [variants, variantId]);
  const visibleVariants = useMemo(() => {
    const q = search.trim().toLocaleLowerCase();
    return q ? variants.filter(v => `${v.product_name} ${v.variant_name} ${v.sku}`.toLocaleLowerCase().includes(q)) : variants;
  }, [variants, search]);

  async function refresh() {
    setLoading(true); setError("");
    try {
      const [v, l, s, b] = await Promise.all([
        getTraceabilityVariants(), getLocations(), getTraceabilitySerials({ limit: 300 }), getTraceabilityLots({ limit: 300 }),
      ]);
      setVariants(v); setLocations(l);
      setSerials(s); setLots(b);
      setVariantId(current => current || v[0]?.variant_id || "");
      setLocationId(current => current || l[0]?.id || "");
    } catch (e) {
      setError(e instanceof Error ? e.message : "Inventory tracking details could not be loaded.");
    } finally { setLoading(false); }
  }
  useEffect(() => { void refresh(); }, []);
  useEffect(() => { if (selected) setMode(selected.tracking_mode); }, [selected?.variant_id, selected?.tracking_mode]);

  async function saveMode(event: FormEvent) {
    event.preventDefault(); if (!selected) return;
    setBusy(true); setError(""); setMessage("");
    try {
      await setVariantTrackingMode(selected.variant_id, mode);
      setMessage("Tracking method saved. Existing stock must be reconciled before changing to serial or batch tracking."); await refresh();
    } catch (e) { setError(e instanceof Error ? e.message : "Tracking method could not be saved."); }
    finally { setBusy(false); }
  }

  async function receiveSerials(event: FormEvent) {
    event.preventDefault(); if (!selected || !locationId || !unitCost.trim()) return;
    const numbers = serialNumbers.split(/\r?\n|,|;/).map(s => s.trim()).filter(Boolean);
    const imeiList = imeis.trim() ? imeis.split(/\r?\n|,|;/).map(s => s.trim()) : undefined;
    if (!numbers.length) { setError("Enter at least one serial number."); return; }
    if (imeiList && imeiList.length !== numbers.length) { setError("Enter one IMEI per serial number, in the same order."); return; }
    setBusy(true); setError(""); setMessage("");
    try {
      await receiveSerialStock({ variant_id: selected.variant_id, location_id: locationId, unit_cost: unitCost, serial_numbers: numbers, ...(imeiList ? { imeis: imeiList } : {}), reference: reference || null });
      setSerialNumbers(""); setImeis(""); setReference(""); setMessage(`${numbers.length} unit(s) received. Stock quantity and serial register were saved together.`); await refresh();
    } catch (e) { setError(e instanceof Error ? e.message : "Serial units could not be received."); }
    finally { setBusy(false); }
  }

  async function receiveLot(event: FormEvent) {
    event.preventDefault(); if (!selected || !locationId || !lotNumber.trim() || !quantity || !unitCost) return;
    setBusy(true); setError(""); setMessage("");
    try {
      await receiveBatchStock({ variant_id: selected.variant_id, location_id: locationId, lot_number: lotNumber.trim(), quantity, unit_cost: unitCost, expires_on: expiry || null, manufactured_on: manufactured || null, reference: reference || null });
      setLotNumber(""); setExpiry(""); setManufactured(""); setReference(""); setMessage("Batch received and linked to a stock movement."); await refresh();
    } catch (e) { setError(e instanceof Error ? e.message : "Batch could not be received."); }
    finally { setBusy(false); }
  }

  return <AppShell title="Serial numbers & batches" eyebrow="Inventory setup">
    <div style={{ display: "grid", gap: 18 }}>
      <header><h1 style={{ marginBottom: 6 }}>Serial numbers & batches</h1><p style={{ margin: 0, color: "var(--muted, #667085)" }}>Choose how each product option is tracked. Phones and electronics can use serial numbers or IMEIs; food, medicine and other dated stock can use batch numbers and expiry dates.</p></header>
      {message && <div role="status" style={{ ...panelStyle, borderColor: "#76a88c" }}>{message}</div>}
      {error && <div role="alert" style={{ ...panelStyle, borderColor: "#c75b5b" }}>{error}</div>}
      <section style={panelStyle}>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(220px,1fr))", gap: 12 }}>
          <label style={{ display: "grid", gap: 6 }}>Find a product<input style={inputStyle} value={search} onChange={e => setSearch(e.target.value)} placeholder="Product name or code" /></label>
          <label style={{ display: "grid", gap: 6 }}>Product option<select style={inputStyle} value={variantId} onChange={e => setVariantId(e.target.value)}><option value="">Choose product option</option>{visibleVariants.map(v => <option key={v.variant_id} value={v.variant_id}>{v.product_name} · {v.variant_name} · {v.sku}</option>)}</select></label>
          <label style={{ display: "grid", gap: 6 }}>Where is the stock kept?<select style={inputStyle} value={locationId} onChange={e => setLocationId(e.target.value)}><option value="">Choose location</option>{locations.map(l => <option key={l.id} value={l.id}>{l.name} · {l.code}</option>)}</select></label>
        </div>
        {selected && <div style={{ marginTop: 14, display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(160px,1fr))", gap: 10 }}>
          <div><small>Current stock</small><h2 style={{ margin: "4px 0" }}>{Number(selected.on_hand).toLocaleString("en-UG")}</h2></div>
          <div><small>Product code</small><h2 style={{ margin: "4px 0", fontSize: 18 }}>{selected.sku}</h2></div>
          <div><small>How stock is tracked</small><h2 style={{ margin: "4px 0", fontSize: 18 }}>{({ QUANTITY: "Ordinary quantity", SERIAL: "Each item has a serial", BATCH: "Batch / expiry" })[selected.tracking_mode]}</h2></div>
        </div>}
        <form onSubmit={saveMode} style={{ marginTop: 14, display: "flex", alignItems: "end", gap: 12, flexWrap: "wrap" }}>
          <label style={{ display: "grid", gap: 6, minWidth: 240 }}>How should LEXA track this option?<select style={inputStyle} value={mode} onChange={e => setMode(e.target.value as typeof mode)}><option value="QUANTITY">Ordinary quantity (bottles, kg, packs)</option><option value="SERIAL">Each item has a serial number / IMEI</option><option value="BATCH">Batch or lot with optional expiry date</option></select></label>
          <button type="submit" disabled={busy || !selected} style={{ minHeight: 42, padding: "10px 18px", borderRadius: 9, border: 0, background: "var(--primary, #182c4c)", color: "white", fontWeight: 600 }}>{busy ? "Saving…" : "Save tracking method"}</button>
        </form>
      </section>
      {selected?.tracking_mode === "SERIAL" && <section style={panelStyle}><h2 style={{ marginTop: 0 }}>Receive individually numbered items</h2><p>Enter one serial number per line. IMEIs are optional, but when supplied there must be one per item. Duplicate numbers are rejected.</p><form onSubmit={receiveSerials} style={{ display: "grid", gap: 12 }}>
        <label style={{ display: "grid", gap: 6 }}>Serial numbers (one per line)<textarea style={{ ...inputStyle, minHeight: 112 }} value={serialNumbers} onChange={e => setSerialNumbers(e.target.value)} placeholder={"SN-0001\nSN-0002"} required /></label>
        <label style={{ display: "grid", gap: 6 }}>IMEI numbers (optional, same order)<textarea style={{ ...inputStyle, minHeight: 86 }} value={imeis} onChange={e => setImeis(e.target.value)} placeholder={"356000000000001\n356000000000002"} /></label>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(200px,1fr))", gap: 12 }}><label style={{ display: "grid", gap: 6 }}>Purchase cost per item<input style={inputStyle} type="number" min="0.000001" step="0.000001" value={unitCost} onChange={e => setUnitCost(e.target.value)} required /></label><label style={{ display: "grid", gap: 6 }}>Delivery / receipt reference (optional)<input style={inputStyle} value={reference} onChange={e => setReference(e.target.value)} maxLength={120} /></label></div>
        <button disabled={busy} style={{ minHeight: 42, border: 0, borderRadius: 9, background: "var(--primary, #182c4c)", color: "white", fontWeight: 600 }}>{busy ? "Receiving…" : "Receive serial-numbered stock"}</button>
      </form></section>}
      {selected?.tracking_mode === "BATCH" && <section style={panelStyle}><h2 style={{ marginTop: 0 }}>Receive a batch or lot</h2><p>Each delivery batch keeps its own quantity, purchase cost and expiry date. The expiry date can be left blank for products without one.</p><form onSubmit={receiveLot} style={{ display: "grid", gap: 12 }}>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(180px,1fr))", gap: 12 }}><label style={{ display: "grid", gap: 6 }}>Batch / lot number<input style={inputStyle} value={lotNumber} onChange={e => setLotNumber(e.target.value)} placeholder="LOT-2026-001" required /></label><label style={{ display: "grid", gap: 6 }}>Quantity received<input style={inputStyle} type="number" min="0.000001" step="0.000001" value={quantity} onChange={e => setQuantity(e.target.value)} required /></label><label style={{ display: "grid", gap: 6 }}>Cost per unit<input style={inputStyle} type="number" min="0.000001" step="0.000001" value={unitCost} onChange={e => setUnitCost(e.target.value)} required /></label></div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(180px,1fr))", gap: 12 }}><label style={{ display: "grid", gap: 6 }}>Manufactured on (optional)<input style={inputStyle} type="date" value={manufactured} onChange={e => setManufactured(e.target.value)} /></label><label style={{ display: "grid", gap: 6 }}>Expires on (optional)<input style={inputStyle} type="date" value={expiry} onChange={e => setExpiry(e.target.value)} /></label><label style={{ display: "grid", gap: 6 }}>Delivery / receipt reference (optional)<input style={inputStyle} value={reference} onChange={e => setReference(e.target.value)} maxLength={120} /></label></div>
        <button disabled={busy} style={{ minHeight: 42, border: 0, borderRadius: 9, background: "var(--primary, #182c4c)", color: "white", fontWeight: 600 }}>{busy ? "Receiving…" : "Receive batch"}</button>
      </form></section>}
      <section style={panelStyle}><div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: 12, flexWrap: "wrap" }}><div><h2 style={{ margin: 0 }}>Serial number register</h2><p style={{ margin: "4px 0", color: "var(--muted, #667085)" }}>Available means the item is currently in stock. Sold units stay in the history rather than being deleted.</p></div><button onClick={() => void refresh()} disabled={loading || busy} style={{ minHeight: 38, padding: "8px 12px", borderRadius: 8 }}>Refresh</button></div>
        {loading ? <p>Loading serial numbers…</p> : !serials.length ? <p>No serial-numbered items have been received yet.</p> : <div style={{ overflowX: "auto" }}><table style={{ width: "100%", borderCollapse: "collapse" }}><thead><tr>{["Item","Serial number","IMEI","Location","Status"].map(t => <th key={t} style={{ textAlign: "left", padding: 10, borderBottom: "1px solid var(--border, #e1e5eb)" }}>{t}</th>)}</tr></thead><tbody>{serials.map(s => <tr key={s.id}>{[`${s.product_name} · ${s.variant_name} (${s.sku})`,s.serial_number,s.imei || "—",s.location_name || "—",({ IN_STOCK: "Available", SOLD: "Sold", IN_TRANSIT: "In transit", QUARANTINED: "Quarantined", WRITTEN_OFF: "Written off" } as Record<string,string>)[s.status] || s.status].map((v,i) => <td key={i} style={{ padding: 10, borderBottom: "1px solid var(--border, #e1e5eb)" }}>{v}</td>)}</tr>)}</tbody></table></div>}
      </section>
      <section style={panelStyle}><h2 style={{ marginTop: 0 }}>Batch and expiry register</h2>{loading ? <p>Loading batches…</p> : !lots.length ? <p>No batch-tracked stock has been received yet.</p> : <div style={{ overflowX: "auto" }}><table style={{ width: "100%", borderCollapse: "collapse" }}><thead><tr>{["Item","Batch / lot","Location","Expires","Received","Remaining","Status"].map(t=><th key={t} style={{ textAlign: "left", padding: 10, borderBottom: "1px solid var(--border, #e1e5eb)" }}>{t}</th>)}</tr></thead><tbody>{lots.map(l=><tr key={l.id}>{[`${l.product_name} · ${l.variant_name} (${l.sku})`,l.lot_number,l.location_name,l.expires_on || "No expiry date",Number(l.received_quantity).toLocaleString("en-UG"),Number(l.remaining_quantity).toLocaleString("en-UG"),l.status === "DEPLETED" ? "Used up" : l.status === "EXPIRED" ? "Expired" : "Available"].map((v,i)=><td key={i} style={{ padding: 10, borderBottom: "1px solid var(--border, #e1e5eb)" }}>{v}</td>)}</tr>)}</tbody></table></div>}</section>
      <aside style={{ color: "var(--muted, #667085)", fontSize: 13 }}>This screen configures tracking and records incoming serial/batch stock through the inventory ledger. Before production release, connect the existing checkout, supplier receipt, stock transfer, count and return commands to these unit/lot movements; the database sale guard is designed to reject unlabelled sales for traceable items.</aside>
    </div>
  </AppShell>;
}
