export type TransactionTraceJournal = {
  id: string; source_type: string; source_id: string; entry_role: string;
  reference?: string | null; description: string; currency_code: string; status: string;
  debit_total: string; credit_total: string; difference: string; balanced: boolean;
};
export type CommerceSaleTrace = {
  source: string;
  source_transaction: Record<string, unknown>;
  receipt: { reference?: string | null; sale_id: string; transaction_id: string };
  product_and_tax_lines: Array<Record<string, unknown>>;
  inventory_cost_movements: Array<Record<string, unknown>>;
  prior_receipts_for_sale_items: Array<Record<string, unknown>>;
  recorded_payments_and_allocations: Array<Record<string, unknown>>;
  receivables: Array<Record<string, unknown>>;
  journals: TransactionTraceJournal[];
  returns_and_credit_notes: Array<Record<string, unknown>>;
  audit_records: Array<Record<string, unknown>>;
  events: Array<Record<string, unknown>>;
  summary: { sale_total: string; tax_total: string; recorded_payments_allocated: string; open_receivable_balance: string; stock_movements: number; balanced_journals: number; unbalanced_journals: number };
  reporting_note: string;
};
export function getCommerceSaleTrace(saleOrTransactionId: string) {
  return getJson<CommerceSaleTrace>(`/api/v1/transaction-trace/sales/${encodeURIComponent(saleOrTransactionId)}`);
}
