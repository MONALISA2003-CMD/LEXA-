"""Phase 1 inventory traceability APIs.

All writes are tenant-scoped, branch/location scoped, idempotent and recorded
against the existing immutable inventory quantity ledger.
"""
from __future__ import annotations

from datetime import date
from decimal import Decimal
from typing import Any
from uuid import UUID, uuid4

from fastapi import APIRouter, Depends, Header, HTTPException, Query
from pydantic import BaseModel, ConfigDict, Field, field_validator
from sqlalchemy import text
from sqlalchemy.orm import Session

from ..branch_access import ensure_location_access
from ..dependencies import require_permission
from ..inventory import post_ledger, tenant_location, tenant_variant, idempotent_start, _commit
from ..catalog import write_audit, emit_event

router = APIRouter(prefix="/inventory/traceability", tags=["inventory-traceability"])

class Strict(BaseModel):
    model_config = ConfigDict(extra="forbid")

class TrackingModeIn(Strict):
    tracking_mode: str = Field(pattern=r"^(QUANTITY|SERIAL|BATCH)$")

class SerialReceiptIn(Strict):
    location_id: UUID
    variant_id: UUID
    unit_cost: Decimal = Field(gt=0, max_digits=20, decimal_places=6)
    serial_numbers: list[str] = Field(min_length=1, max_length=500)
    imeis: list[str | None] | None = None
    reference: str | None = Field(default=None, max_length=120)

    @field_validator("serial_numbers")
    @classmethod
    def serials_are_unique_nonblank(cls, values: list[str]) -> list[str]:
        cleaned = [value.strip() for value in values]
        if any(not value for value in cleaned):
            raise ValueError("Every serial number must be filled in.")
        if len({value.casefold() for value in cleaned}) != len(cleaned):
            raise ValueError("A serial number was entered more than once.")
        return cleaned

    @field_validator("imeis")
    @classmethod
    def imeis_match_number_of_units(cls, values: list[str | None] | None) -> list[str | None] | None:
        if values is not None and any(value is not None and not value.strip() for value in values):
            raise ValueError("IMEI fields must be left empty or filled in.")
        return [value.strip() if value else None for value in values] if values is not None else None

class LotReceiptIn(Strict):
    location_id: UUID
    variant_id: UUID
    lot_number: str = Field(min_length=1, max_length=120)
    quantity: Decimal = Field(gt=0, max_digits=20, decimal_places=6)
    unit_cost: Decimal = Field(gt=0, max_digits=20, decimal_places=6)
    expires_on: date | None = None
    manufactured_on: date | None = None
    reference: str | None = Field(default=None, max_length=120)

    @field_validator("lot_number")
    @classmethod
    def lot_number_nonblank(cls, value: str) -> str:
        value = value.strip()
        if not value:
            raise ValueError("Enter a lot or batch number.")
        return value

@router.get("/variants")
def list_tracking_variants(q: str | None = Query(default=None, max_length=120), ctx=Depends(require_permission("catalog.read"))):
    db, _, tenant_id, _ = ctx
    rows = db.execute(text("""
      SELECT v.id AS variant_id, v.product_id, p.name AS product_name, v.name AS variant_name,
             v.sku, v.tracking_mode, v.track_inventory,
             COALESCE((SELECT sum(b.on_hand) FROM public.inventory_balances b WHERE b.tenant_id=v.tenant_id AND b.variant_id=v.id),0) AS on_hand
      FROM public.product_variants v
      JOIN public.products p ON p.tenant_id=v.tenant_id AND p.id=v.product_id
      WHERE v.tenant_id=:t AND v.deleted_at IS NULL
        AND (:q IS NULL OR v.sku ILIKE '%' || :q || '%' OR v.name ILIKE '%' || :q || '%' OR p.name ILIKE '%' || :q || '%')
      ORDER BY p.name, v.name LIMIT 500
    """), {"t": str(tenant_id), "q": q.strip() if q and q.strip() else None}).mappings().all()
    return [dict(row) for row in rows]

@router.patch("/variants/{variant_id}/mode")
def set_tracking_mode(variant_id: UUID, body: TrackingModeIn, ctx=Depends(require_permission("catalog.manage"))):
    db, actor, tenant_id, _ = ctx
    variant = tenant_variant(db, tenant_id, variant_id)
    if body.tracking_mode != "QUANTITY" and not variant.track_inventory:
        raise HTTPException(422, "Turn on stock tracking before using serial numbers or batches.")
    if body.tracking_mode != "QUANTITY":
        open_qty = db.execute(text("SELECT COALESCE(sum(on_hand),0) FROM public.inventory_balances WHERE tenant_id=:t AND variant_id=:v"), {"t": str(tenant_id), "v": str(variant_id)}).scalar_one()
        if Decimal(str(open_qty or 0)) != 0:
            raise HTTPException(409, "Record or reconcile existing stock before changing this item's tracking method.")
    db.execute(text("UPDATE public.product_variants SET tracking_mode=:mode, updated_at=now() WHERE tenant_id=:t AND id=:v"), {"mode": body.tracking_mode, "t": str(tenant_id), "v": str(variant_id)})
    write_audit(db, tenant_id=tenant_id, actor_user_id=actor, action="catalog.variant.tracking_mode_changed", target_type="product_variant", target_id=variant_id)
    emit_event(db, tenant_id=tenant_id, event_type="ProductVariantTrackingModeChanged", aggregate_type="product_variant", aggregate_id=variant_id, actor_user_id=actor, payload={"tracking_mode": body.tracking_mode})
    db.commit()
    return {"variant_id": str(variant_id), "tracking_mode": body.tracking_mode}

@router.get("/serials")
def list_serials(location_id: UUID | None = None, variant_id: UUID | None = None, status: str | None = None, q: str | None = Query(None, max_length=120), limit: int = Query(200, ge=1, le=500), ctx=Depends(require_permission("inventory.read"))):
    db, actor, tenant_id, _ = ctx
    if location_id:
        tenant_location(db, tenant_id, location_id)
        ensure_location_access(db, tenant_id=tenant_id, user_id=actor, location_id=location_id)
    rows = db.execute(text("""
      SELECT s.id,s.variant_id,s.current_location_id,s.serial_number,s.imei,s.status,s.created_at,
             v.sku,v.name AS variant_name,p.name AS product_name,l.name AS location_name
      FROM public.inventory_serial_units s
      JOIN public.product_variants v ON v.tenant_id=s.tenant_id AND v.id=s.variant_id
      JOIN public.products p ON p.tenant_id=v.tenant_id AND p.id=v.product_id
      LEFT JOIN public.locations l ON l.tenant_id=s.tenant_id AND l.id=s.current_location_id
      WHERE s.tenant_id=:t AND (:loc IS NULL OR s.current_location_id=:loc)
        AND (:variant IS NULL OR s.variant_id=:variant) AND (:status IS NULL OR s.status=:status)
        AND (:q IS NULL OR s.serial_number ILIKE '%'||:q||'%' OR COALESCE(s.imei,'') ILIKE '%'||:q||'%' OR v.sku ILIKE '%'||:q||'%' OR p.name ILIKE '%'||:q||'%')
      ORDER BY s.created_at DESC,s.id LIMIT :lim
    """), {"t": str(tenant_id), "loc": str(location_id) if location_id else None, "variant": str(variant_id) if variant_id else None, "status": status, "q": q.strip() if q else None, "lim": limit}).mappings().all()
    # Only show rows in branches the caller can access; location access is required per row.
    visible = []
    for row in rows:
        if row["current_location_id"] is None:
            continue
        try:
            ensure_location_access(db, tenant_id=tenant_id, user_id=actor, location_id=row["current_location_id"])
        except HTTPException:
            continue
        visible.append(dict(row))
    return visible

@router.post("/serials/receive", status_code=201)
def receive_serials(body: SerialReceiptIn, idempotency_key: str = Header(..., alias="Idempotency-Key", min_length=1, max_length=200), ctx=Depends(require_permission("purchasing.receive"))):
    db, actor, tenant_id, _ = ctx
    location = tenant_location(db, tenant_id, body.location_id)
    ensure_location_access(db, tenant_id=tenant_id, user_id=actor, location_id=body.location_id)
    variant = tenant_variant(db, tenant_id, body.variant_id)
    mode = db.execute(text("SELECT tracking_mode FROM public.product_variants WHERE tenant_id=:t AND id=:v"), {"t": str(tenant_id), "v": str(body.variant_id)}).scalar_one()
    if mode != "SERIAL":
        raise HTTPException(409, "Set this product option to Serial / IMEI tracking before receiving individual units.")
    if body.imeis is not None and len(body.imeis) != len(body.serial_numbers):
        raise HTTPException(422, "Enter one IMEI field per serial number, or leave IMEIs out entirely.")
    payload = body.model_dump(mode="json")
    idem = idempotent_start(db, tenant_id, "inventory.traceability.serial_receipt", idempotency_key, payload)
    if isinstance(idem, tuple): return idem[1]
    receipt_id = uuid4()
    existing = db.execute(text("SELECT serial_number FROM public.inventory_serial_units WHERE tenant_id=:t AND variant_id=:v AND serial_number = ANY(:numbers)"), {"t": str(tenant_id), "v": str(body.variant_id), "numbers": body.serial_numbers}).scalars().all()
    if existing:
        raise HTTPException(409, "One or more serial numbers have already been registered for this product option.")
    if body.imeis:
        imeis = [value for value in body.imeis if value]
        if len(imeis) != len(set(imeis)):
            raise HTTPException(422, "An IMEI was entered more than once.")
        duplicate = db.execute(text("SELECT imei FROM public.inventory_serial_units WHERE tenant_id=:t AND imei = ANY(:imeis)"), {"t": str(tenant_id), "imeis": imeis or [""]}).scalars().all()
        if duplicate:
            raise HTTPException(409, "An IMEI is already registered in this business.")
    tx = post_ledger(db, tenant_id=tenant_id, actor_user_id=actor, location_id=body.location_id, variant_id=body.variant_id,
        quantity_delta=Decimal(len(body.serial_numbers)), unit_cost=body.unit_cost, transaction_type="TRACEABLE_RECEIPT",
        reference_type="traceable_receipt", reference_id=receipt_id, idempotency_key=f"{idempotency_key}:ledger",
        metadata={"reference": body.reference, "serial_ids": [], "tracking_mode": "SERIAL"})
    for index, serial in enumerate(body.serial_numbers):
        imei = body.imeis[index] if body.imeis else None
        sid = uuid4()
        db.execute(text("INSERT INTO public.inventory_serial_units(id,tenant_id,variant_id,current_location_id,serial_number,imei,status,received_transaction_id) VALUES(:id,:t,:v,:loc,:serial,:imei,'IN_STOCK',:tx)"), {"id": str(sid), "t": str(tenant_id), "v": str(body.variant_id), "loc": str(body.location_id), "serial": serial, "imei": imei, "tx": str(tx.id)})
        db.execute(text("INSERT INTO public.inventory_serial_movements(tenant_id,serial_unit_id,inventory_transaction_id,movement_type,to_status,to_location_id,metadata) VALUES(:t,:s,:tx,'RECEIPT','IN_STOCK',:loc,:meta)"), {"t": str(tenant_id), "s": str(sid), "tx": str(tx.id), "loc": str(body.location_id), "meta": {"reference": body.reference}})
    write_audit(db, tenant_id=tenant_id, actor_user_id=actor, action="inventory.serial_receipt.posted", target_type="inventory_transaction", target_id=tx.id)
    emit_event(db, tenant_id=tenant_id, event_type="inventory.serial_receipt.posted.v1", aggregate_type="inventory_transaction", aggregate_id=tx.id, actor_user_id=actor, payload={"variant_id": str(variant.id), "units": len(body.serial_numbers)})
    response = {"id": str(receipt_id), "inventory_transaction_id": str(tx.id), "status": "POSTED", "units_received": len(body.serial_numbers)}
    return _commit(db, idem, response)

@router.post("/lots/receive", status_code=201)
def receive_lot(body: LotReceiptIn, idempotency_key: str = Header(..., alias="Idempotency-Key", min_length=1, max_length=200), ctx=Depends(require_permission("purchasing.receive"))):
    db, actor, tenant_id, _ = ctx
    tenant_location(db, tenant_id, body.location_id)
    ensure_location_access(db, tenant_id=tenant_id, user_id=actor, location_id=body.location_id)
    variant = tenant_variant(db, tenant_id, body.variant_id)
    mode = db.execute(text("SELECT tracking_mode FROM public.product_variants WHERE tenant_id=:t AND id=:v"), {"t": str(tenant_id), "v": str(body.variant_id)}).scalar_one()
    if mode != "BATCH":
        raise HTTPException(409, "Set this product option to Batch / expiry tracking before receiving a lot.")
    if body.manufactured_on and body.expires_on and body.manufactured_on > body.expires_on:
        raise HTTPException(422, "Expiry date must be on or after the manufacture date.")
    payload = body.model_dump(mode="json")
    idem = idempotent_start(db, tenant_id, "inventory.traceability.lot_receipt", idempotency_key, payload)
    if isinstance(idem, tuple): return idem[1]
    # A receipt is a ledger movement and a lot registration in the same transaction.
    receipt_id = uuid4()
    tx = post_ledger(db, tenant_id=tenant_id, actor_user_id=actor, location_id=body.location_id, variant_id=body.variant_id,
        quantity_delta=body.quantity, unit_cost=body.unit_cost, transaction_type="TRACEABLE_RECEIPT",
        reference_type="traceable_receipt", reference_id=receipt_id, idempotency_key=f"{idempotency_key}:ledger",
        metadata={"reference": body.reference, "lot_number": body.lot_number, "tracking_mode": "BATCH"})
    lot_id = uuid4()
    db.execute(text("INSERT INTO public.inventory_lots(id,tenant_id,variant_id,location_id,lot_number,expires_on,manufactured_on,received_quantity,remaining_quantity,unit_cost,received_transaction_id) VALUES(:id,:t,:v,:loc,:lot,:expires,:made,:qty,:qty,:cost,:tx)"), {"id": str(lot_id), "t": str(tenant_id), "v": str(body.variant_id), "loc": str(body.location_id), "lot": body.lot_number, "expires": body.expires_on, "made": body.manufactured_on, "qty": body.quantity, "cost": body.unit_cost, "tx": str(tx.id)})
    db.execute(text("INSERT INTO public.inventory_lot_movements(tenant_id,lot_id,inventory_transaction_id,quantity_delta,remaining_after,movement_type,metadata) VALUES(:t,:lot,:tx,:qty,:qty,'RECEIPT',:meta)"), {"t": str(tenant_id), "lot": str(lot_id), "tx": str(tx.id), "qty": body.quantity, "meta": {"reference": body.reference}})
    write_audit(db, tenant_id=tenant_id, actor_user_id=actor, action="inventory.lot_receipt.posted", target_type="inventory_transaction", target_id=tx.id)
    emit_event(db, tenant_id=tenant_id, event_type="inventory.lot_receipt.posted.v1", aggregate_type="inventory_transaction", aggregate_id=tx.id, actor_user_id=actor, payload={"variant_id": str(variant.id), "lot_id": str(lot_id), "quantity": str(body.quantity), "expires_on": body.expires_on.isoformat() if body.expires_on else None})
    response = {"id": str(receipt_id), "lot_id": str(lot_id), "inventory_transaction_id": str(tx.id), "status": "POSTED", "quantity_received": str(body.quantity)}
    return _commit(db, idem, response)

@router.get("/lots")
def list_lots(location_id: UUID | None = None, variant_id: UUID | None = None, expiring_within_days: int | None = Query(None, ge=0, le=3650), limit: int = Query(200, ge=1, le=500), ctx=Depends(require_permission("inventory.read"))):
    db, actor, tenant_id, _ = ctx
    if location_id:
        tenant_location(db, tenant_id, location_id)
        ensure_location_access(db, tenant_id=tenant_id, user_id=actor, location_id=location_id)
    rows = db.execute(text("""
      SELECT lot.*,v.sku,v.name AS variant_name,p.name AS product_name,l.name AS location_name,
        CASE WHEN lot.expires_on IS NULL THEN NULL ELSE lot.expires_on-current_date END AS days_to_expiry
      FROM public.inventory_lots lot
      JOIN public.product_variants v ON v.tenant_id=lot.tenant_id AND v.id=lot.variant_id
      JOIN public.products p ON p.tenant_id=v.tenant_id AND p.id=v.product_id
      JOIN public.locations l ON l.tenant_id=lot.tenant_id AND l.id=lot.location_id
      WHERE lot.tenant_id=:t AND (:loc IS NULL OR lot.location_id=:loc) AND (:v IS NULL OR lot.variant_id=:v)
        AND (:days IS NULL OR lot.expires_on <= current_date + make_interval(days => :days))
      ORDER BY lot.expires_on NULLS LAST,lot.created_at,lot.id LIMIT :lim
    """), {"t": str(tenant_id), "loc": str(location_id) if location_id else None, "v": str(variant_id) if variant_id else None, "days": expiring_within_days, "lim": limit}).mappings().all()
    visible=[]
    for row in rows:
        try: ensure_location_access(db, tenant_id=tenant_id, user_id=actor, location_id=row["location_id"])
        except HTTPException: continue
        visible.append(dict(row))
    return visible
