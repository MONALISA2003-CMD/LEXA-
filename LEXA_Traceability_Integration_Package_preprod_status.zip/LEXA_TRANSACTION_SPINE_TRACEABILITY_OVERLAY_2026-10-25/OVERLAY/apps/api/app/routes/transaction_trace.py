"""Read-only end-to-end trace for a completed LEXA sale.

The endpoint follows the existing source transaction and its linked records. It
never creates sales, payments, inventory movements or journals.
"""
from __future__ import annotations

from decimal import Decimal
from typing import Any
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import or_, select, text
from sqlalchemy.orm import Session

from ..branch_access import ensure_branch_access, ensure_location_access
from ..dependencies import require_permission
from ..models import AuditLog, OutboxEvent

router = APIRouter(prefix="/transaction-trace", tags=["transaction-trace"])


def _out(row: Any) -> dict[str, Any]:
    if row is None:
        return {}
    values = row if hasattr(row, "items") else row._mapping
    out = {}
    for key, value in values.items():
        out[key] = str(value) if isinstance(value, Decimal) else value
    return out


@router.get("/sales/{sale_or_transaction_id}")
def trace_sale(sale_or_transaction_id: UUID, ctx=Depends(require_permission("sales.read"))):
    """Trace sale → stock/cost → recorded payments/receivable → journals → tax/audit/events."""
    db, actor, tenant_id, _ = ctx
    sale = db.execute(text("""
      SELECT s.*, bt.reference AS lexa_receipt_reference, bt.status AS source_transaction_status,
             bt.transaction_type AS source_transaction_type, bt.occurred_at AS source_occurred_at,
             bt.closed_at AS source_closed_at, bt.metadata AS source_metadata,
             b.name AS branch_name, l.name AS location_name
      FROM public.sales s
      JOIN public.business_transactions bt
        ON bt.tenant_id=s.tenant_id AND bt.id=s.transaction_id
      LEFT JOIN public.branches b ON b.tenant_id=s.tenant_id AND b.id=s.branch_id
      LEFT JOIN public.locations l ON l.tenant_id=s.tenant_id AND l.id=s.location_id
      WHERE s.tenant_id=:tenant
        AND (s.id=:source_id OR s.transaction_id=:source_id)
      LIMIT 1
    """), {"tenant": str(tenant_id), "source_id": str(sale_or_transaction_id)}).mappings().first()
    if not sale:
        raise HTTPException(404, "Sale or source transaction not found in this business.")
    if sale.get("branch_id"):
        ensure_branch_access(db, tenant_id=tenant_id, user_id=actor, branch_id=UUID(str(sale["branch_id"])))
    if sale.get("location_id"):
        ensure_location_access(db, tenant_id=tenant_id, user_id=actor, location_id=UUID(str(sale["location_id"])))

    sale_id, tx_id = str(sale["id"]), str(sale["transaction_id"])
    lines = db.execute(text("""
      SELECT id, line_no, line_type, product_variant_id, description, quantity, unit_price,
             line_total, discount_amount, tax_rate, tax_amount, metadata
      FROM public.transaction_lines
      WHERE tenant_id=:t AND transaction_id=:tx
      ORDER BY line_no, id
    """), {"t": str(tenant_id), "tx": tx_id}).mappings().all()

    movements = db.execute(text("""
      SELECT it.id, it.location_id, l.name AS location_name, it.variant_id,
             v.sku, v.name AS variant_name, p.name AS product_name,
             it.transaction_type, it.quantity_delta, it.unit_cost, it.total_cost,
             it.balance_after, it.reference_type, it.reference_id,
             it.source_transaction_id, it.occurred_at, it.metadata
      FROM public.inventory_transactions it
      JOIN public.product_variants v ON v.tenant_id=it.tenant_id AND v.id=it.variant_id
      JOIN public.products p ON p.tenant_id=v.tenant_id AND p.id=v.product_id
      LEFT JOIN public.locations l ON l.tenant_id=it.tenant_id AND l.id=it.location_id
      WHERE it.tenant_id=:t
        AND it.reference_type='sale' AND it.reference_id=:sale_id
      ORDER BY it.occurred_at, it.id
    """), {"t": str(tenant_id), "sale_id": sale_id}).mappings().all()

    receipts = db.execute(text("""
      SELECT it.id AS inventory_transaction_id, it.variant_id, v.sku, v.name AS variant_name,
             p.name AS product_name, it.location_id, l.name AS location_name,
             it.quantity_delta, it.unit_cost, it.total_cost, it.occurred_at,
             it.reference_type, it.reference_id, pr.receipt_number, pr.purchase_order_id
      FROM public.inventory_transactions it
      JOIN public.product_variants v ON v.tenant_id=it.tenant_id AND v.id=it.variant_id
      JOIN public.products p ON p.tenant_id=v.tenant_id AND p.id=v.product_id
      LEFT JOIN public.locations l ON l.tenant_id=it.tenant_id AND l.id=it.location_id
      LEFT JOIN public.purchase_receipts pr
        ON it.tenant_id=pr.tenant_id AND it.reference_type='purchase_receipt' AND pr.id=it.reference_id
      WHERE it.tenant_id=:t AND it.location_id=:sale_location_id AND it.quantity_delta > 0
        AND it.variant_id IN (SELECT product_variant_id FROM public.transaction_lines
          WHERE tenant_id=:t AND transaction_id=:tx AND product_variant_id IS NOT NULL)
        AND it.occurred_at <= :sale_time
      ORDER BY it.occurred_at DESC, it.id
      LIMIT 200
    """), {"t": str(tenant_id), "tx": tx_id, "sale_time": sale["source_occurred_at"], "sale_location_id": str(sale["location_id"])}).mappings().all()

    payment_rows = db.execute(text("""
      SELECT p.id AS payment_id, p.transaction_id, p.amount AS recorded_amount,
             p.currency_code, p.method, p.reference, p.status AS payment_status, p.paid_at,
             pa.id AS allocation_id, pa.amount AS allocated_amount, pa.status AS allocation_status,
             pa.receivable_id
      FROM public.payment_allocations pa
      JOIN public.payments p ON p.tenant_id=pa.tenant_id AND p.id=pa.payment_id
      LEFT JOIN public.receivables r ON r.tenant_id=pa.tenant_id AND r.id=pa.receivable_id
      WHERE pa.tenant_id=:t AND (pa.sale_id=:s OR r.sale_id=:s)
      ORDER BY p.paid_at, p.id, pa.id
    """), {"t": str(tenant_id), "s": sale_id}).mappings().all()

    receivables = db.execute(text("""
      SELECT id, sale_id, customer_party_id, original_amount, paid_amount,
             adjustment_amount, balance, status, due_at, created_at, updated_at
      FROM public.receivables WHERE tenant_id=:t AND sale_id=:s
      ORDER BY created_at, id
    """), {"t": str(tenant_id), "s": sale_id}).mappings().all()

    journals = db.execute(text("""
      SELECT je.id, je.source_type, je.source_id, je.entry_role, je.entry_date,
             je.reference, je.description, je.currency_code, je.status, je.posted_at,
             COALESCE(SUM(jl.debit),0) AS debit_total,
             COALESCE(SUM(jl.credit),0) AS credit_total,
             COALESCE(SUM(jl.debit),0)-COALESCE(SUM(jl.credit),0) AS difference
      FROM public.journal_entries je
      LEFT JOIN public.journal_lines jl ON jl.tenant_id=je.tenant_id AND jl.journal_entry_id=je.id
      WHERE je.tenant_id=:t AND (
        (je.source_type='SALE' AND je.source_id=:s)
        OR (je.source_type='PAYMENT' AND je.source_id IN (
          SELECT p.id FROM public.payment_allocations pa
          JOIN public.payments p ON p.tenant_id=pa.tenant_id AND p.id=pa.payment_id
          LEFT JOIN public.receivables r ON r.tenant_id=pa.tenant_id AND r.id=pa.receivable_id
          WHERE pa.tenant_id=:t AND (pa.sale_id=:s OR r.sale_id=:s)
        ))
        OR (je.source_type='SALE_RETURN' AND je.source_id IN (
          SELECT sr.id FROM public.sale_returns sr WHERE sr.tenant_id=:t AND sr.sale_id=:s
        ))
      )
      GROUP BY je.id
      ORDER BY je.entry_date, je.created_at, je.id
    """), {"t": str(tenant_id), "s": sale_id}).mappings().all()

    sale_returns = db.execute(text("""
      SELECT id, sale_id, transaction_id, status, reason, total, completed_at, created_at
      FROM public.sale_returns WHERE tenant_id=:t AND sale_id=:s ORDER BY created_at, id
    """), {"t": str(tenant_id), "s": sale_id}).mappings().all()

    # These records are immutable append-only evidence from the same transaction.
    audits = db.scalars(select(AuditLog).where(
        AuditLog.tenant_id == tenant_id,
        or_(AuditLog.target_id == UUID(sale_id), AuditLog.target_id == UUID(tx_id)),
    ).order_by(AuditLog.created_at.asc()).limit(200)).all()
    events = db.scalars(select(OutboxEvent).where(
        OutboxEvent.tenant_id == tenant_id,
        or_(OutboxEvent.aggregate_id == UUID(sale_id), OutboxEvent.aggregate_id == UUID(tx_id)),
    ).order_by(OutboxEvent.occurred_at.asc()).limit(200)).all()

    journal_rows = [_out(row) for row in journals]
    for journal in journal_rows:
        journal["balanced"] = abs(Decimal(str(journal["difference"]))) < Decimal("0.0001")
    totals = {
        "sale_total": str(sale["total"]),
        "tax_total": str(sale["tax_total"]),
        "recorded_payments_allocated": str(sum((Decimal(str(x["allocated_amount"] or 0)) for x in payment_rows), Decimal("0"))),
        "open_receivable_balance": str(sum((Decimal(str(x["balance"] or 0)) for x in receivables), Decimal("0"))),
        "stock_movements": len(movements),
        "balanced_journals": sum(1 for x in journal_rows if x["balanced"]),
        "unbalanced_journals": sum(1 for x in journal_rows if not x["balanced"]),
    }
    return {
        "source": "existing LEXA source transaction; read-only trace",
        "source_transaction": _out(sale),
        "receipt": {"reference": sale.get("lexa_receipt_reference"), "sale_id": sale_id, "transaction_id": tx_id},
        "product_and_tax_lines": [_out(row) for row in lines],
        "inventory_cost_movements": [_out(row) for row in movements],
        "prior_receipts_for_sale_items": [_out(row) for row in receipts],
        "recorded_payments_and_allocations": [_out(row) for row in payment_rows],
        "receivables": [_out(row) for row in receivables],
        "journals": journal_rows,
        "returns_and_credit_notes": [_out(row) for row in sale_returns],
        "audit_records": [
            {"id": str(a.id), "action": a.action, "target_type": a.target_type,
             "target_id": str(a.target_id), "outcome": a.outcome,
             "created_at": a.created_at.isoformat() if a.created_at else None,
             "correlation_id": a.correlation_id}
            for a in audits
        ],
        "events": [
            {"id": str(e.id), "event_type": e.event_type, "aggregate_type": e.aggregate_type,
             "aggregate_id": str(e.aggregate_id), "occurred_at": e.occurred_at.isoformat(),
             "payload": e.payload}
            for e in events
        ],
        "summary": totals,
        "reporting_note": "The summary is derived from linked source records; it does not create or replay an analytics event.",
    }
