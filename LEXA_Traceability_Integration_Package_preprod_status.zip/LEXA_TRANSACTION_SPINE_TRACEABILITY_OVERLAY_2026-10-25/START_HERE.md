# LEXA transaction spine + full serial/batch workflow overlay

This is a guarded source bundle for `MONALISA2003-CMD/LEXA-`, targeted at the existing `LEXA-branch`. GitHub source writes are denied by the connector (HTTP 403), so no branch, commit or pull request was pushed. Apply this ZIP to a clean local checkout and keep the production gates closed until the full test matrix passes.

## Included

- Migration 049 — serial/IMEI and batch/lot inventory traceability.
- Migration 050 — source transaction trace indexes.
- Migration 051 — connect canonical receiving, supplier returns, sale returns, transfers, counts and adjustments to the trace ledgers; requires receipt-origin matching for supplier returns; supports the existing sale-return `RETURN` alias.
- Read-only transaction trace API and business-readable frontend trace page.
- Existing checkout patch for serial selection and FEFO lot allocation.
- New guarded source patch for purchase-order receiving/returns, sale returns, transfers, stock counts and adjustments.
- Offline contract tests and acceptance checklist.

## Apply to local source

1. Check out `LEXA-branch` from `https://github.com/MONALISA2003-CMD/LEXA-` and verify the working tree is clean.
2. Run `python APPLY/apply_transaction_spine_overlay.py --repo /path/to/LEXA- --dry-run`. Review the edits, then run without `--dry-run`.
3. Run `python APPLY/apply_tracked_workflow_integration.py --repo /path/to/LEXA- --dry-run`. Review the edits, then run without `--dry-run`.
4. Run the offline contracts in `OVERLAY/tests/`. Reconcile the existing canonical migration recovery chain through 048 before attempting a full clean replay; the repo's current historical replay gate is closed and ends at migration 045.
5. Run the API tests, web typecheck/build, and authenticated end-to-end acceptance tests against a **disposable** PostgreSQL database. Do not deploy if any of these fail.

Both installers stop when a source anchor is missing or ambiguous; the second installer preflights all of its anchors before writing the three route files.

## Neon / Render / Vercel

A child branch named `lexa-inventory-overlay-replay-20261025` was schema-checked through version 051 under the separate `LEXA-PHASE7-REPLAY-20261022` project. Database trigger smoke tests passed for serial receipt/sale/return/double-sell rejection, batch receipt/transfers/sale/supplier return, count/adjustment, and the legacy standalone trace receipt paths. Synthetic QA fixtures remain only on this disposable branch. This did not touch production Neon or the backup project. Production Neon remains at 047, so Render `/ready` correctly remains 503. Vercel's latest production deployment is `READY`, but it does not include this ZIP. No remote deployment or environment change was made because the complete app build/E2E gates have not passed and the overlay has not been committed to GitHub.

Excluded by scope: EFRIS/URA API integrations and payment gateway, mobile-money, bank, or payment-processing APIs.
