from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    app_env: str = "development"
    database_url: str
    database_app_role: str = ""
    redis_url: str
    jwt_secret: str
    jwt_issuer: str = "lexa"
    jwt_audience: str = "lexa-web"
    access_token_minutes: int = 30
    refresh_token_days: int = 30
    cors_origins: str = "http://localhost:3000"
    lexa_neon_project_id: str = "wispy-mud-75323042"
    lexa_neon_branch_id: str = "br-soft-star-b1dj2m2w"
    lexa_open_dev_mode: bool = False
    lexa_open_dev_email: str = "preview@lexa.local"
    lexa_open_dev_workspace_name: str = "LEXA Workspace"
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    @property
    def sqlalchemy_database_url(self) -> str:
        """Return a SQLAlchemy PostgreSQL URL using psycopg 3.

        Neon and other managed PostgreSQL providers commonly expose
        postgresql:// URLs without a driver. SQLAlchemy may otherwise
        select the legacy psycopg2 dialect. LEXA standardizes on psycopg 3.
        """
        url = self.database_url.strip()
        if url.startswith("postgres://"):
            url = "postgresql://" + url[len("postgres://"): ]
        if url.startswith("postgresql+psycopg2://"):
            url = "postgresql+psycopg://" + url[len("postgresql+psycopg2://"): ]
        elif url.startswith("postgresql://"):
            url = "postgresql+psycopg://" + url[len("postgresql://"): ]
        return url

    @property
    def cors_origin_list(self) -> list[str]:
        return [origin.strip() for origin in self.cors_origins.split(",") if origin.strip()]


settings = Settings()
