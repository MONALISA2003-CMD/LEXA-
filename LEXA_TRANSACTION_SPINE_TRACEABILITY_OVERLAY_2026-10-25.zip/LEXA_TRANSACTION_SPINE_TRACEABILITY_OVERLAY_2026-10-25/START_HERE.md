# LEXA transaction-spine and inventory traceability overlay

This is a guarded source overlay for `MONALISA2003-CMD/LEXA-`, not a deployment. GitHub rejected branch creation with 403 `Resource not accessible by integration`, so no code was pushed and no production service was changed. The live status is not all green: Vercel deployment is READY, Render `/ready` is returning 503 on the Phase 7 schema gate, and Neon is at migration 047 without 048/049 traceability schema. Details and timestamps are in `IMPLEMENTATION_STATUS.md`.

## What it adds

- The Phase 1 serial/IMEI and batch/expiry register, immutable detail movements and deferred quantity reconciliation from `migrations/049_phase1_inventory_traceability.sql`.
- A read-only `/api/v1/transaction-trace/sales/{sale_id_or_transaction_id}` endpoint that follows an existing sale to tax-supporting lines, stock/cost movements, positive receipt history, payment allocations, receivables, journal debits/credits, returns, audit records and outbox events.
- A web trace screen at `/commerce/traceability` with business-readable summary and linked registers.
- An additive SQL index migration (050) for trace queries.
- A guarded installer that wires the routers, API helpers and pages, and patches checkout to require selected serial/IMEI identities or allocate batches by FEFO (first expiry, first out). The backend ledger/database trigger stays the single stock-deduction point; the trace screen is read-only.

## Apply to a local checkout

1. Start from a clean feature branch based on the source version from the supplied baseline (main commit `cd7fba79e4e75048a5e0b72c74f99053a627b023`).
2. Review the whole diff, especially the `commerce.py` checkout patch and the SQL trigger in migration 049.
3. Run `python APPLY/apply_transaction_spine_overlay.py --repo /path/to/LEXA- --dry-run` from this bundle's location, inspect the plan, then run without `--dry-run`. It refuses to overwrite any existing overlay target and aborts if source anchors are not unique.
4. Update the repository's clean-replay manifest so migrations 049 and 050 run after canonical migration 048. The existing manifest itself says clean replay/recovery approval is closed; do not bypass that gate or run the migrations on the Neon primary branch.
5. On a disposable local/CI PostgreSQL database, run the migration chain and the repo's API tests; run the web typecheck/build; add authenticated integration tests for the full acceptance matrix before merge.

## Important functional boundary

The existing LEXA sale code already creates the sale, inventory movement, recorded payments/allocations, any receivable, journals and outbox/audit effects in a single transaction guarded by idempotency. This overlay makes stock detail visible in the same path and exposes a read-only trace. The direct serial/batch receiving APIs in the inventory traceability router also post to the existing ledger.

**Not yet release-complete:** purchase-order receipt UI/posting, batch/serial sale returns, transfers, stock counts and stock adjustments still need identity allocations connected end-to-end. Migration 049 intentionally fails closed on unsupported quantity-only mutations for SERIAL/BATCH items rather than silently corrupting traceability. Do not enable these tracked operations for production until each path has a ledger-linked implementation and tests. Ordinary-quantity receiving, checkout, balances, stock value, journals and analytics continue using existing LEXA flows.

## Prohibited actions / scope

- No production SQL or production migration run.
- No Render or Vercel deploy, environment-variable edit or redeploy.
- No EFRIS/URA API or payment gateway/mobile money/bank/payment-processing API.
- No claim of production readiness from static checks or platform deployment state alone.
