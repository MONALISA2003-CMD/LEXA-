# LEXA Transaction Spine + Inventory Traceability Overlay

**Artifact type:** local source overlay for review; not merged, deployed, or validated against the complete app.

Start with `START_HERE.md` and read `IMPLEMENTATION_STATUS.md` before applying it. The overlay packages Phase 1 serial/batch foundations, guarded checkout integration, a read-only source-transaction trace screen/API, and migration 050 query indexes. It also records the live infrastructure status observed while preparing it.

Do not apply migrations to the Neon primary branch or trigger production deploys during this implementation phase. GitHub branch creation was blocked by the connector; use a local clean checkout and submit a reviewable PR from your own authorized environment.
