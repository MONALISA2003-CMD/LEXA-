# LEXA CI repair — ready-to-upload replacement files

Prepared against `MONALISA2003-CMD/LEXA-` main at commit `1958b27ba3b54bb5930c0b79b119a4951188379b` (24 October 2026).

## What this is

This ZIP contains the **complete corrected contents** of six existing test files, stored under the same repository paths. It is not a full copy of LEXA and it is not a GitHub Actions workflow. Do not upload this ZIP into `.github/workflows`.

The changes update stale test assertions to match the labels and wording in the current app. They do not change application runtime code, database migrations, authentication, deployment configuration, or the intentionally disabled external AI assistant.

## Files inside

- `apps/web/tests/phase1-ux-contract.test.mjs`
- `apps/web/tests/phase3-document-intelligence.test.mjs`
- `apps/web/tests/phase4-demand-forecast.test.mjs`
- `apps/web/tests/phase8-foundation-polish.test.mjs`
- `apps/web/tests/visible-product-contract.test.mjs`
- `apps/api/tests/test_intelligence_phase3.py`

`CI_CONTRACT_FIX.patch` contains the compact diff, while `MANUAL_EDIT_GUIDE.md` lists the six exact file paths and intended edits.

## Phone workflow

1. Download and open this ZIP using your Android file manager or ZIP app.
2. The folders inside mirror the repository paths. Use the full file text from each file to replace the contents of the same file in GitHub's browser editor. Do not create new files under different paths and don't upload the ZIP itself expecting GitHub to apply it automatically.
3. Make changes on a new branch, then open a pull request into `main`.
4. Review the changed files and let GitHub Actions complete before merging.

The GitHub integration available to this session refused write access, so this package has **not** been committed to your repository. The tests also have not been run in a complete local checkout here. A green Actions run is still required to prove the end-to-end repair.
