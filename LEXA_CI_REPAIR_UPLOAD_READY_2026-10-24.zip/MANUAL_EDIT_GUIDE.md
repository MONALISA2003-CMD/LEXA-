# Exact edits from GitHub's phone editor

Repository: `MONALISA2003-CMD/LEXA-`

For each file below, use GitHub's **Edit** feature and change only the specified lines. Commit changes to one branch, `fix/ci-contract-test-assertions`, rather than committing directly to `main`.

## 1. `apps/web/tests/phase1-ux-contract.test.mjs`

Find:
```js
assert.match(navigation, /Business settings/);
```
Replace with:
```js
assert.match(navigation, /Business details/);
```

## 2. `apps/web/tests/phase3-document-intelligence.test.mjs`

Inside the `AI assistant language is polished and clearly pauses external requests` test, replace these four assertions:
```js
assert.match(page, /Guidance that fits your business/);
assert.match(page, /AI responses are temporarily paused/);
assert.match(page, /Your question will not be sent to a provider/);
assert.match(page, /executionAvailable &&/);
```
with:
```js
assert.match(page, /Guidance for your business/);
assert.match(page, /The assistant isn’t available right now/);
assert.match(page, /will not generate or pretend to generate an answer while the assistant is unavailable/);
assert.doesNotMatch(page, /fetch\(|<textarea|executionAvailable &&/);
```

Later in the same file, replace:
```js
assert.match(page, /Information that needs a refresh/);
assert.match(page, /Missing data is never presented as zero/);
```
with:
```js
assert.match(page, /Information to check or update/);
assert.match(page, /Missing information is never treated as zero/);
```

## 3. `apps/web/tests/phase4-demand-forecast.test.mjs`

Replace:
```js
assert.match(nav, /\["\/demand-forecast", "Demand forecast", "chart"\]/);
assert.match(nav, /Product demand forecast/);
```
with:
```js
assert.match(nav, /\["\/demand-forecast", "Sales forecast", "chart"\]/);
assert.match(nav, /Expected demand and sales forecast/);
```

## 4. `apps/web/tests/phase8-foundation-polish.test.mjs`

In the `for (const label of [...])` line, replace the label `Finance` with `Money & records`. The complete corrected line is:
```js
for (const label of ["Home", "Sales", "Stock", "Products", "Customers", "Purchases", "Money & records", "Reports"]) assert.ok(navigation.includes(`"${label}"`));
```

## 5. `apps/web/tests/visible-product-contract.test.mjs`

Find:
```js
assert.match(navigation, /Business settings/);
```
Replace with:
```js
assert.match(navigation, /Business details/);
```

## 6. `apps/api/tests/test_intelligence_phase3.py`

Inside `test_phase3_api_ui_and_policy_keep_review_separate_from_business_writes`, replace:
```py
    assert "executionAvailable &&" in ai_ui
    assert "Your question will not be sent to a provider" in ai_ui
```
with:
```py
    assert "The assistant isn’t available right now." in ai_ui
    assert "will not generate or pretend to generate an answer while the assistant is unavailable" in ai_ui
    assert "fetch(" not in ai_ui
    assert "<textarea" not in ai_ui
```

## Before merging

Open the pull request and confirm only those six test files changed. Do not change `apps/web/app/ai-assistant/page.tsx`, enable any external AI provider, add API keys, or alter policy gates to get CI green. Then wait for the GitHub Actions checks attached to the pull request to complete before merging.
