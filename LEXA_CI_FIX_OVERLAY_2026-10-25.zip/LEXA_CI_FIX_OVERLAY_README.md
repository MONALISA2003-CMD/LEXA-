# LEXA CI Fix Overlay — 25 October 2026

This is a **test-only source overlay** for repository `MONALISA2003-CMD/LEXA-`.

## Root cause addressed

1. `apps/web/tests/ura-efris-external-ai.test.mjs` expected a former UI sentence (`do not create a default tax rule`). The current Phase 3 UI instead uses an explicit owner-confirmation guard before activating standard-rated VAT. The contract now checks that guard and its explanatory message.
2. `apps/api/tests/test_performance_observability.py` searched the entire `apps/api/app/main.py` for `request.body`. The separate manual-only EFRIS guard intentionally reads the EFRIS configuration request body to reject system-to-system mode. The test now scopes the no-body/no-query assertion to `request_id_middleware`, where request logging and timing happen.

No production application code, database schema, migration, secrets, tax records, payment records, or hosting settings are changed by this overlay.

## How to apply

Upload this ZIP through the existing **LEXA ZIP Extractor** at the repository root. It contains canonical `apps/...` paths. Do not apply it directly to Neon or deploy it around CI. Trigger and inspect a new `LEXA Main Build CI` run on the resulting exact commit. Require all API tests, frontend contracts, typecheck, production build, Compose and HAProxy checks to pass.

## Current known base

`7f01d167229e7c0a57b53753dbefb8b9c9be94ce` — the current `main` head inspected on 25 October 2026. GitHub branch creation was denied to the connected integration (403), so this is a local overlay only; it has not been pushed or deployed.
