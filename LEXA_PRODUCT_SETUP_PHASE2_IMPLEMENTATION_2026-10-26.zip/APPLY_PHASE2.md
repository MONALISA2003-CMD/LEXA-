# Apply the Phase 2 overlay

1. Back up or branch from the already-audited canonical LEXA source.
2. Extract this ZIP at the repository root, preserving the included `apps/...` paths.
3. Inspect each file diff in the canonical repository before committing.
4. Run focused tests first, then the full API/web CI checks and authenticated PostgreSQL staging journey.
5. Do not treat this overlay as a database migration or a deployment. No migration is included because Phase 2 uses existing tables/columns.

The package intentionally excludes generated dependencies, secrets, `.env` files, local state and database dumps.
