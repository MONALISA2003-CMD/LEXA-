# LEXA Product Setup — Phase 2 Implementation Report

**Date:** 26 October 2026  
**Delivery type:** local source overlay; not merged or deployed  
**Scope:** five-step Product Setup wizard connected to existing catalogue APIs and database models

## Implemented

- Integrated the new five-step wizard into the existing Products page: Identity; SKU and variants; Tracking; Pricing and costing; Review.
- Added a typed `POST /api/v1/catalog/products/full-setup` endpoint that creates a product, variants, attribute values, barcodes and prices in one database transaction, with audit/outbox records and idempotency support.
- Added single-item, manual-variant and attribute-generated workflows. Attribute combinations can be previewed, capped at 100, and excluded before submission.
- Added editable SKU suggestions, barcode type/value and optional manufacturer part number. Manufacturer part number is stored in the existing variant JSON metadata, not a new indexed column.
- Added variant-level units, quantity tracking and fractional-quantity validation.
- Required an active and currently effective tenant price list and a valid selling price/minimum quantity for every submitted saleable variant. New price records inherit the price-list expiry date.
- Hardened server validation for tenant-scoped category, brand, unit, attribute definition and price-list references; duplicate SKUs, barcodes and variant combinations; supported attribute data types; finite numeric attributes/prices; and HTTPS image URLs.
- Reused the existing idempotent request helper so retries with the same payload reuse a request key. A failed page refresh after a successful create is reported as a refresh problem, not a failed product write.
- Kept opening stock out of product creation. The wizard directs users to Inventory for opening balances.
- Preserved the catalogue detail and inventory paths by refreshing the Products page and opening the created product's variant detail after successful creation.

## Database decision

**No new database migration is required for the supported Phase 2 writes.** The inspected schema already includes product and variant records, JSON metadata, barcode records, attribute definitions and values, price lists/prices, variant tracking fields and costing method. The endpoint writes to those existing structures and commits all required catalogue records atomically. Existing SKU/barcode uniqueness constraints remain the database backstop. No live database was changed by this package.

## Explicitly not represented as complete

- **Draft saving/autosave:** not implemented in this phase because the current product lifecycle has no verified draft state. The wizard creates active or inactive products only.
- **Serial/IMEI and batch/lot/expiry tracking:** deliberately not exposed as working controls because the inspected downstream receipt, transfer, sale, return and adjustment flows do not establish full lifecycle enforcement.
- **Category tracking defaults and authorized overrides:** not configured by this wizard; the current category schema/API does not provide the required default fields.
- **Tax classification:** the wizard leaves classification unassigned. The product's nullable `tax_category_id` has no tenant-safe catalogue lookup or foreign-key-backed category model in this snapshot, and the current sales resolver uses effective-dated Finance tax rules. The new full-setup endpoint rejects a non-null tax-category ID instead of silently storing an unverified identifier. Required-tax blocking at sale posting still needs dedicated verification in the subsequent backend-rules phase.
- **Costing:** weighted average is the only method exposed. Other methods are not offered without verified valuation/accounting behaviour.
- **Supplier/reorder details and direct image upload:** not offered because the corresponding product-level fields or image-storage upload contract are not established in this snapshot. An HTTPS image URL may be saved in product metadata.

These are phase boundaries, not claims that LEXA can never support the capabilities.

## Validation results

- `python -m py_compile apps/api/app/routes/catalog.py`: **passed**.
- Focused API product setup + quick setup contract tests: **12 passed**.
- Phase 2 frontend contract tests: **4 passed**.
- Isolated TypeScript check of the wizard and API module against a typed React/JSX stub: **passed**. This is a targeted check, not the full application typecheck.
- Full API snapshot suite: **210 passed, 6 failed**. The six failures are outside Product Setup and were present in the source snapshot before Phase 2: an older sales receipt-source assertion; missing `apps/api/app/routes/tax_reference.py`; missing migration `048_phase7_approval_limits_reversals_accounting.sql`; two stale auth/RLS source assertions; and a reconstructed migration 021 ending assertion.
- Full web snapshot suite: **67 passed, 3 failed**. The two CI/purchasing tests depend on missing `.github/workflows/lexa-ci.yml`; one release-polish test fails on an unrelated customer-page placeholder assertion. The four new Phase 2 UI contract tests pass.
- Full Next.js typecheck/build and live PostgreSQL/staging end-to-end creation were **not verified** in this environment. Frontend dependency installation did not complete; no live database was contacted.

## GitHub and release status

GitHub write access remains unavailable. No commit, merge, migration run, production data write or deployment was performed. This ZIP is an overlay package containing the updated source files at their repository-relative paths. Apply it to the validated canonical source branch and rerun the complete CI/staging workflow before release.
