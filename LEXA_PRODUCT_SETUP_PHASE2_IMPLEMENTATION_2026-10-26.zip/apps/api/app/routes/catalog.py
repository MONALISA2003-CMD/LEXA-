from __future__ import annotations

import base64
import json
from datetime import datetime, timezone
from decimal import Decimal
from typing import Any
from urllib.parse import urlsplit
from uuid import UUID

from fastapi import APIRouter, Depends, Header, HTTPException, Query, status
from fastapi.responses import JSONResponse
from pydantic import BaseModel, ConfigDict, Field
from sqlalchemy import and_, exists, or_, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from ..catalog import CatalogValidation, begin_idempotency, emit_event, finish_idempotency, normalize_code, normalize_text, utc_now, validate_minimum_quantity, validate_price, write_audit
from ..dependencies import require_permission
from ..models import (
    Barcode, Brand, Category, PriceList, Product, ProductAttributeDefinition,
    ProductAttributeValue, ProductPrice, ProductVariant, Unit,
)

router = APIRouter(prefix="/catalog", tags=["catalog"])

class ORM(BaseModel):
    model_config = ConfigDict(from_attributes=True)

class Page(BaseModel):
    items: list[Any]
    next_cursor: str | None = None

class CategoryIn(BaseModel):
    name: str; code: str; description: str | None = None; parent_id: UUID | None = None; sort_order: int = 0
class CategoryPatch(BaseModel):
    name: str | None = None; description: str | None = None; parent_id: UUID | None = None; sort_order: int | None = None; status: str | None = None
class CategoryOut(ORM):
    id: UUID; tenant_id: UUID; parent_id: UUID | None; name: str; code: str; description: str | None; status: str; sort_order: int

class BrandIn(BaseModel):
    name: str; code: str | None = None; description: str | None = None
class BrandPatch(BaseModel):
    name: str | None = None; code: str | None = None; description: str | None = None; status: str | None = None
class BrandOut(ORM):
    id: UUID; tenant_id: UUID; name: str; code: str | None; description: str | None; status: str

class UnitIn(BaseModel):
    name: str; code: str; symbol: str; unit_type: str = "COUNT"; allows_fraction: bool = False; precision_scale: int = Field(default=0, ge=0, le=6)
class UnitOut(ORM):
    id: UUID; tenant_id: UUID | None; name: str; code: str; symbol: str; unit_type: str; allows_fraction: bool; precision_scale: int; is_system: bool

class ProductIn(BaseModel):
    name: str; category_id: UUID; brand_id: UUID | None = None; description: str | None = None; product_type: str = "STOCKED"; has_variants: bool = True; tax_category_id: UUID | None = None; metadata: dict[str, Any] = Field(default_factory=dict)
class ProductQuickSetupIn(BaseModel):
    product_name: str = Field(min_length=1, max_length=250)
    category_id: UUID
    brand_id: UUID | None = None
    description: str | None = None
    product_type: str = "STOCKED"
    tax_category_id: UUID | None = None
    product_metadata: dict[str, Any] = Field(default_factory=dict)
    variant_name: str = Field(min_length=1, max_length=200)
    sku: str = Field(min_length=1, max_length=100)
    base_unit_id: UUID
    track_inventory: bool = True
    allow_fractional_quantity: bool = False
    costing_method: str = "WEIGHTED_AVERAGE"
    variant_metadata: dict[str, Any] = Field(default_factory=dict)
    barcode: str | None = Field(default=None, max_length=120)
    barcode_type: str = "OTHER"
    price_list_id: UUID | None = None
    unit_price: Decimal | None = Field(default=None, ge=0)
    minimum_quantity: Decimal = Field(default=Decimal("1"), gt=0)
    effective_from: datetime | None = None


class ProductPatch(BaseModel):
    name: str | None = None; category_id: UUID | None = None; brand_id: UUID | None = None; description: str | None = None; status: str | None = None; has_variants: bool | None = None; tax_category_id: UUID | None = None; metadata: dict[str, Any] | None = None
class ProductOut(ORM):
    id: UUID; tenant_id: UUID; category_id: UUID; brand_id: UUID | None; name: str; description: str | None; product_type: str; status: str; has_variants: bool; tax_category_id: UUID | None; metadata: dict = Field(validation_alias="product_metadata")

class VariantIn(BaseModel):
    product_id: UUID; name: str; sku: str; base_unit_id: UUID; track_inventory: bool = True; allow_fractional_quantity: bool = False; costing_method: str | None = None; metadata: dict[str, Any] = Field(default_factory=dict)
class VariantPatch(BaseModel):
    name: str | None = None; base_unit_id: UUID | None = None; track_inventory: bool | None = None; allow_fractional_quantity: bool | None = None; status: str | None = None; costing_method: str | None = None; metadata: dict[str, Any] | None = None
class VariantOut(ORM):
    id: UUID; tenant_id: UUID; product_id: UUID; name: str; sku: str; base_unit_id: UUID; track_inventory: bool; allow_fractional_quantity: bool; status: str; costing_method: str | None; metadata: dict = Field(validation_alias="variant_metadata")

class BarcodeIn(BaseModel):
    variant_id: UUID; barcode: str; barcode_type: str = "OTHER"; is_primary: bool = False
class BarcodeOut(ORM):
    id: UUID; tenant_id: UUID; variant_id: UUID; barcode: str; barcode_type: str; is_primary: bool; status: str

class AttributeDefinitionIn(BaseModel):
    name: str; code: str; category_id: UUID | None = None; data_type: str; required: bool = False; options: dict[str, Any] | None = None
class AttributeDefinitionOut(ORM):
    id: UUID; tenant_id: UUID; category_id: UUID | None; name: str; code: str; data_type: str; required: bool; options: dict | None

class AttributeValueIn(BaseModel):
    variant_id: UUID; attribute_definition_id: UUID; value_text: str | None = None; value_number: Decimal | None = None; value_boolean: bool | None = None; value_date: datetime | None = None; value_json: dict[str, Any] | list[Any] | None = None
class AttributeValueOut(ORM):
    id: UUID; tenant_id: UUID; variant_id: UUID; attribute_definition_id: UUID; value_text: str | None; value_number: float | None; value_boolean: bool | None; value_date: datetime | None; value_json: dict | list | None

class PriceListIn(BaseModel):
    name: str; currency: str = "UGX"; price_type: str = "RETAIL"; effective_from: datetime; effective_to: datetime | None = None
class PriceListOut(ORM):
    id: UUID; tenant_id: UUID; name: str; currency: str; price_type: str; status: str; effective_from: datetime; effective_to: datetime | None
class ProductPriceIn(BaseModel):
    price_list_id: UUID; variant_id: UUID; unit_price: Decimal = Field(ge=0); minimum_quantity: Decimal = Field(default=Decimal("1"), gt=0); effective_from: datetime; effective_to: datetime | None = None
class ProductPriceOut(ORM):
    id: UUID; tenant_id: UUID; price_list_id: UUID; variant_id: UUID; unit_price: Decimal; minimum_quantity: Decimal; effective_from: datetime; effective_to: datetime | None

class ProductQuickSetupOut(BaseModel):
    product: ProductOut
    variant: VariantOut
    barcode: BarcodeOut | None = None
    price: ProductPriceOut | None = None
    opening_stock_created: bool
    next_step: str


class ProductSetupVariantIn(BaseModel):
    name: str = Field(min_length=1, max_length=200)
    sku: str = Field(min_length=1, max_length=100)
    base_unit_id: UUID
    track_inventory: bool = True
    allow_fractional_quantity: bool = False
    costing_method: str = "WEIGHTED_AVERAGE"
    barcode: str | None = Field(default=None, max_length=120)
    barcode_type: str = Field(default="OTHER", max_length=30)
    manufacturer_part_number: str | None = Field(default=None, max_length=120)
    price_list_id: UUID
    unit_price: Decimal = Field(ge=0)
    minimum_quantity: Decimal = Field(default=Decimal("1"), gt=0)
    attributes: dict[str, Any] = Field(default_factory=dict)


class ProductFullSetupIn(BaseModel):
    product_name: str = Field(min_length=1, max_length=250)
    category_id: UUID
    brand_id: UUID | None = None
    description: str | None = None
    image_url: str | None = Field(default=None, max_length=2048)
    product_type: str = "STOCKED"
    status: str = "ACTIVE"
    tax_category_id: UUID | None = None
    product_metadata: dict[str, Any] = Field(default_factory=dict)
    variants: list[ProductSetupVariantIn] = Field(min_length=1, max_length=100)
    combination_attribute_ids: list[UUID] = Field(default_factory=list, max_length=10)
    effective_from: datetime | None = None


class ProductFullSetupOut(BaseModel):
    product: ProductOut
    variants: list[VariantOut]
    barcodes: list[BarcodeOut]
    prices: list[ProductPriceOut]
    opening_stock_created: bool = False
    next_step: str




def enc_cursor(value: UUID) -> str:
    return base64.urlsafe_b64encode(json.dumps({"id": str(value)}).encode()).decode()

def dec_cursor(cursor: str | None) -> UUID | None:
    if not cursor: return None
    try: return UUID(json.loads(base64.urlsafe_b64decode(cursor.encode()).decode())["id"])
    except Exception as exc: raise HTTPException(400, "Invalid cursor") from exc

def page(stmt, model, db: Session, limit: int, cursor: str | None):
    after = dec_cursor(cursor)
    if after: stmt = stmt.where(model.id > after)
    rows = list(db.scalars(stmt.order_by(model.id).limit(limit + 1)))
    next_cursor = enc_cursor(rows[-1].id) if len(rows) > limit else None
    return rows[:limit], next_cursor

def commit_or_409(db: Session, detail: str):
    try:
        db.commit()
    except IntegrityError as exc:
        db.rollback()
        raise HTTPException(409, detail) from exc

@router.get("/categories", response_model=Page)
def categories(limit: int = Query(50, ge=1, le=100), cursor: str | None = None, ctx=Depends(require_permission("catalog.read"))):
    db, _, tenant_id, _ = ctx
    rows, nxt = page(select(Category).where(Category.tenant_id == tenant_id, Category.deleted_at.is_(None)), Category, db, limit, cursor)
    return Page(items=[CategoryOut.model_validate(x) for x in rows], next_cursor=nxt)

@router.post("/categories", response_model=CategoryOut, status_code=status.HTTP_201_CREATED)
def create_category(body: CategoryIn, ctx=Depends(require_permission("catalog.manage"))):
    db, actor, tenant_id, _ = ctx
    try:
        code = normalize_code(body.code, "Category code"); name = normalize_text(body.name, "Category name")
        if body.parent_id and not db.scalar(select(Category.id).where(Category.id == body.parent_id, Category.tenant_id == tenant_id, Category.deleted_at.is_(None))):
            raise HTTPException(400, "Parent category does not belong to tenant")
        row = Category(tenant_id=tenant_id, name=name, code=code, description=body.description, parent_id=body.parent_id, sort_order=body.sort_order)
        db.add(row); db.flush()
        write_audit(db, tenant_id=tenant_id, actor_user_id=actor, action="catalog.category.created", target_type="category", target_id=row.id)
        emit_event(db, tenant_id=tenant_id, event_type="CategoryCreated", aggregate_type="category", aggregate_id=row.id, actor_user_id=actor, payload={"id": str(row.id), "code": code, "name": name})
    except CatalogValidation as exc: db.rollback(); raise HTTPException(422, str(exc)) from exc
    commit_or_409(db, "Category code already exists for this tenant")
    return row

@router.patch("/categories/{category_id}", response_model=CategoryOut)
def patch_category(category_id: UUID, body: CategoryPatch, ctx=Depends(require_permission("catalog.manage"))):
    db, actor, tenant_id, _ = ctx
    row = db.scalar(select(Category).where(Category.id == category_id, Category.tenant_id == tenant_id, Category.deleted_at.is_(None)))
    if not row: raise HTTPException(404, "Category not found")
    if body.parent_id == category_id: raise HTTPException(409, "Category cannot be its own parent")
    if body.parent_id and not db.scalar(select(Category.id).where(Category.id == body.parent_id, Category.tenant_id == tenant_id, Category.deleted_at.is_(None))): raise HTTPException(400, "Parent category does not belong to tenant")
    if body.name is not None: row.name = normalize_text(body.name, "Category name")
    if body.description is not None: row.description = body.description
    if body.parent_id is not None: row.parent_id = body.parent_id
    if body.sort_order is not None: row.sort_order = body.sort_order
    if body.status is not None: row.status = normalize_code(body.status, "Status")
    db.flush(); write_audit(db, tenant_id=tenant_id, actor_user_id=actor, action="catalog.category.updated", target_type="category", target_id=row.id); emit_event(db, tenant_id=tenant_id, event_type="CategoryUpdated", aggregate_type="category", aggregate_id=row.id, actor_user_id=actor, payload={"id": str(row.id), "status": row.status})
    commit_or_409(db, "Category update conflicts with existing data"); return row

@router.delete("/categories/{category_id}", response_model=CategoryOut)
def delete_category(category_id: UUID, ctx=Depends(require_permission("catalog.manage"))):
    db, actor, tenant_id, _ = ctx
    row = db.scalar(select(Category).where(Category.id == category_id, Category.tenant_id == tenant_id, Category.deleted_at.is_(None)))
    if not row: raise HTTPException(404, "Category not found")
    child = db.scalar(select(Category.id).where(Category.parent_id == row.id, Category.deleted_at.is_(None)))
    product = db.scalar(select(Product.id).where(Product.category_id == row.id, Product.deleted_at.is_(None)))
    if child or product: raise HTTPException(409, "Category is still referenced")
    row.deleted_at = utc_now(); row.deleted_by = actor; row.status = "INACTIVE"; db.flush(); write_audit(db, tenant_id=tenant_id, actor_user_id=actor, action="catalog.category.deleted", target_type="category", target_id=row.id); emit_event(db, tenant_id=tenant_id, event_type="CategoryDeleted", aggregate_type="category", aggregate_id=row.id, actor_user_id=actor, payload={"id": str(row.id)})
    db.commit(); return row

@router.get("/brands", response_model=Page)
def brands(limit: int = Query(50, ge=1, le=100), cursor: str | None = None, ctx=Depends(require_permission("catalog.read"))):
    db, _, tenant_id, _ = ctx; rows, nxt = page(select(Brand).where(Brand.tenant_id == tenant_id, Brand.deleted_at.is_(None)), Brand, db, limit, cursor); return Page(items=[BrandOut.model_validate(x) for x in rows], next_cursor=nxt)

@router.post("/brands", response_model=BrandOut, status_code=201)
def create_brand(body: BrandIn, ctx=Depends(require_permission("catalog.manage"))):
    db, actor, tenant_id, _ = ctx
    try: name = normalize_text(body.name, "Brand name"); code = normalize_code(body.code, "Brand code") if body.code else None
    except CatalogValidation as exc: raise HTTPException(422, str(exc)) from exc
    row = Brand(tenant_id=tenant_id, name=name, code=code, description=body.description); db.add(row); db.flush(); write_audit(db, tenant_id=tenant_id, actor_user_id=actor, action="catalog.brand.created", target_type="brand", target_id=row.id); emit_event(db, tenant_id=tenant_id, event_type="BrandCreated", aggregate_type="brand", aggregate_id=row.id, actor_user_id=actor, payload={"id": str(row.id), "name": name, "code": code}); commit_or_409(db, "Brand code conflicts with existing data"); return row

@router.patch("/brands/{brand_id}", response_model=BrandOut)
def patch_brand(brand_id: UUID, body: BrandPatch, ctx=Depends(require_permission("catalog.manage"))):
    db, actor, tenant_id, _ = ctx; row = db.scalar(select(Brand).where(Brand.id == brand_id, Brand.tenant_id == tenant_id, Brand.deleted_at.is_(None)))
    if not row: raise HTTPException(404, "Brand not found")
    try:
        if body.name is not None: row.name = normalize_text(body.name, "Brand name")
        if body.code is not None: row.code = normalize_code(body.code, "Brand code")
        if body.description is not None: row.description = body.description
        if body.status is not None: row.status = normalize_code(body.status, "Status")
    except CatalogValidation as exc: raise HTTPException(422, str(exc)) from exc
    db.flush(); write_audit(db, tenant_id=tenant_id, actor_user_id=actor, action="catalog.brand.updated", target_type="brand", target_id=row.id); emit_event(db, tenant_id=tenant_id, event_type="BrandUpdated", aggregate_type="brand", aggregate_id=row.id, actor_user_id=actor, payload={"id": str(row.id), "status": row.status}); commit_or_409(db, "Brand update conflicts with existing data"); return row

@router.get("/units", response_model=Page)
def units(limit: int = Query(50, ge=1, le=100), cursor: str | None = None, ctx=Depends(require_permission("catalog.read"))):
    db, _, tenant_id, _ = ctx
    stmt = select(Unit).where((Unit.tenant_id == tenant_id) | (Unit.tenant_id.is_(None)))
    rows, nxt = page(stmt, Unit, db, limit, cursor); return Page(items=[UnitOut.model_validate(x) for x in rows], next_cursor=nxt)

@router.post("/units", response_model=UnitOut, status_code=201)
def create_unit(body: UnitIn, ctx=Depends(require_permission("catalog.manage"))):
    db, actor, tenant_id, _ = ctx
    try:
        name = normalize_text(body.name, "Unit name"); code = normalize_code(body.code, "Unit code")
        if body.allows_fraction and body.precision_scale < 1: raise CatalogValidation("Fractional units require a precision scale")
    except CatalogValidation as exc: raise HTTPException(422, str(exc)) from exc
    row = Unit(tenant_id=tenant_id, name=name, code=code, symbol=body.symbol.strip(), unit_type=normalize_code(body.unit_type, "Unit type"), allows_fraction=body.allows_fraction, precision_scale=body.precision_scale, is_system=False); db.add(row); db.flush(); write_audit(db, tenant_id=tenant_id, actor_user_id=actor, action="catalog.unit.created", target_type="unit", target_id=row.id); emit_event(db, tenant_id=tenant_id, event_type="UnitCreated", aggregate_type="unit", aggregate_id=row.id, actor_user_id=actor, payload={"id": str(row.id), "code": code}); commit_or_409(db, "Unit code conflicts with existing data"); return row

@router.get("/products", response_model=Page)
def products(limit: int = Query(50, ge=1, le=100), cursor: str | None = None, q: str | None = Query(None, min_length=1), status_filter: str | None = None, ctx=Depends(require_permission("catalog.read"))):
    db, _, tenant_id, _ = ctx; stmt = select(Product).where(Product.tenant_id == tenant_id, Product.deleted_at.is_(None))
    if q: stmt = stmt.where(Product.name.ilike(f"%{q.strip()}%"))
    if status_filter: stmt = stmt.where(Product.status == normalize_code(status_filter, "Status"))
    rows, nxt = page(stmt, Product, db, limit, cursor); return Page(items=[ProductOut.model_validate(x) for x in rows], next_cursor=nxt)

@router.get("/lookup", response_model=list[dict])
def catalog_lookup(q: str = Query(..., min_length=1), limit: int = Query(20, ge=1, le=50), ctx=Depends(require_permission("catalog.read"))):
    db, _, tenant_id, _ = ctx
    needle = q.strip()
    barcode_match = exists(select(1).select_from(Barcode).where(Barcode.variant_id == ProductVariant.id, Barcode.tenant_id == tenant_id, Barcode.status == "ACTIVE", Barcode.barcode == needle))
    rows = db.execute(
        select(ProductVariant, Product.name.label("product_name"))
        .join(Product, Product.id == ProductVariant.product_id)
        .where(
            ProductVariant.tenant_id == tenant_id, ProductVariant.deleted_at.is_(None), ProductVariant.status == "ACTIVE", Product.deleted_at.is_(None),
            or_(ProductVariant.sku.ilike(f"%{needle}%"), ProductVariant.name.ilike(f"%{needle}%"), Product.name.ilike(f"%{needle}%"), barcode_match),
        ).order_by(ProductVariant.id).limit(limit)
    ).all()
    return [{"variant_id": v.id, "product_id": v.product_id, "product_name": product_name, "variant_name": v.name, "sku": v.sku} for v, product_name in rows]

@router.post("/products", response_model=ProductOut, status_code=201)
def create_product(body: ProductIn, idempotency_key: str | None = Header(None, alias="Idempotency-Key"), ctx=Depends(require_permission("catalog.manage"))):
    db, actor, tenant_id, _ = ctx
    try:
        idem, replay = begin_idempotency(db, tenant_id=tenant_id, operation_type="catalog.product.create", key=idempotency_key, payload=body.model_dump(mode="json"))
    except CatalogValidation as exc:
        db.rollback(); raise HTTPException(409 if "different" in str(exc) else 422, str(exc)) from exc
    if replay:
        return JSONResponse(status_code=replay[0], content=replay[1])
    if not db.scalar(select(Category.id).where(Category.id == body.category_id, Category.tenant_id == tenant_id, Category.deleted_at.is_(None))): raise HTTPException(400, "Category does not belong to tenant")
    if body.brand_id and not db.scalar(select(Brand.id).where(Brand.id == body.brand_id, Brand.tenant_id == tenant_id, Brand.deleted_at.is_(None))): raise HTTPException(400, "Brand does not belong to tenant")
    try: name = normalize_text(body.name, "Product name"); product_type = normalize_code(body.product_type, "Product type")
    except CatalogValidation as exc: db.rollback(); raise HTTPException(422, str(exc)) from exc
    row = Product(tenant_id=tenant_id, category_id=body.category_id, brand_id=body.brand_id, name=name, description=body.description, product_type=product_type, has_variants=body.has_variants, tax_category_id=body.tax_category_id, product_metadata=body.metadata); db.add(row); db.flush(); write_audit(db, tenant_id=tenant_id, actor_user_id=actor, action="catalog.product.created", target_type="product", target_id=row.id); emit_event(db, tenant_id=tenant_id, event_type="ProductCreated", aggregate_type="product", aggregate_id=row.id, actor_user_id=actor, payload={"id": str(row.id), "name": name, "category_id": str(body.category_id), "brand_id": str(body.brand_id) if body.brand_id else None});
    finish_idempotency(db, idem, status_code=201, response_body=ProductOut.model_validate(row).model_dump(mode="json"), resource_type="product", resource_id=row.id)
    db.commit(); return row

@router.post("/products/quick-setup", response_model=ProductQuickSetupOut, status_code=201)
def create_product_quick_setup(
    body: ProductQuickSetupIn,
    idempotency_key: str | None = Header(None, alias="Idempotency-Key"),
    ctx=Depends(require_permission("catalog.manage")),
):
    """Create a product and its first sellable variant in one database transaction.

    Optional barcode and price are committed with the product/variant or not at all.
    Opening stock is deliberately excluded: stock must enter through audited inventory
    movements or a posted goods receipt, never through a catalog form.
    """
    db, actor, tenant_id, _ = ctx
    try:
        idem, replay = begin_idempotency(
            db,
            tenant_id=tenant_id,
            operation_type="catalog.product.quick_setup",
            key=idempotency_key,
            payload=body.model_dump(mode="json"),
        )
    except CatalogValidation as exc:
        db.rollback()
        raise HTTPException(409 if "different" in str(exc) else 422, str(exc)) from exc
    if replay:
        return JSONResponse(status_code=replay[0], content=replay[1])

    if (body.unit_price is None) != (body.price_list_id is None):
        db.rollback()
        raise HTTPException(422, "Provide both a price list and a selling price, or neither.")
    category = db.scalar(select(Category).where(
        Category.id == body.category_id,
        Category.tenant_id == tenant_id,
        Category.deleted_at.is_(None),
        Category.status == "ACTIVE",
    ))
    if not category:
        db.rollback()
        raise HTTPException(400, "Select an active category belonging to this business.")
    if body.brand_id:
        brand = db.scalar(select(Brand).where(
            Brand.id == body.brand_id,
            Brand.tenant_id == tenant_id,
            Brand.deleted_at.is_(None),
            Brand.status == "ACTIVE",
        ))
        if not brand:
            db.rollback()
            raise HTTPException(400, "Select an active brand belonging to this business.")
    unit = db.scalar(select(Unit).where(
        Unit.id == body.base_unit_id,
        (Unit.tenant_id == tenant_id) | (Unit.tenant_id.is_(None)),
    ))
    if not unit:
        db.rollback()
        raise HTTPException(400, "Select a valid unit of measure.")
    if body.allow_fractional_quantity and not unit.allows_fraction:
        db.rollback()
        raise HTTPException(422, "This unit does not support fractional quantities.")

    price_list = None
    if body.price_list_id:
        price_list = db.scalar(select(PriceList).where(
            PriceList.id == body.price_list_id,
            PriceList.tenant_id == tenant_id,
            PriceList.status == "ACTIVE",
        ))
        if not price_list:
            db.rollback()
            raise HTTPException(400, "Select an active price list belonging to this business.")

    try:
        product_name = normalize_text(body.product_name, "Product name")
        product_description = (
            normalize_text(body.description, "Description")
            if body.description and body.description.strip()
            else None
        )
        variant_name = normalize_text(body.variant_name, "Variant name")
        sku = normalize_code(body.sku, "SKU")
        product_type = normalize_code(body.product_type, "Product type")
        costing_method = normalize_code(body.costing_method, "Costing method")
        barcode_value = body.barcode.strip() if body.barcode else None
        barcode_type = normalize_code(body.barcode_type, "Barcode type")
        if barcode_value is not None and not barcode_value:
            barcode_value = None
        if barcode_value and db.scalar(select(Barcode.id).where(
            Barcode.tenant_id == tenant_id,
            Barcode.barcode == barcode_value,
            Barcode.status == "ACTIVE",
        )):
            db.rollback()
            raise HTTPException(409, "This barcode is already assigned to an active item.")
        if db.scalar(select(ProductVariant.id).where(
            ProductVariant.tenant_id == tenant_id,
            ProductVariant.sku == sku,
            ProductVariant.deleted_at.is_(None),
        )):
            db.rollback()
            raise HTTPException(409, "This product code already exists. Choose a unique SKU.")
        price_value = validate_price(body.unit_price) if body.unit_price is not None else None
        minimum_quantity = validate_minimum_quantity(body.minimum_quantity) if price_value is not None else None
    except CatalogValidation as exc:
        db.rollback()
        raise HTTPException(422, str(exc)) from exc

    try:
        product = Product(
            tenant_id=tenant_id,
            category_id=body.category_id,
            brand_id=body.brand_id,
            name=product_name,
            description=product_description,
            product_type=product_type,
            has_variants=True,
            tax_category_id=body.tax_category_id,
            product_metadata=body.product_metadata,
        )
        db.add(product)
        db.flush()
        write_audit(db, tenant_id=tenant_id, actor_user_id=actor, action="catalog.product.created", target_type="product", target_id=product.id)
        emit_event(
            db, tenant_id=tenant_id, event_type="ProductCreated", aggregate_type="product",
            aggregate_id=product.id, actor_user_id=actor,
            payload={"id": str(product.id), "name": product_name, "category_id": str(body.category_id),
                     "brand_id": str(body.brand_id) if body.brand_id else None, "setup_method": "QUICK_SETUP"},
        )

        variant = ProductVariant(
            tenant_id=tenant_id, product_id=product.id, name=variant_name, sku=sku,
            base_unit_id=body.base_unit_id, track_inventory=body.track_inventory,
            allow_fractional_quantity=body.allow_fractional_quantity,
            costing_method=costing_method, variant_metadata=body.variant_metadata,
        )
        db.add(variant)
        db.flush()
        write_audit(db, tenant_id=tenant_id, actor_user_id=actor, action="catalog.variant.created", target_type="product_variant", target_id=variant.id)
        emit_event(
            db, tenant_id=tenant_id, event_type="ProductVariantCreated", aggregate_type="product_variant",
            aggregate_id=variant.id, actor_user_id=actor,
            payload={"id": str(variant.id), "product_id": str(product.id), "sku": sku, "name": variant_name},
        )

        barcode_row = None
        if barcode_value:
            barcode_row = Barcode(
                tenant_id=tenant_id, variant_id=variant.id, barcode=barcode_value,
                barcode_type=barcode_type, is_primary=True, status="ACTIVE",
            )
            db.add(barcode_row)
            db.flush()
            write_audit(db, tenant_id=tenant_id, actor_user_id=actor, action="catalog.barcode.created", target_type="barcode", target_id=barcode_row.id)
            emit_event(
                db, tenant_id=tenant_id, event_type="BarcodeCreated", aggregate_type="barcode",
                aggregate_id=barcode_row.id, actor_user_id=actor,
                payload={"id": str(barcode_row.id), "variant_id": str(variant.id), "barcode_type": barcode_type},
            )

        price_row = None
        if price_value is not None and price_list is not None and minimum_quantity is not None:
            price_row = ProductPrice(
                tenant_id=tenant_id, price_list_id=price_list.id, variant_id=variant.id,
                unit_price=price_value, minimum_quantity=minimum_quantity,
                effective_from=body.effective_from or utc_now(),
            )
            db.add(price_row)
            db.flush()
            write_audit(db, tenant_id=tenant_id, actor_user_id=actor, action="catalog.price.created", target_type="product_price", target_id=price_row.id)
            emit_event(
                db, tenant_id=tenant_id, event_type="ProductPriceCreated", aggregate_type="product_price",
                aggregate_id=price_row.id, actor_user_id=actor,
                payload={"id": str(price_row.id), "variant_id": str(variant.id), "price_list_id": str(price_list.id)},
            )

        response_body = {
            "product": ProductOut.model_validate(product).model_dump(mode="json"),
            "variant": VariantOut.model_validate(variant).model_dump(mode="json"),
            "barcode": BarcodeOut.model_validate(barcode_row).model_dump(mode="json") if barcode_row else None,
            "price": ProductPriceOut.model_validate(price_row).model_dump(mode="json") if price_row else None,
            "opening_stock_created": False,
            "next_step": "Record opening stock via an approved inventory adjustment or goods receipt.",
        }
        finish_idempotency(
            db, idem, status_code=201, response_body=response_body,
            resource_type="product", resource_id=product.id,
        )
        db.commit()
        return JSONResponse(status_code=201, content=response_body)
    except HTTPException:
        db.rollback()
        raise
    except IntegrityError as exc:
        db.rollback()
        raise HTTPException(409, "The product setup conflicted with an existing code or record. Check SKU/barcode uniqueness and try again.") from exc
    except Exception:
        db.rollback()
        raise




@router.post("/products/full-setup", response_model=ProductFullSetupOut, status_code=201)
def create_product_full_setup(
    body: ProductFullSetupIn,
    idempotency_key: str | None = Header(None, alias="Idempotency-Key"),
    ctx=Depends(require_permission("catalog.manage")),
):
    """Atomically create a product, its sellable variants, attributes, barcodes and prices.

    The database transaction contains the complete catalogue setup. Opening stock is
    intentionally excluded and must be entered through Inventory.
    """
    db, actor, tenant_id, _ = ctx
    try:
        idem, replay = begin_idempotency(
            db, tenant_id=tenant_id, operation_type="catalog.product.full_setup",
            key=idempotency_key, payload=body.model_dump(mode="json"),
        )
    except CatalogValidation as exc:
        db.rollback()
        raise HTTPException(409 if "different" in str(exc) else 422, str(exc)) from exc
    if replay:
        return JSONResponse(status_code=replay[0], content=replay[1])

    try:
        if body.tax_category_id is not None:
            raise HTTPException(
                422,
                "Tax category assignment is not available in Product Setup because this catalogue has no tenant-safe tax-category lookup. Configure tax rules in Finance instead.",
            )
        category = db.scalar(select(Category).where(
            Category.id == body.category_id, Category.tenant_id == tenant_id,
            Category.deleted_at.is_(None), Category.status == "ACTIVE",
        ))
        if not category:
            raise HTTPException(400, "Select an active category belonging to this business.")
        if body.brand_id:
            brand = db.scalar(select(Brand).where(
                Brand.id == body.brand_id, Brand.tenant_id == tenant_id,
                Brand.deleted_at.is_(None), Brand.status == "ACTIVE",
            ))
            if not brand:
                raise HTTPException(400, "Select an active brand belonging to this business.")

        product_name = normalize_text(body.product_name, "Product name")
        description = normalize_text(body.description, "Description") if body.description and body.description.strip() else None
        image_url = body.image_url.strip() if body.image_url else None
        if image_url:
            try:
                parsed_image_url = urlsplit(image_url)
                _ = parsed_image_url.port
            except ValueError as exc:
                raise HTTPException(422, "Product image URL is invalid.") from exc
            if (parsed_image_url.scheme.lower() != "https" or not parsed_image_url.hostname
                    or parsed_image_url.username is not None or parsed_image_url.password is not None):
                raise HTTPException(422, "Product image URL must be a valid HTTPS URL without embedded credentials.")
        product_metadata = dict(body.product_metadata)
        # Avoid bypassing the dedicated URL validation with a raw metadata key.
        product_metadata.pop("image_url", None)
        if image_url:
            product_metadata["image_url"] = image_url
        product_type = normalize_code(body.product_type, "Product type")
        allowed_product_types = {"STOCKED", "SERVICE"}
        if product_type not in allowed_product_types:
            raise HTTPException(422, "Product type must be STOCKED or SERVICE.")
        product_status = normalize_code(body.status, "Product status")
        if product_status not in {"ACTIVE", "INACTIVE"}:
            raise HTTPException(422, "Product status must be ACTIVE or INACTIVE. Drafts are not supported by this endpoint.")
        effective_from = body.effective_from or utc_now()
        if effective_from.tzinfo is None:
            effective_from = effective_from.replace(tzinfo=timezone.utc)
        else:
            effective_from = effective_from.astimezone(timezone.utc)
        if product_type == "SERVICE" and any(v.track_inventory or v.allow_fractional_quantity for v in body.variants):
            raise HTTPException(422, "Service variants cannot use inventory or quantity-fraction tracking.")

        normalized_skus: list[str] = []
        normalized_barcodes: list[str] = []
        definitions_by_id: dict[UUID, ProductAttributeDefinition] = {}
        price_lists_by_id: dict[UUID, PriceList] = {}
        for raw in body.variants:
            sku = normalize_code(raw.sku, "SKU")
            normalized_skus.append(sku)
            if raw.costing_method != "WEIGHTED_AVERAGE":
                raise HTTPException(422, "Only weighted-average costing is currently supported by Product Setup.")
            unit = db.scalar(select(Unit).where(
                Unit.id == raw.base_unit_id,
                or_(Unit.tenant_id == tenant_id, Unit.tenant_id.is_(None)),
            ))
            if not unit:
                raise HTTPException(400, "A variant uses a unit of measure outside this business.")
            if raw.allow_fractional_quantity and (not unit.allows_fraction or unit.precision_scale < 1):
                raise HTTPException(422, f"Unit {unit.name} does not support fractional quantities.")
            price_list = db.scalar(select(PriceList).where(
                PriceList.id == raw.price_list_id, PriceList.tenant_id == tenant_id,
                PriceList.status == "ACTIVE",
                PriceList.effective_from <= effective_from,
                or_(PriceList.effective_to.is_(None), PriceList.effective_to > effective_from),
            ))
            if not price_list:
                raise HTTPException(400, "Every saleable variant must use an active price list for the selected effective date and belonging to this business.")
            price_lists_by_id[raw.price_list_id] = price_list
            if not raw.unit_price.is_finite():
                raise HTTPException(422, "Selling price must be a finite number.")
            if not raw.minimum_quantity.is_finite():
                raise HTTPException(422, "Minimum quantity must be a finite number greater than zero.")
            try:
                validate_price(raw.unit_price)
                validate_minimum_quantity(raw.minimum_quantity)
            except CatalogValidation as exc:
                raise HTTPException(422, str(exc)) from exc
            if raw.barcode and raw.barcode.strip():
                normalized_barcodes.append(raw.barcode.strip())
            for definition_raw_id in raw.attributes.keys():
                try:
                    definition_id = UUID(str(definition_raw_id))
                except ValueError as exc:
                    raise HTTPException(422, "A variant attribute reference is invalid.") from exc
                if definition_id not in definitions_by_id:
                    definition = db.scalar(select(ProductAttributeDefinition).where(
                        ProductAttributeDefinition.id == definition_id,
                        ProductAttributeDefinition.tenant_id == tenant_id,
                        or_(ProductAttributeDefinition.category_id == body.category_id,
                            ProductAttributeDefinition.category_id.is_(None)),
                    ))
                    if not definition:
                        raise HTTPException(400, "A variant attribute is not available for this category or tenant.")
                    definitions_by_id[definition_id] = definition

        if body.combination_attribute_ids:
            if len(set(body.combination_attribute_ids)) != len(body.combination_attribute_ids):
                raise HTTPException(422, "Combination attribute dimensions must be unique.")
            for dimension_id in body.combination_attribute_ids:
                definition = definitions_by_id.get(dimension_id)
                if not definition or definition.data_type != "SELECT":
                    raise HTTPException(422, "Generated combinations can only use configured single-select attributes.")
            seen_combinations: set[str] = set()
            for index, raw in enumerate(body.variants, 1):
                combo = {str(attr_id): raw.attributes.get(str(attr_id)) for attr_id in body.combination_attribute_ids}
                if any(value is None or value == "" for value in combo.values()):
                    raise HTTPException(422, f"Variant {index} is missing a generated combination value.")
                combo_key = json.dumps(combo, sort_keys=True, separators=(",", ":"), default=str)
                if combo_key in seen_combinations:
                    raise HTTPException(409, "Duplicate attribute combinations are not allowed.")
                seen_combinations.add(combo_key)

        if len(set(s.upper() for s in normalized_skus)) != len(normalized_skus):
            raise HTTPException(409, "Two variants in this setup have the same SKU.")
        if len(set(normalized_barcodes)) != len(normalized_barcodes):
            raise HTTPException(409, "Two variants in this setup have the same barcode.")
        existing_skus = set(db.scalars(select(ProductVariant.sku).where(
            ProductVariant.tenant_id == tenant_id,
            ProductVariant.sku.in_(normalized_skus),
            ProductVariant.deleted_at.is_(None),
        )))
        if existing_skus:
            raise HTTPException(409, "SKU already exists: " + ", ".join(sorted(existing_skus)))
        existing_barcodes = set(db.scalars(select(Barcode.barcode).where(
            Barcode.tenant_id == tenant_id, Barcode.status == "ACTIVE",
            Barcode.barcode.in_(normalized_barcodes) if normalized_barcodes else False,
        )))
        if existing_barcodes:
            raise HTTPException(409, "Barcode already assigned: " + ", ".join(sorted(existing_barcodes)))

        # Every required category attribute must be present for every variant.
        required_definitions = list(db.scalars(select(ProductAttributeDefinition).where(
            ProductAttributeDefinition.tenant_id == tenant_id,
            ProductAttributeDefinition.required.is_(True),
            or_(ProductAttributeDefinition.category_id == body.category_id,
                ProductAttributeDefinition.category_id.is_(None)),
        )))
        for index, raw in enumerate(body.variants, 1):
            missing = [d.name for d in required_definitions if str(d.id) not in raw.attributes and d.id not in raw.attributes]
            if missing:
                raise HTTPException(422, f"Variant {index} is missing required attributes: {', '.join(missing)}.")
            for definition_id_raw, value in raw.attributes.items():
                try:
                    definition_id = UUID(str(definition_id_raw))
                except ValueError as exc:
                    raise HTTPException(422, "A variant attribute reference is invalid.") from exc
                definition = definitions_by_id.get(definition_id)
                if not definition:
                    raise HTTPException(400, "A variant attribute is not available for this category or tenant.")
                if value is None or value == "":
                    raise HTTPException(422, f"Attribute {definition.name} cannot be empty.")
                if definition.data_type in {"TEXT", "SELECT"}:
                    if not isinstance(value, str):
                        raise HTTPException(422, f"Attribute {definition.name} must be text.")
                    if definition.data_type == "SELECT":
                        choices = (definition.options or {}).get("choices", [])
                        if not choices or value not in choices:
                            raise HTTPException(422, f"Attribute {definition.name} has an unsupported choice or no configured choices.")
                elif definition.data_type == "NUMBER":
                    try:
                        numeric_value = Decimal(str(value))
                    except Exception as exc:
                        raise HTTPException(422, f"Attribute {definition.name} must be numeric.") from exc
                    if not numeric_value.is_finite():
                        raise HTTPException(422, f"Attribute {definition.name} must be a finite number.")
                elif definition.data_type == "BOOLEAN":
                    if not isinstance(value, bool):
                        raise HTTPException(422, f"Attribute {definition.name} must be true or false.")
                elif definition.data_type == "MULTI_SELECT":
                    if not isinstance(value, list) or any(not isinstance(item, str) for item in value):
                        raise HTTPException(422, f"Attribute {definition.name} must be a list of text choices.")
                    choices = set((definition.options or {}).get("choices", []))
                    if choices and not set(value).issubset(choices):
                        raise HTTPException(422, f"Attribute {definition.name} contains unsupported choices.")
                elif definition.data_type == "DATE":
                    try:
                        datetime.fromisoformat(str(value))
                    except ValueError as exc:
                        raise HTTPException(422, f"Attribute {definition.name} must be a date.") from exc
                else:
                    raise HTTPException(422, f"Attribute {definition.name} uses an unsupported data type.")

        product = Product(
            tenant_id=tenant_id, category_id=body.category_id, brand_id=body.brand_id,
            name=product_name, description=description, product_type=product_type,
            status=product_status, has_variants=len(body.variants) > 1, tax_category_id=body.tax_category_id,
            product_metadata=product_metadata,
        )
        db.add(product)
        db.flush()
        write_audit(db, tenant_id=tenant_id, actor_user_id=actor, action="catalog.product.created", target_type="product", target_id=product.id)
        emit_event(db, tenant_id=tenant_id, event_type="ProductCreated", aggregate_type="product", aggregate_id=product.id,
                   actor_user_id=actor, payload={"id": str(product.id), "name": product_name, "category_id": str(body.category_id), "setup_method": "FULL_SETUP"})

        variants_out: list[ProductVariant] = []
        barcodes_out: list[Barcode] = []
        prices_out: list[ProductPrice] = []
        for raw in body.variants:
            variant_name = normalize_text(raw.name, "Variant name")
            sku = normalize_code(raw.sku, "SKU")
            variant = ProductVariant(
                tenant_id=tenant_id, product_id=product.id, name=variant_name, sku=sku,
                base_unit_id=raw.base_unit_id, track_inventory=raw.track_inventory,
                allow_fractional_quantity=raw.allow_fractional_quantity,
                status="ACTIVE", costing_method=raw.costing_method,
                variant_metadata={"manufacturer_part_number": normalize_text(raw.manufacturer_part_number, "Manufacturer part number") if raw.manufacturer_part_number and raw.manufacturer_part_number.strip() else None},
            )
            db.add(variant)
            db.flush()
            variants_out.append(variant)
            write_audit(db, tenant_id=tenant_id, actor_user_id=actor, action="catalog.variant.created", target_type="product_variant", target_id=variant.id)
            emit_event(db, tenant_id=tenant_id, event_type="ProductVariantCreated", aggregate_type="product_variant", aggregate_id=variant.id,
                       actor_user_id=actor, payload={"id": str(variant.id), "product_id": str(product.id), "sku": sku})

            barcode_value = raw.barcode.strip() if raw.barcode else ""
            if barcode_value:
                barcode_row = Barcode(tenant_id=tenant_id, variant_id=variant.id, barcode=barcode_value,
                                      barcode_type=normalize_code(raw.barcode_type, "Barcode type"), is_primary=True, status="ACTIVE")
                db.add(barcode_row)
                db.flush()
                barcodes_out.append(barcode_row)
                write_audit(db, tenant_id=tenant_id, actor_user_id=actor, action="catalog.barcode.created", target_type="barcode", target_id=barcode_row.id)
                emit_event(db, tenant_id=tenant_id, event_type="BarcodeCreated", aggregate_type="barcode", aggregate_id=barcode_row.id,
                           actor_user_id=actor, payload={"id": str(barcode_row.id), "variant_id": str(variant.id), "barcode_type": barcode_row.barcode_type})

            price_row = ProductPrice(
                tenant_id=tenant_id, price_list_id=raw.price_list_id, variant_id=variant.id,
                unit_price=validate_price(raw.unit_price), minimum_quantity=validate_minimum_quantity(raw.minimum_quantity),
                effective_from=effective_from,
                effective_to=price_lists_by_id[raw.price_list_id].effective_to,
            )
            db.add(price_row)
            db.flush()
            prices_out.append(price_row)
            write_audit(db, tenant_id=tenant_id, actor_user_id=actor, action="catalog.price.created", target_type="product_price", target_id=price_row.id)
            emit_event(db, tenant_id=tenant_id, event_type="ProductPriceCreated", aggregate_type="product_price", aggregate_id=price_row.id,
                       actor_user_id=actor, payload={"id": str(price_row.id), "variant_id": str(variant.id), "price_list_id": str(raw.price_list_id)})

            for definition_id_raw, value in raw.attributes.items():
                definition = definitions_by_id[UUID(str(definition_id_raw))]
                value_text = value_number = value_boolean = value_date = value_json = None
                if definition.data_type in {"TEXT", "SELECT"}:
                    value_text = normalize_text(value, f"Attribute {definition.name}") if definition.data_type == "TEXT" else value
                elif definition.data_type == "NUMBER":
                    value_number = Decimal(str(value))
                elif definition.data_type == "BOOLEAN": value_boolean = value
                elif definition.data_type == "DATE":
                    value_date = datetime.fromisoformat(str(value))
                    if value_date.tzinfo is None:
                        value_date = value_date.replace(tzinfo=timezone.utc)
                    else:
                        value_date = value_date.astimezone(timezone.utc)
                elif definition.data_type == "MULTI_SELECT": value_json = value
                else: raise HTTPException(422, f"Unsupported attribute data type for {definition.name}.")
                attribute_row = ProductAttributeValue(
                    tenant_id=tenant_id, variant_id=variant.id, attribute_definition_id=definition.id,
                    value_text=value_text, value_number=value_number, value_boolean=value_boolean,
                    value_date=value_date, value_json=value_json,
                )
                db.add(attribute_row)
                db.flush()
                write_audit(db, tenant_id=tenant_id, actor_user_id=actor, action="catalog.attribute_value.created", target_type="product_attribute_value", target_id=attribute_row.id)

        response_body = {
            "product": ProductOut.model_validate(product).model_dump(mode="json"),
            "variants": [VariantOut.model_validate(v).model_dump(mode="json") for v in variants_out],
            "barcodes": [BarcodeOut.model_validate(b).model_dump(mode="json") for b in barcodes_out],
            "prices": [ProductPriceOut.model_validate(p).model_dump(mode="json") for p in prices_out],
            "opening_stock_created": False,
            "next_step": "Record opening stock separately through Inventory.",
        }
        finish_idempotency(db, idem, status_code=201, response_body=response_body, resource_type="product", resource_id=product.id)
        db.commit()
        return JSONResponse(status_code=201, content=response_body)
    except HTTPException:
        db.rollback()
        raise
    except CatalogValidation as exc:
        db.rollback()
        raise HTTPException(422, str(exc)) from exc
    except IntegrityError as exc:
        db.rollback()
        raise HTTPException(409, "Product setup conflicts with an existing SKU, barcode or price record.") from exc
    except Exception:
        db.rollback()
        raise


@router.patch("/products/{product_id}", response_model=ProductOut)
def patch_product(product_id: UUID, body: ProductPatch, ctx=Depends(require_permission("catalog.manage"))):
    db, actor, tenant_id, _ = ctx; row = db.scalar(select(Product).where(Product.id == product_id, Product.tenant_id == tenant_id, Product.deleted_at.is_(None)))
    if not row: raise HTTPException(404, "Product not found")
    if body.category_id is not None and not db.scalar(select(Category.id).where(Category.id == body.category_id, Category.tenant_id == tenant_id, Category.deleted_at.is_(None))): raise HTTPException(400, "Category does not belong to tenant")
    if body.brand_id is not None and not db.scalar(select(Brand.id).where(Brand.id == body.brand_id, Brand.tenant_id == tenant_id, Brand.deleted_at.is_(None))): raise HTTPException(400, "Brand does not belong to tenant")
    try:
        if body.name is not None: row.name = normalize_text(body.name, "Product name")
        for attr in ("category_id", "brand_id", "description", "status", "has_variants", "tax_category_id"):
            value = getattr(body, attr)
            if value is not None: setattr(row, attr, value)
        if body.metadata is not None:
            row.product_metadata = body.metadata
        # metadata is a public API field; product_metadata is the ORM-safe attribute.
    except CatalogValidation as exc: raise HTTPException(422, str(exc)) from exc
    db.flush(); write_audit(db, tenant_id=tenant_id, actor_user_id=actor, action="catalog.product.updated", target_type="product", target_id=row.id); emit_event(db, tenant_id=tenant_id, event_type="ProductUpdated", aggregate_type="product", aggregate_id=row.id, actor_user_id=actor, payload={"id": str(row.id), "status": row.status}); db.commit(); return row

@router.delete("/products/{product_id}", response_model=ProductOut)
def delete_product(product_id: UUID, ctx=Depends(require_permission("catalog.manage"))):
    db, actor, tenant_id, _ = ctx; row = db.scalar(select(Product).where(Product.id == product_id, Product.tenant_id == tenant_id, Product.deleted_at.is_(None)))
    if not row: raise HTTPException(404, "Product not found")
    row.deleted_at = utc_now(); row.deleted_by = actor; row.status = "INACTIVE"; db.flush(); write_audit(db, tenant_id=tenant_id, actor_user_id=actor, action="catalog.product.deleted", target_type="product", target_id=row.id); emit_event(db, tenant_id=tenant_id, event_type="ProductDeleted", aggregate_type="product", aggregate_id=row.id, actor_user_id=actor, payload={"id": str(row.id)}); db.commit(); return row

@router.get("/products/{product_id}", response_model=ProductOut)
def get_product(product_id: UUID, ctx=Depends(require_permission("catalog.read"))):
    db, _, tenant_id, _ = ctx
    row = db.scalar(select(Product).where(Product.id == product_id, Product.tenant_id == tenant_id, Product.deleted_at.is_(None)))
    if not row: raise HTTPException(404, "Product not found")
    return row

@router.get("/products/{product_id}/variants", response_model=list[VariantOut])
def product_variants(product_id: UUID, ctx=Depends(require_permission("catalog.read"))):
    db, _, tenant_id, _ = ctx
    if not db.scalar(select(Product.id).where(Product.id == product_id, Product.tenant_id == tenant_id, Product.deleted_at.is_(None))): raise HTTPException(404, "Product not found")
    return list(db.scalars(select(ProductVariant).where(ProductVariant.product_id == product_id, ProductVariant.tenant_id == tenant_id, ProductVariant.deleted_at.is_(None)).order_by(ProductVariant.id)))

@router.post("/variants", response_model=VariantOut, status_code=201)
def create_variant(body: VariantIn, idempotency_key: str | None = Header(None, alias="Idempotency-Key"), ctx=Depends(require_permission("catalog.manage"))):
    db, actor, tenant_id, _ = ctx
    try:
        idem, replay = begin_idempotency(db, tenant_id=tenant_id, operation_type="catalog.variant.create", key=idempotency_key, payload=body.model_dump(mode="json"))
    except CatalogValidation as exc:
        db.rollback(); raise HTTPException(409 if "different" in str(exc) else 422, str(exc)) from exc
    if replay:
        return JSONResponse(status_code=replay[0], content=replay[1])
    if not db.scalar(select(Product.id).where(Product.id == body.product_id, Product.tenant_id == tenant_id, Product.deleted_at.is_(None))): raise HTTPException(400, "Product does not belong to tenant")
    unit = db.scalar(select(Unit).where(Unit.id == body.base_unit_id, (Unit.tenant_id == tenant_id) | (Unit.tenant_id.is_(None))))
    if not unit: raise HTTPException(400, "Unit does not belong to tenant")
    try: name = normalize_text(body.name, "Variant name"); sku = normalize_code(body.sku, "SKU")
    except CatalogValidation as exc: db.rollback(); raise HTTPException(422, str(exc)) from exc
    if body.allow_fractional_quantity and not unit.allows_fraction: db.rollback(); raise HTTPException(422, "Variant cannot allow fractional quantity with a non-fractional base unit")
    row = ProductVariant(tenant_id=tenant_id, product_id=body.product_id, name=name, sku=sku, base_unit_id=body.base_unit_id, track_inventory=body.track_inventory, allow_fractional_quantity=body.allow_fractional_quantity, costing_method=body.costing_method, variant_metadata=body.metadata); db.add(row); db.flush(); write_audit(db, tenant_id=tenant_id, actor_user_id=actor, action="catalog.variant.created", target_type="product_variant", target_id=row.id); emit_event(db, tenant_id=tenant_id, event_type="ProductVariantCreated", aggregate_type="product_variant", aggregate_id=row.id, actor_user_id=actor, payload={"id": str(row.id), "product_id": str(body.product_id), "sku": sku});
    finish_idempotency(db, idem, status_code=201, response_body=VariantOut.model_validate(row).model_dump(mode="json"), resource_type="product_variant", resource_id=row.id)
    commit_or_409(db, "SKU already exists for this tenant"); return row

@router.patch("/variants/{variant_id}", response_model=VariantOut)
def patch_variant(variant_id: UUID, body: VariantPatch, idempotency_key: str | None = Header(None, alias="Idempotency-Key"), ctx=Depends(require_permission("catalog.manage"))):
    db, actor, tenant_id, _ = ctx; row = db.scalar(select(ProductVariant).where(ProductVariant.id == variant_id, ProductVariant.tenant_id == tenant_id, ProductVariant.deleted_at.is_(None)))
    if not row: raise HTTPException(404, "Variant not found")
    try:
        idem, replay = begin_idempotency(db, tenant_id=tenant_id, operation_type="catalog.variant.update", key=idempotency_key, payload=body.model_dump(mode="json") | {"variant_id": str(variant_id)})
    except CatalogValidation as exc:
        db.rollback(); raise HTTPException(409 if "different" in str(exc) else 422, str(exc)) from exc
    if replay:
        return JSONResponse(status_code=replay[0], content=replay[1])
    if body.base_unit_id is not None:
        unit = db.scalar(select(Unit).where(Unit.id == body.base_unit_id, (Unit.tenant_id == tenant_id) | (Unit.tenant_id.is_(None))))
        if not unit: raise HTTPException(400, "Unit does not belong to tenant")
        if row.allow_fractional_quantity and not unit.allows_fraction: raise HTTPException(422, "Variant cannot use a non-fractional base unit")
    try:
        if body.name is not None: row.name = normalize_text(body.name, "Variant name")
        for attr in ("base_unit_id", "track_inventory", "allow_fractional_quantity", "status", "costing_method"):
            value = getattr(body, attr)
            if value is not None: setattr(row, attr, value)
        if body.metadata is not None:
            row.variant_metadata = body.metadata
        # metadata is a public API field; variant_metadata is the ORM-safe attribute.
        unit2 = db.scalar(select(Unit).where(Unit.id == row.base_unit_id, (Unit.tenant_id == tenant_id) | (Unit.tenant_id.is_(None))))
        if row.allow_fractional_quantity and (not unit2 or not unit2.allows_fraction): raise CatalogValidation("Variant cannot allow fractional quantity with a non-fractional base unit")
    except CatalogValidation as exc: raise HTTPException(422, str(exc)) from exc
    db.flush(); write_audit(db, tenant_id=tenant_id, actor_user_id=actor, action="catalog.variant.updated", target_type="product_variant", target_id=row.id); emit_event(db, tenant_id=tenant_id, event_type="ProductVariantUpdated", aggregate_type="product_variant", aggregate_id=row.id, actor_user_id=actor, payload={"id": str(row.id), "sku": row.sku, "status": row.status})
    response_body = VariantOut.model_validate(row).model_dump(mode="json")
    finish_idempotency(db, idem, status_code=200, response_body=response_body, resource_type="product_variant", resource_id=row.id)
    commit_or_409(db, "Variant update conflicts with existing data"); return row

@router.get("/variants/{variant_id}", response_model=VariantOut)
def get_variant(variant_id: UUID, ctx=Depends(require_permission("catalog.read"))):
    db, _, tenant_id, _ = ctx
    row = db.scalar(select(ProductVariant).where(ProductVariant.id == variant_id, ProductVariant.tenant_id == tenant_id, ProductVariant.deleted_at.is_(None)))
    if not row: raise HTTPException(404, "Variant not found")
    return row

@router.get("/skus/{sku}", response_model=VariantOut)
def lookup_sku(sku: str, ctx=Depends(require_permission("catalog.read"))):
    db, _, tenant_id, _ = ctx
    value = sku.strip().upper()
    row = db.scalar(select(ProductVariant).where(ProductVariant.tenant_id == tenant_id, ProductVariant.sku == value, ProductVariant.status == "ACTIVE", ProductVariant.deleted_at.is_(None)))
    if not row: raise HTTPException(404, "SKU not found")
    return row

@router.get("/barcodes", response_model=list[BarcodeOut])
def list_barcodes(variant_id: UUID | None = None, ctx=Depends(require_permission("catalog.read"))):
    db, _, tenant_id, _ = ctx
    stmt = select(Barcode).where(Barcode.tenant_id == tenant_id, Barcode.status == "ACTIVE")
    if variant_id:
        stmt = stmt.where(Barcode.variant_id == variant_id)
    return list(db.scalars(stmt.order_by(Barcode.is_primary.desc(), Barcode.barcode)))

@router.get("/barcodes/{barcode}", response_model=BarcodeOut)
def lookup_barcode(barcode: str, ctx=Depends(require_permission("catalog.read"))):
    db, _, tenant_id, _ = ctx; value = barcode.strip()
    row = db.scalar(select(Barcode).where(Barcode.tenant_id == tenant_id, Barcode.barcode == value, Barcode.status == "ACTIVE").limit(1))
    if not row: raise HTTPException(404, "Barcode not found")
    return row

@router.post("/barcodes", response_model=BarcodeOut, status_code=201)
def create_barcode(body: BarcodeIn, idempotency_key: str | None = Header(None, alias="Idempotency-Key"), ctx=Depends(require_permission("catalog.manage"))):
    db, actor, tenant_id, _ = ctx
    try:
        idem, replay = begin_idempotency(db, tenant_id=tenant_id, operation_type="catalog.barcode.create", key=idempotency_key, payload=body.model_dump(mode="json"))
    except CatalogValidation as exc:
        db.rollback(); raise HTTPException(409 if "different" in str(exc) else 422, str(exc)) from exc
    if replay:
        return JSONResponse(status_code=replay[0], content=replay[1])
    barcode = body.barcode.strip()
    if not barcode: raise HTTPException(422, "Barcode cannot be empty")
    variant = db.scalar(select(ProductVariant).where(ProductVariant.id == body.variant_id, ProductVariant.tenant_id == tenant_id, ProductVariant.deleted_at.is_(None), ProductVariant.status == "ACTIVE"))
    if not variant: raise HTTPException(400, "Variant does not belong to tenant or is inactive")
    row = Barcode(tenant_id=tenant_id, variant_id=body.variant_id, barcode=barcode, barcode_type=normalize_code(body.barcode_type, "Barcode type"), is_primary=body.is_primary); db.add(row); db.flush()
    if body.is_primary: db.query(Barcode).filter(Barcode.variant_id == body.variant_id, Barcode.tenant_id == tenant_id, Barcode.id != row.id).update({Barcode.is_primary: False}, synchronize_session=False)
    write_audit(db, tenant_id=tenant_id, actor_user_id=actor, action="catalog.barcode.created", target_type="barcode", target_id=row.id); emit_event(db, tenant_id=tenant_id, event_type="BarcodeCreated", aggregate_type="barcode", aggregate_id=row.id, actor_user_id=actor, payload={"id": str(row.id), "variant_id": str(body.variant_id), "barcode": barcode})
    response_body = BarcodeOut.model_validate(row).model_dump(mode="json")
    finish_idempotency(db, idem, status_code=201, response_body=response_body, resource_type="barcode", resource_id=row.id)
    commit_or_409(db, "Barcode already belongs to another active catalog identity"); return row

@router.get("/attribute-definitions", response_model=list[AttributeDefinitionOut])
def attribute_definitions(ctx=Depends(require_permission("catalog.read"))):
    db, _, tenant_id, _ = ctx
    return list(db.scalars(select(ProductAttributeDefinition).where(ProductAttributeDefinition.tenant_id == tenant_id).order_by(ProductAttributeDefinition.code)))

@router.get("/attribute-values/{variant_id}", response_model=list[AttributeValueOut])
def attribute_values(variant_id: UUID, ctx=Depends(require_permission("catalog.read"))):
    db, _, tenant_id, _ = ctx
    if not db.scalar(select(ProductVariant.id).where(ProductVariant.id == variant_id, ProductVariant.tenant_id == tenant_id, ProductVariant.deleted_at.is_(None))): raise HTTPException(404, "Variant not found")
    return list(db.scalars(select(ProductAttributeValue).where(ProductAttributeValue.tenant_id == tenant_id, ProductAttributeValue.variant_id == variant_id).order_by(ProductAttributeValue.attribute_definition_id)))

@router.post("/attribute-definitions", response_model=AttributeDefinitionOut, status_code=201)
def create_attribute_definition(body: AttributeDefinitionIn, ctx=Depends(require_permission("catalog.manage"))):
    db, actor, tenant_id, _ = ctx
    if body.category_id and not db.scalar(select(Category.id).where(Category.id == body.category_id, Category.tenant_id == tenant_id, Category.deleted_at.is_(None))): raise HTTPException(400, "Category does not belong to tenant")
    data_type = normalize_code(body.data_type, "Attribute data type")
    allowed = {"TEXT","NUMBER","BOOLEAN","DATE","SELECT","MULTI_SELECT"}
    if data_type not in allowed: raise HTTPException(422, f"Unsupported attribute data type: {data_type}")
    row = ProductAttributeDefinition(tenant_id=tenant_id, category_id=body.category_id, name=normalize_text(body.name,"Attribute name"), code=normalize_code(body.code,"Attribute code"), data_type=data_type, required=body.required, options=body.options); db.add(row); db.flush(); write_audit(db, tenant_id=tenant_id, actor_user_id=actor, action="catalog.attribute_definition.created", target_type="product_attribute_definition", target_id=row.id); emit_event(db, tenant_id=tenant_id, event_type="ProductAttributeDefinitionCreated", aggregate_type="product_attribute_definition", aggregate_id=row.id, actor_user_id=actor, payload={"id": str(row.id), "code": row.code}); commit_or_409(db, "Attribute definition code already exists for this tenant"); return row

@router.post("/attribute-values", response_model=AttributeValueOut, status_code=201)
def create_attribute_value(body: AttributeValueIn, ctx=Depends(require_permission("catalog.manage"))):
    db, actor, tenant_id, _ = ctx
    variant = db.scalar(select(ProductVariant).where(ProductVariant.id == body.variant_id, ProductVariant.tenant_id == tenant_id, ProductVariant.deleted_at.is_(None)))
    definition = db.scalar(select(ProductAttributeDefinition).where(ProductAttributeDefinition.id == body.attribute_definition_id, ProductAttributeDefinition.tenant_id == tenant_id))
    if not variant or not definition: raise HTTPException(400, "Variant and attribute definition must belong to tenant")
    provided = [body.value_text is not None, body.value_number is not None, body.value_boolean is not None, body.value_date is not None, body.value_json is not None]
    if sum(provided) != 1: raise HTTPException(422, "Exactly one attribute value representation is required")
    compatible = {"TEXT":"value_text","NUMBER":"value_number","BOOLEAN":"value_boolean","DATE":"value_date","SELECT":"value_text","MULTI_SELECT":"value_json"}
    field = compatible.get(definition.data_type)
    if not field or getattr(body, field) is None: raise HTTPException(422, f"Value does not match attribute data type {definition.data_type}")
    if definition.data_type == "SELECT" and definition.options:
        choices = definition.options.get("choices", [])
        if body.value_text not in choices: raise HTTPException(422, "Value is not an allowed choice")
    if definition.data_type == "MULTI_SELECT" and definition.options:
        choices = set(definition.options.get("choices", [])); values = set(body.value_json if isinstance(body.value_json, list) else []); 
        if not values.issubset(choices): raise HTTPException(422, "One or more values are not allowed choices")
    row = ProductAttributeValue(tenant_id=tenant_id, variant_id=body.variant_id, attribute_definition_id=body.attribute_definition_id, value_text=body.value_text, value_number=body.value_number, value_boolean=body.value_boolean, value_date=body.value_date, value_json=body.value_json); db.add(row); db.flush(); write_audit(db, tenant_id=tenant_id, actor_user_id=actor, action="catalog.attribute_value.created", target_type="product_attribute_value", target_id=row.id); db.commit(); return row

@router.get("/price-lists", response_model=list[PriceListOut])
def price_lists(ctx=Depends(require_permission("catalog.read"))):
    db, _, tenant_id, _ = ctx; return list(db.scalars(select(PriceList).where(PriceList.tenant_id == tenant_id).order_by(PriceList.effective_from.desc(), PriceList.id)))

@router.post("/price-lists", response_model=PriceListOut, status_code=201)
def create_price_list(body: PriceListIn, idempotency_key: str | None = Header(None, alias="Idempotency-Key"), ctx=Depends(require_permission("catalog.manage"))):
    db, actor, tenant_id, _ = ctx
    try:
        idem, replay = begin_idempotency(db, tenant_id=tenant_id, operation_type="catalog.price_list.create", key=idempotency_key, payload=body.model_dump(mode="json"))
    except CatalogValidation as exc:
        db.rollback(); raise HTTPException(409 if "different" in str(exc) else 422, str(exc)) from exc
    if replay:
        return JSONResponse(status_code=replay[0], content=replay[1])
    if body.effective_to and body.effective_to <= body.effective_from: raise HTTPException(422, "effective_to must be after effective_from")
    row = PriceList(tenant_id=tenant_id, name=normalize_text(body.name,"Price list name"), currency=normalize_code(body.currency,"Currency"), price_type=normalize_code(body.price_type,"Price type"), effective_from=body.effective_from, effective_to=body.effective_to); db.add(row); db.flush(); write_audit(db, tenant_id=tenant_id, actor_user_id=actor, action="catalog.price_list.created", target_type="price_list", target_id=row.id); emit_event(db, tenant_id=tenant_id, event_type="PriceListCreated", aggregate_type="price_list", aggregate_id=row.id, actor_user_id=actor, payload={"id": str(row.id), "name": row.name, "currency": row.currency})
    response_body = PriceListOut.model_validate(row).model_dump(mode="json")
    finish_idempotency(db, idem, status_code=201, response_body=response_body, resource_type="price_list", resource_id=row.id)
    commit_or_409(db, "Price list conflicts with existing data"); return row

@router.get("/prices", response_model=list[ProductPriceOut])
def prices(variant_id: UUID | None = None, price_list_id: UUID | None = None, ctx=Depends(require_permission("catalog.read"))):
    db, _, tenant_id, _ = ctx
    stmt = select(ProductPrice).where(ProductPrice.tenant_id == tenant_id)
    if variant_id: stmt = stmt.where(ProductPrice.variant_id == variant_id)
    if price_list_id: stmt = stmt.where(ProductPrice.price_list_id == price_list_id)
    return list(db.scalars(stmt.order_by(ProductPrice.effective_from.desc(), ProductPrice.minimum_quantity)))

@router.post("/prices", response_model=ProductPriceOut, status_code=201)
def create_price(body: ProductPriceIn, idempotency_key: str | None = Header(None, alias="Idempotency-Key"), ctx=Depends(require_permission("catalog.manage"))):
    db, actor, tenant_id, _ = ctx
    try:
        idem, replay = begin_idempotency(db, tenant_id=tenant_id, operation_type="catalog.price.create", key=idempotency_key, payload=body.model_dump(mode="json"))
    except CatalogValidation as exc:
        db.rollback(); raise HTTPException(409 if "different" in str(exc) else 422, str(exc)) from exc
    if replay:
        return JSONResponse(status_code=replay[0], content=replay[1])
    price_list = db.scalar(select(PriceList).where(PriceList.id == body.price_list_id, PriceList.tenant_id == tenant_id, PriceList.status == "ACTIVE")); variant = db.scalar(select(ProductVariant).where(ProductVariant.id == body.variant_id, ProductVariant.tenant_id == tenant_id, ProductVariant.deleted_at.is_(None)))
    if not price_list or not variant: raise HTTPException(400, "Price list and variant must belong to tenant")
    if body.effective_to and body.effective_to <= body.effective_from: raise HTTPException(422, "effective_to must be after effective_from")
    validate_price(body.unit_price); validate_minimum_quantity(body.minimum_quantity)
    overlap = db.scalar(select(ProductPrice.id).where(
        ProductPrice.tenant_id == tenant_id,
        ProductPrice.price_list_id == body.price_list_id,
        ProductPrice.variant_id == body.variant_id,
        ProductPrice.minimum_quantity == body.minimum_quantity,
        ProductPrice.effective_from < (body.effective_to or datetime.max.replace(tzinfo=timezone.utc)),
        or_(ProductPrice.effective_to.is_(None), ProductPrice.effective_to > body.effective_from),
    ).limit(1))
    if overlap: raise HTTPException(409, "Overlapping price interval exists for this variant, price list and minimum quantity")
    row = ProductPrice(tenant_id=tenant_id, price_list_id=body.price_list_id, variant_id=body.variant_id, unit_price=body.unit_price, minimum_quantity=body.minimum_quantity, effective_from=body.effective_from, effective_to=body.effective_to); db.add(row); db.flush(); write_audit(db, tenant_id=tenant_id, actor_user_id=actor, action="catalog.product_price.created", target_type="product_price", target_id=row.id); emit_event(db, tenant_id=tenant_id, event_type="ProductPriceCreated", aggregate_type="product_price", aggregate_id=row.id, actor_user_id=actor, payload={"id": str(row.id), "variant_id": str(body.variant_id), "price_list_id": str(body.price_list_id)})
    response_body = ProductPriceOut.model_validate(row).model_dump(mode="json")
    finish_idempotency(db, idem, status_code=201, response_body=response_body, resource_type="product_price", resource_id=row.id)
    commit_or_409(db, "Overlapping or duplicate product price is not permitted"); return row
