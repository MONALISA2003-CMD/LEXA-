from pathlib import Path


def endpoint_source():
    repo = Path(__file__).resolve().parents[3]
    source = (repo / "apps/api/app/routes/catalog.py").read_text(encoding="utf-8")
    start = source.index("def create_product_full_setup(")
    end = source.index('@router.patch("/products/{product_id}"', start)
    return source, source[start:end]


def test_full_setup_is_a_typed_idempotent_atomic_write():
    source, endpoint = endpoint_source()
    assert '@router.post("/products/full-setup", response_model=ProductFullSetupOut, status_code=201)' in source
    assert 'operation_type="catalog.product.full_setup"' in endpoint
    for model in ("Product(", "ProductVariant(", "ProductAttributeValue(", "Barcode(", "ProductPrice("):
        assert model in endpoint
    assert "finish_idempotency(" in endpoint
    assert "db.commit()" in endpoint
    assert "except IntegrityError as exc:" in endpoint
    assert "db.rollback()" in endpoint


def test_full_setup_requires_prices_for_all_saleable_variants_and_never_creates_stock():
    source, endpoint = endpoint_source()
    schema_start = source.index("class ProductSetupVariantIn(BaseModel):")
    schema_end = source.index("class ProductFullSetupIn(BaseModel):", schema_start)
    variant_schema = source[schema_start:schema_end]
    assert "price_list_id: UUID" in variant_schema
    assert "unit_price: Decimal = Field(ge=0)" in variant_schema
    assert "minimum_quantity: Decimal" in variant_schema
    assert '"opening_stock_created": False' in endpoint
    assert "inventory_balances" not in endpoint
    assert "stock_movement" not in endpoint.lower()


def test_full_setup_checks_tenant_owned_references_and_unique_identifiers():
    _, endpoint = endpoint_source()
    for expression in (
        "Category.tenant_id == tenant_id",
        "Brand.tenant_id == tenant_id",
        "Unit.tenant_id == tenant_id",
        "PriceList.tenant_id == tenant_id",
        "ProductAttributeDefinition.tenant_id == tenant_id",
        "ProductVariant.tenant_id == tenant_id",
        "Barcode.tenant_id == tenant_id",
        "Duplicate attribute combinations are not allowed.",
        "Two variants in this setup have the same SKU.",
    ):
        assert expression in endpoint


def test_full_setup_only_advertises_supported_costing_and_bounded_combinations():
    source, endpoint = endpoint_source()
    assert 'Field(min_length=1, max_length=100)' in source
    assert 'combination_attribute_ids: list[UUID] = Field(default_factory=list, max_length=10)' in source
    assert 'raw.costing_method != "WEIGHTED_AVERAGE"' in endpoint
    assert "Generated combinations can only use configured single-select attributes." in endpoint


def test_full_setup_only_uses_price_lists_valid_at_the_price_effective_date():
    _, endpoint = endpoint_source()
    assert "PriceList.effective_from <= effective_from" in endpoint
    assert "PriceList.effective_to > effective_from" in endpoint
    assert "effective_to=price_lists_by_id[raw.price_list_id].effective_to" in endpoint
    assert "Selling price must be a finite number." in endpoint
    assert "Minimum quantity must be a finite number greater than zero." in endpoint


def test_full_setup_does_not_accept_unverified_tax_category_ids():
    _, endpoint = endpoint_source()
    assert "if body.tax_category_id is not None:" in endpoint
    assert "no tenant-safe tax-category lookup" in endpoint


def test_inactive_product_does_not_disable_its_variant_records():
    _, endpoint = endpoint_source()
    assert 'status="ACTIVE", costing_method=raw.costing_method' in endpoint
    assert 'status="ACTIVE")' in endpoint


def test_manufacturer_part_number_uses_existing_variant_metadata_storage():
    source, endpoint = endpoint_source()
    assert "manufacturer_part_number: str | None = Field(default=None, max_length=120)" in source
    assert '"manufacturer_part_number": normalize_text(raw.manufacturer_part_number' in endpoint
