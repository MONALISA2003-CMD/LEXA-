from pathlib import Path


def test_quick_product_setup_persists_related_catalog_records_together():
    repo = Path(__file__).resolve().parents[3]
    source = (repo / "apps/api/app/routes/catalog.py").read_text(encoding="utf-8")
    start = source.index('def create_product_quick_setup(')
    end = source.index('@router.patch("/products/{product_id}"', start)
    endpoint = source[start:end]

    assert 'operation_type="catalog.product.quick_setup"' in endpoint
    assert "Product(" in endpoint
    assert "ProductVariant(" in endpoint
    assert "Barcode(" in endpoint
    assert "ProductPrice(" in endpoint
    assert "finish_idempotency(" in endpoint
    assert "db.commit()" in endpoint
    assert 'action="catalog.product.created"' in endpoint
    assert 'action="catalog.variant.created"' in endpoint
    assert "except IntegrityError as exc:" in endpoint
    assert "db.rollback()" in endpoint


def test_quick_product_setup_preserves_stock_ledger_boundary():
    repo = Path(__file__).resolve().parents[3]
    source = (repo / "apps/api/app/routes/catalog.py").read_text(encoding="utf-8")
    start = source.index('def create_product_quick_setup(')
    end = source.index('@router.patch("/products/{product_id}"', start)
    endpoint = source[start:end]

    assert 'require_permission("catalog.manage")' in source
    assert '"opening_stock_created": False' in endpoint
    assert "Record opening stock via an approved inventory adjustment or goods receipt." in endpoint
    assert "stock_movement" not in endpoint.lower()
    assert "inventory_balances" not in endpoint


def test_product_setup_validates_tenant_owned_reference_data_and_prices():
    repo = Path(__file__).resolve().parents[3]
    source = (repo / "apps/api/app/routes/catalog.py").read_text(encoding="utf-8")
    start = source.index('def create_product_quick_setup(')
    end = source.index('@router.patch("/products/{product_id}"', start)
    endpoint = source[start:end]

    assert "Category.tenant_id == tenant_id" in endpoint
    assert "Brand.tenant_id == tenant_id" in endpoint
    assert "(Unit.tenant_id == tenant_id) | (Unit.tenant_id.is_(None))" in endpoint
    assert "PriceList.tenant_id == tenant_id" in endpoint
    assert "ProductVariant.sku == sku" in endpoint
    assert "Barcode.barcode == barcode_value" in endpoint
    assert "Provide both a price list and a selling price, or neither." in endpoint

def test_quick_setup_exposes_a_typed_openapi_response():
    repo = Path(__file__).resolve().parents[3]
    source = (repo / "apps/api/app/routes/catalog.py").read_text(encoding="utf-8")
    assert '@router.post("/products/quick-setup", response_model=ProductQuickSetupOut, status_code=201)' in source
    assert "class ProductQuickSetupOut(BaseModel):" in source
