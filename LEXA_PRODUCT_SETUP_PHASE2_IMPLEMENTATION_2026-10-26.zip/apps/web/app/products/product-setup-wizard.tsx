"use client";

import { useEffect, useMemo, useState, type FormEvent } from "react";
import {
  createProductFullSetup, getProductAttributeDefinitions, userFacingError,
  type Brand, type Category, type Product, type PriceList, type Unit,
  type ProductAttributeDefinition, type ProductFullSetupVariantInput,
} from "../../lib/api";

type VariantDraft = {
  id: string; name: string; sku: string; baseUnitId: string; barcode: string; barcodeType: string; manufacturerPartNumber: string;
  priceListId: string; unitPrice: string; minimumQuantity: string;
  trackInventory: boolean; allowFractionalQuantity: boolean;
  attributes: Record<string, string | number | boolean | string[]>; enabled: boolean;
};
type Props = {
  categories: Category[]; brands: Brand[]; units: Unit[]; priceLists: PriceList[];
  onCreated: (product: Product, preferredVariantId?: string) => Promise<void> | void;
};
const stepNames = ["Identity", "SKU & variants", "Tracking", "Pricing & costing", "Review"];
const newVariant = (unitId = ""): VariantDraft => ({
  id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`, name: "Each", sku: "", baseUnitId: unitId,
  barcode: "", barcodeType: "EAN", manufacturerPartNumber: "", priceListId: "", unitPrice: "", minimumQuantity: "1", trackInventory: true,
  allowFractionalQuantity: false, attributes: {}, enabled: true,
});
function skuPart(value: string) {
  return value.normalize("NFKD").replace(/[\u0300-\u036f]/g, "").toUpperCase().replace(/[^A-Z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 24);
}
function buildSku(productName: string, variantName: string, index: number) {
  const base = skuPart(productName) || "ITEM";
  const suffix = skuPart(variantName);
  const combined = [base, suffix && suffix !== "EACH" ? suffix : "", index > 1 ? String(index) : ""].filter(Boolean).join("-");
  return combined.slice(0, 100) || `ITEM-${index}`;
}
function cartesian<T>(groups: T[][]): T[][] {
  return groups.reduce<T[][]>((acc, group) => acc.flatMap((prefix) => group.map((value) => [...prefix, value])), [[]]);
}

export function ProductSetupWizard({ categories, brands, units, priceLists, onCreated }: Props) {
  const [step, setStep] = useState(0);
  const [productName, setProductName] = useState("");
  const [productType, setProductType] = useState("STOCKED");
  const [productStatus, setProductStatus] = useState("ACTIVE");
  const [categoryId, setCategoryId] = useState("");
  const [brandId, setBrandId] = useState("");
  const [description, setDescription] = useState("");
  const [imageUrl, setImageUrl] = useState("");
  const [subcategory, setSubcategory] = useState("");
  const [mode, setMode] = useState<"single" | "manual" | "attributes">("single");
  const [variants, setVariants] = useState<VariantDraft[]>([newVariant()]);
  const [definitions, setDefinitions] = useState<ProductAttributeDefinition[]>([]);
  const [selectedValues, setSelectedValues] = useState<Record<string, string[]>>({});
  const [attributeLoadError, setAttributeLoadError] = useState("");
  const [attributeLoading, setAttributeLoading] = useState(false);
  const [message, setMessage] = useState("");
  const [busy, setBusy] = useState(false);
  const [attempted, setAttempted] = useState(false);
  const activeCategories = categories.filter((x) => x.status === "ACTIVE");
  const activeBrands = brands.filter((x) => x.status === "ACTIVE");
  const nowMs = Date.now();
  const activePriceLists = priceLists.filter((x) => {
    const starts = new Date(x.effective_from).getTime();
    const ends = x.effective_to ? new Date(x.effective_to).getTime() : Number.POSITIVE_INFINITY;
    return x.status === "ACTIVE" && Number.isFinite(starts) && starts <= nowMs && ends > nowMs;
  });
  const relevantDefinitions = definitions.filter((d) => !d.category_id || d.category_id === categoryId);
  const generatedDefinitions = relevantDefinitions.filter((d) => d.data_type === "SELECT");
  const requiredDefinitions = relevantDefinitions.filter((d) => d.required);
  const selectedDefinitions = relevantDefinitions.filter((d) => (selectedValues[d.id] || []).length > 0);
  const enabledVariants = variants.filter((v) => v.enabled);
  const skuDuplicates = useMemo(() => {
    const counts = new Map<string, number>();
    enabledVariants.forEach((v) => { const key = v.sku.trim().toUpperCase(); if (key) counts.set(key, (counts.get(key) || 0) + 1); });
    return new Set([...counts.entries()].filter(([, n]) => n > 1).map(([sku]) => sku));
  }, [enabledVariants]);

  useEffect(() => {
    setAttributeLoading(true);
    void getProductAttributeDefinitions().then(setDefinitions).catch((error) => {
      setAttributeLoadError(userFacingError(error, "Attribute definitions could not be loaded."));
    }).finally(() => setAttributeLoading(false));
  }, []);

  function updateVariant(id: string, patch: Partial<VariantDraft>) {
    setVariants((current) => current.map((v) => v.id === id ? { ...v, ...patch } : v));
  }
  function generateSkus() {
    setVariants((current) => current.map((v, index) => ({ ...v, sku: buildSku(productName, v.name, index + 1) })));
    setMessage("Generated SKU suggestions. Review and edit them before creating the product.");
  }
  function chooseMode(nextMode: "single" | "manual" | "attributes") {
    setMode(nextMode);
    if (nextMode === "single") setVariants((current) => [{ ...(current[0] || newVariant(units[0]?.id)), name: current[0]?.name || "Each", attributes: {}, enabled: true }]);
    if (nextMode === "manual" && variants.length < 2) setVariants((current) => [...current, { ...newVariant(units[0]?.id), name: `Variant ${current.length + 1}`, trackInventory: productType !== "SERVICE" }]);
    if (nextMode === "attributes") setVariants((current) => current.length ? current : [newVariant(units[0]?.id)]);
    setMessage("");
  }
  function previewCombinations() {
    const dimensions = selectedDefinitions.filter((definition) => definition.data_type === "SELECT").map((definition) => ({ definition, values: selectedValues[definition.id] || [] }));
    if (!dimensions.length || dimensions.some((d) => !d.values.length)) {
      setMessage("Choose at least one attribute and select one or more values for each chosen attribute.");
      return;
    }
    const combinations = cartesian(dimensions.map((d) => d.values));
    if (combinations.length > 100) {
      setMessage(`That selection creates ${combinations.length} combinations. Reduce the selection to 100 or fewer before continuing.`);
      return;
    }
    const generated = combinations.map((values, index) => {
      const attributes: Record<string, string> = {};
      const title = values.map((value, i) => `${dimensions[i].definition.name}: ${value}`).join(" / ");
      values.forEach((value, i) => { attributes[dimensions[i].definition.id] = value; });
      return { ...newVariant(units[0]?.id), name: title.slice(0, 200), sku: buildSku(productName, title, index + 1),
        priceListId: activePriceLists[0]?.id || "", attributes, trackInventory: productType !== "SERVICE", enabled: true };
    });
    setVariants(generated);
    setMessage(`Preview created ${generated.length} combinations. Exclude combinations you do not sell, and verify each SKU and price.`);
  }
  function stepErrors(targetStep = step): string[] {
    const errors: string[] = [];
    if (targetStep === 0) {
      if (!productName.trim()) errors.push("Enter a product name.");
      if (!categoryId) errors.push("Choose a category.");
      if (brandId && !activeBrands.some((b) => b.id === brandId)) errors.push("Choose an active brand.");
      if (imageUrl.trim()) { try { const parsed = new URL(imageUrl.trim()); if (parsed.protocol !== "https:" || parsed.username || parsed.password) errors.push("Product image URL must use HTTPS and cannot contain embedded credentials."); } catch { errors.push("Enter a valid HTTPS product image URL, or leave it blank."); } }
    }
    if (targetStep === 1) {
      if (!enabledVariants.length) errors.push("Keep at least one sellable variant enabled.");
      enabledVariants.forEach((v, i) => {
        if (!v.name.trim()) errors.push(`Variant ${i + 1}: enter a variant name.`);
        if (!v.sku.trim()) errors.push(`Variant ${i + 1}: enter or generate an SKU.`);
        if (skuDuplicates.has(v.sku.trim().toUpperCase())) errors.push(`SKU ${v.sku} is duplicated in this setup.`);
        if (!v.baseUnitId) errors.push(`Variant ${i + 1}: choose a unit of measure.`);
        if (v.barcode.trim() && enabledVariants.some((other) => other.id !== v.id && other.barcode.trim() === v.barcode.trim())) errors.push(`Barcode ${v.barcode} is repeated in this setup.`);
        requiredDefinitions.forEach((definition) => {
          const value = v.attributes[definition.id];
          if (value === undefined || value === null || value === "" || (Array.isArray(value) && value.length === 0)) errors.push(`Variant ${i + 1}: complete required attribute ${definition.name}.`);
        });
      });
      if (mode === "attributes" && !enabledVariants.some((v) => Object.keys(v.attributes).length)) errors.push("Preview attribute combinations before continuing.");
    }
    if (targetStep === 2 && productType !== "SERVICE") {
      enabledVariants.forEach((v, i) => {
        const unit = units.find((u) => u.id === v.baseUnitId);
        if (v.allowFractionalQuantity && (!unit?.allows_fraction || unit.precision_scale < 1)) errors.push(`Variant ${i + 1}: ${unit?.name || "This unit"} does not support fractional quantities.`);
      });
    }
    if (targetStep === 3) {
      enabledVariants.forEach((v, i) => {
        if (!v.priceListId || !activePriceLists.some((p) => p.id === v.priceListId)) errors.push(`Variant ${i + 1}: choose an active selling price list.`);
        if (v.unitPrice.trim() === "" || !Number.isFinite(Number(v.unitPrice)) || Number(v.unitPrice) < 0) errors.push(`Variant ${i + 1}: enter a valid selling price.`);
        if (v.minimumQuantity.trim() === "" || !Number.isFinite(Number(v.minimumQuantity)) || Number(v.minimumQuantity) <= 0) errors.push(`Variant ${i + 1}: minimum price quantity must be greater than zero.`);
      });
    }
    return [...new Set(errors)];
  }
  function goNext() {
    const errors = stepErrors();
    setAttempted(true);
    if (errors.length) { setMessage(errors[0]); return; }
    if (step === 0) {
      setVariants((current) => current.map((v, index) => ({
        ...v,
        name: v.name.trim() || (productType === "SERVICE" ? "Service" : "Each"),
        sku: v.sku.trim() || buildSku(productName, v.name || "Each", index + 1),
        baseUnitId: v.baseUnitId || units[0]?.id || "",
        priceListId: v.priceListId || activePriceLists[0]?.id || "",
      })));
    }
    setAttempted(false); setMessage(""); setStep((s) => Math.min(4, s + 1));
  }
  function goBack() { setMessage(""); setAttempted(false); setStep((s) => Math.max(0, s - 1)); }

  async function submit(event?: FormEvent) {
    event?.preventDefault();
    if (step < 4) { goNext(); return; }
    const errors = [0, 1, 2, 3].flatMap((s) => stepErrors(s));
    setAttempted(true);
    if (errors.length) { setMessage(errors[0]); const match = errors[0].match(/Variant (\d+)/); if (match && Number(match[1]) > 0) setStep(errors[0].includes("price") || errors[0].includes("quantity") ? 3 : 1); else setStep(errors[0].includes("category") || errors[0].includes("product name") ? 0 : 1); return; }
    setBusy(true); setMessage("");
    try {
      const payloadVariants: ProductFullSetupVariantInput[] = enabledVariants.map((v) => ({
        name: v.name.trim(), sku: v.sku.trim().toUpperCase(), base_unit_id: v.baseUnitId,
        track_inventory: productType === "SERVICE" ? false : v.trackInventory,
        allow_fractional_quantity: productType === "SERVICE" ? false : v.allowFractionalQuantity,
        costing_method: "WEIGHTED_AVERAGE", barcode: v.barcode.trim() || null,
        barcode_type: v.barcodeType, manufacturer_part_number: v.manufacturerPartNumber.trim() || null,
        price_list_id: v.priceListId, unit_price: v.unitPrice,
        minimum_quantity: v.minimumQuantity, attributes: v.attributes,
      }));
      const result = await createProductFullSetup({
        product_name: productName.trim(), category_id: categoryId, brand_id: brandId || null,
        description: description.trim() || null, image_url: imageUrl.trim() || null,
        product_type: productType, status: productStatus,
        product_metadata: { subcategory: subcategory.trim() || null, setup_method: mode.toUpperCase() },
        variants: payloadVariants,
        combination_attribute_ids: mode === "attributes" ? selectedDefinitions.filter((d) => d.data_type === "SELECT").map((d) => d.id) : [],
      });
      setMessage(`Created ${result.product.name} with ${result.variants.length} variant${result.variants.length === 1 ? "" : "s"}. No opening stock was created.`);
      try {
        await onCreated(result.product, result.variants[0]?.id);
      } catch {
        setMessage(`Product ${result.product.name} was created successfully, but the catalogue view could not refresh. Reload the page; do not submit the product again.`);
      }
    } catch (error) {
      setMessage(userFacingError(error, "Product setup failed. The server did not confirm that the product was created."));
    } finally { setBusy(false); }
  }

  const errors = attempted ? stepErrors() : [];
  return <div className="product-wizard" aria-label="Product setup wizard">
    <div className="product-wizard-progress" aria-label={`Step ${step + 1} of 5`}>
      {stepNames.map((name, index) => <button type="button" key={name} className={`product-wizard-step ${step === index ? "current" : ""} ${step > index ? "complete" : ""}`} onClick={() => { if (index < step) { setStep(index); setMessage(""); } }} disabled={busy || index > step} aria-current={step === index ? "step" : undefined}>
        <span>{step > index ? "✓" : index + 1}</span><b>{name}</b>
      </button>)}
    </div>
    <form onSubmit={submit}>
      {step === 0 && <section className="product-wizard-body">
        <div className="product-wizard-intro"><span>STEP 1 OF 5</span><h3>Product identity</h3><p>Start with the catalogue identity and choose whether the product should be active or inactive after creation.</p></div>
        <div className="form-grid">
          <label>Product name *<input value={productName} onChange={(e) => setProductName(e.target.value)} required maxLength={250} placeholder="e.g. Long Grain Rice" /></label>
          <label>Product type *<select value={productType} onChange={(e) => { setProductType(e.target.value); if (e.target.value === "SERVICE") setVariants((current) => current.map((v) => ({ ...v, trackInventory: false, allowFractionalQuantity: false }))); }}><option value="STOCKED">Stocked product</option><option value="SERVICE">Service (not stocked)</option></select></label>
          <label>Category *<select value={categoryId} onChange={(e) => { setCategoryId(e.target.value); setSelectedValues({}); setVariants((current) => current.map((v) => ({ ...v, attributes: {} }))); if (mode === "attributes") setMessage("Category changed. Preview attribute combinations again before continuing."); }} required><option value="">Select category</option>{activeCategories.map((c) => <option value={c.id} key={c.id}>{c.name}</option>)}</select></label>
          <label>Product status *<select value={productStatus} onChange={(e) => setProductStatus(e.target.value)}><option value="ACTIVE">Active — available for use</option><option value="INACTIVE">Inactive — not available by default</option></select></label>
          <label>Brand (optional)<select value={brandId} onChange={(e) => setBrandId(e.target.value)}><option value="">No brand</option>{activeBrands.map((b) => <option value={b.id} key={b.id}>{b.name}</option>)}</select></label>
          <label>Subcategory (optional)<input value={subcategory} onChange={(e) => setSubcategory(e.target.value)} maxLength={120} placeholder="e.g. Grains" /></label>
          <label className="full-width">Description (optional)<textarea value={description} onChange={(e) => setDescription(e.target.value)} maxLength={2000} rows={3} placeholder="Product details useful to your team" /></label>
          <label className="full-width">Product image URL (optional)<input type="url" value={imageUrl} onChange={(e) => setImageUrl(e.target.value)} maxLength={2048} placeholder="https://example.com/product-image.jpg" autoComplete="url" /><small className="detail-hint">Use an HTTPS image URL. LEXA stores this URL in product metadata; direct image upload is not available in the current storage API.</small></label>
        </div>
        {(!activeCategories.length || !units.length) && <p className="form-field-error">An active category and unit of measure are required before setup can continue.</p>}
      </section>}
      {step === 1 && <section className="product-wizard-body">
        <div className="product-wizard-intro"><span>STEP 2 OF 5</span><h3>SKU, identifiers and variants</h3><p>Generate editable SKUs, add barcodes, or preview attribute combinations before deciding which to create.</p></div>
        <div className="product-wizard-mode" role="group" aria-label="Variant setup mode">
          {[{id:"single",title:"Single item",copy:"One sellable variant"},{id:"manual",title:"Manual variants",copy:"Add pack sizes or options"},{id:"attributes",title:"Attribute-generated",copy:"Preview size, colour and other combinations"}].map((option) => <button type="button" key={option.id} className={mode===option.id?"selected":""} onClick={() => chooseMode(option.id as "single"|"manual"|"attributes")}><strong>{option.title}</strong><small>{option.copy}</small></button>)}
        </div>
        {mode === "attributes" && <div className="product-wizard-attributes">
          <div className="product-wizard-inline-head"><strong>Choose attribute dimensions</strong><button type="button" className="button button-soft button-small" onClick={previewCombinations} disabled={attributeLoading || busy}>Preview combinations</button></div>
          {attributeLoading && <p>Loading available attributes…</p>}
          {attributeLoadError && <p className="form-field-error">{attributeLoadError}</p>}
          {!attributeLoading && generatedDefinitions.map((definition) => {
            const choices = definition.options?.choices || [];
            return <div className="product-wizard-attribute" key={definition.id}><strong>{definition.name}{definition.required ? " *" : ""}</strong>
              {!choices.length ? <small>No configured choices are available for this attribute.</small> : <div className="product-wizard-choices">{choices.map((choice) => <label className="check-line" key={choice}><input type="checkbox" checked={(selectedValues[definition.id] || []).includes(choice)} onChange={(e) => setSelectedValues((current) => ({ ...current, [definition.id]: e.target.checked ? [...(current[definition.id] || []), choice] : (current[definition.id] || []).filter((x) => x !== choice) }))}/>{choice}</label>)}</div>}
            </div>;
          })}
          {!attributeLoading && generatedDefinitions.length === 0 && <p>No attribute definitions with configured choices are available. Create them in catalogue attribute settings first, or use manual variants.</p>}
        </div>}
        {mode !== "attributes" && <div className="product-wizard-inline-head"><strong>{mode === "single" ? "Sellable item" : "Sellable variants"}</strong><div className="toolbar-actions"><button type="button" className="button button-soft button-small" onClick={generateSkus}>Generate SKU suggestions</button>{mode === "manual" && <button type="button" className="button button-soft button-small" onClick={() => setVariants((current) => [...current, { ...newVariant(units[0]?.id), name: `Variant ${current.length + 1}`, trackInventory: productType !== "SERVICE" }])} disabled={variants.length >= 100}>+ Add variant</button>}</div></div>}
        {mode !== "attributes" && variants.map((v, index) => <div className="product-wizard-variant" key={v.id}>
          <div className="product-wizard-variant-title"><strong>Variant {index + 1}</strong>{mode === "manual" && variants.length > 1 && <button type="button" className="row-remove" onClick={() => setVariants((current) => current.filter((x) => x.id !== v.id))} aria-label={`Remove variant ${index + 1}`}>×</button>}</div>
          <div className="form-grid"><label>Variant name *<input value={v.name} maxLength={200} onChange={(e) => updateVariant(v.id, {name:e.target.value})} required /></label>
            <label>Editable SKU *<input value={v.sku} maxLength={100} onChange={(e) => updateVariant(v.id, {sku:e.target.value.toUpperCase()})} autoCapitalize="characters" autoComplete="off" required /></label>
            <label>Unit of measure *<select value={v.baseUnitId} onChange={(e) => updateVariant(v.id, {baseUnitId:e.target.value})} required><option value="">Select unit</option>{units.map((u) => <option key={u.id} value={u.id}>{u.name} ({u.symbol})</option>)}</select></label>
            <label>Barcode (optional)<input value={v.barcode} onChange={(e) => updateVariant(v.id, {barcode:e.target.value})} maxLength={120} autoComplete="off" placeholder="Scan or type identifier" /></label>
            <label>Barcode type<select value={v.barcodeType} onChange={(e) => updateVariant(v.id, {barcodeType:e.target.value})}><option value="EAN">EAN</option><option value="UPC">UPC</option><option value="CODE128">Code 128</option><option value="OTHER">Other</option></select></label>
            <label>Manufacturer part number (optional)<input value={v.manufacturerPartNumber} onChange={(e) => updateVariant(v.id, {manufacturerPartNumber:e.target.value})} maxLength={120} autoComplete="off" placeholder="Manufacturer's reference" /></label>
          </div>
          {skuDuplicates.has(v.sku.trim().toUpperCase()) && <small className="form-field-error">This SKU is duplicated in the current setup.</small>}
        </div>)}
        {mode === "attributes" && variants.length > 0 && <div className="product-wizard-variant-list"><div className="product-wizard-inline-head"><strong>Combination preview ({variants.length})</strong><span>Uncheck any combination you do not sell.</span></div>{variants.map((v, index) => <div className="product-wizard-preview-row" key={v.id}><label className="check-line"><input type="checkbox" checked={v.enabled} onChange={(e) => updateVariant(v.id, {enabled:e.target.checked})}/><span><strong>{v.name}</strong><small>{Object.values(v.attributes).join(" / ")}</small></span></label><input aria-label={`SKU for ${v.name}`} value={v.sku} onChange={(e) => updateVariant(v.id, {sku:e.target.value.toUpperCase()})} placeholder="SKU"/><select aria-label={`Unit for ${v.name}`} value={v.baseUnitId} onChange={(e) => updateVariant(v.id, {baseUnitId:e.target.value})}><option value="">Unit</option>{units.map((u) => <option key={u.id} value={u.id}>{u.symbol}</option>)}</select></div>)}</div>}
        {requiredDefinitions.length > 0 && <div className="product-wizard-attributes"><div className="product-wizard-inline-head"><strong>Required product attributes</strong><span>Complete required values for each sellable variant.</span></div>{enabledVariants.map((v, index) => <div className="product-wizard-variant" key={`required-${v.id}`}><div className="product-wizard-variant-title"><strong>{v.name || `Variant ${index + 1}`}</strong></div>{requiredDefinitions.map((definition) => {
          const existingValue = v.attributes[definition.id];
          if (mode === "attributes" && v.attributes[definition.id] !== undefined && definition.data_type === "SELECT") return null;
          const value = existingValue === undefined ? "" : existingValue;
          const setValue = (next: string | number | boolean | string[]) => updateVariant(v.id, { attributes: { ...v.attributes, [definition.id]: next } });
          if (definition.data_type === "BOOLEAN") return <label key={definition.id}>{definition.name} *<select value={value === true ? "true" : value === false ? "false" : ""} onChange={(e) => setValue(e.target.value === "true")}><option value="">Choose value</option><option value="true">Yes</option><option value="false">No</option></select></label>;
          if (definition.data_type === "SELECT") return <label key={definition.id}>{definition.name} *<select value={String(value)} onChange={(e) => setValue(e.target.value)}><option value="">Choose {definition.name}</option>{(definition.options?.choices || []).map((choice) => <option key={choice} value={choice}>{choice}</option>)}</select></label>;
          if (definition.data_type === "MULTI_SELECT") return <div className="product-wizard-attribute" key={definition.id}><strong>{definition.name} *</strong><div className="product-wizard-choices">{(definition.options?.choices || []).map((choice) => <label className="check-line" key={choice}><input type="checkbox" checked={Array.isArray(value) && value.includes(choice)} onChange={(e) => { const current = Array.isArray(value) ? value : []; setValue(e.target.checked ? [...current, choice] : current.filter((x) => x !== choice)); }}/>{choice}</label>)}</div></div>;
          const inputType = definition.data_type === "NUMBER" ? "number" : definition.data_type === "DATE" ? "date" : "text";
          return <label key={definition.id}>{definition.name} *<input type={inputType} value={String(value)} onChange={(e) => setValue(e.target.value)} required /></label>;
        })}</div>)}</div>}
      </section>}
      {step === 2 && <section className="product-wizard-body">
        <div className="product-wizard-intro"><span>STEP 3 OF 5</span><h3>Inventory tracking</h3><p>These settings control the quantity-tracking fields currently enforced by LEXA's variant and inventory foundation.</p></div>
        <div className="product-wizard-tracking">
          <label className="check-line"><input type="checkbox" checked={enabledVariants.every((v) => v.trackInventory)} disabled={productType === "SERVICE"} onChange={(e) => setVariants((current) => current.map((v) => ({...v, trackInventory:e.target.checked, allowFractionalQuantity:e.target.checked ? v.allowFractionalQuantity : false})))}/><span><strong>Track inventory quantities</strong><small>Enable stock balances and inventory movement tracking for this product's variants.</small></span></label>
          <label className="check-line"><input type="checkbox" checked={enabledVariants.every((v) => v.allowFractionalQuantity)} disabled={productType === "SERVICE" || !enabledVariants.every((v) => v.trackInventory) || enabledVariants.some((v) => !units.find((u) => u.id === v.baseUnitId)?.allows_fraction)} onChange={(e) => setVariants((current) => current.map((v) => ({...v, allowFractionalQuantity:e.target.checked})))}/><span><strong>Allow fractional quantities</strong><small>Available only when every selected unit supports fractional quantities.</small></span></label>
        </div>
        <div className="product-wizard-capability-note"><strong>Traceability capabilities</strong><p>Serial/IMEI and batch/lot/expiry tracking are not enabled in this setup because the current downstream transaction APIs do not yet enforce their full lifecycle. They are intentionally not presented as active switches.</p></div>
        {productType === "SERVICE" && <p className="detail-hint">Service products are automatically configured as not inventory-tracked.</p>}
      </section>}
      {step === 3 && <section className="product-wizard-body">
        <div className="product-wizard-intro"><span>STEP 4 OF 5</span><h3>Pricing, costing and replenishment</h3><p>A valid selling price is required for every saleable variant. Stock remains separate from catalogue setup.</p></div>
        <div className="product-wizard-capability-note"><strong>Costing method: Weighted average</strong><p>This is the currently exposed method for safe setup. FIFO and standard cost are not offered here until their valuation and accounting effects are verified end-to-end.</p></div>
        {enabledVariants.map((v, index) => <div className="product-wizard-variant" key={v.id}><div className="product-wizard-variant-title"><strong>{v.name || `Variant ${index+1}`}</strong><small>{v.sku || "SKU not set"}</small></div>
          <div className="form-grid"><label>Selling price list *<select value={v.priceListId} onChange={(e) => updateVariant(v.id, {priceListId:e.target.value})} required><option value="">Choose price list</option>{activePriceLists.map((p) => <option key={p.id} value={p.id}>{p.name} · {p.currency}</option>)}</select></label>
            <label>Selling price *<input type="number" min="0" step="0.0001" inputMode="decimal" value={v.unitPrice} onChange={(e) => updateVariant(v.id, {unitPrice:e.target.value})} placeholder="0.00" required /></label>
            <label>Minimum quantity for this price *<input type="number" min="0.001" step="0.001" inputMode="decimal" value={v.minimumQuantity} onChange={(e) => updateVariant(v.id, {minimumQuantity:e.target.value})} required /></label>
          </div>
        </div>)}
        <div className="product-wizard-capability-note"><strong>Tax classification (optional)</strong><p>Tax rules are not assigned from this wizard because the catalogue does not have a tenant-safe tax-category lookup. Configure effective-dated product, category or default tax rules through Finance. Required-tax blocking at sale posting still needs dedicated verification in the sales workflow.</p></div>
        <p className="detail-hint">Reorder levels and preferred suppliers are not collected here because this schema does not establish them as product-level settings. Configure replenishment in the relevant purchasing or inventory workflow.</p>
      </section>}
      {step === 4 && <section className="product-wizard-body">
        <div className="product-wizard-intro"><span>STEP 5 OF 5</span><h3>Review and create</h3><p>Check the product identity, variant count, tracking policy and all selling prices before submitting.</p></div>
        <div className="product-wizard-review-grid"><div><span>PRODUCT</span><strong>{productName || "Unnamed product"}</strong><small>{productType} · {productStatus} · {activeCategories.find((c) => c.id === categoryId)?.name || "No category"}</small></div><div><span>BRAND</span><strong>{activeBrands.find((b) => b.id === brandId)?.name || "Not set"}</strong><small>{subcategory || "No subcategory"}</small></div><div><span>VARIANTS</span><strong>{enabledVariants.length}</strong><small>{mode === "attributes" ? "Attribute-generated" : mode === "manual" ? "Manually configured" : "Single item"}</small></div><div><span>INVENTORY</span><strong>{enabledVariants.every((v) => v.trackInventory) ? "Tracked" : enabledVariants.every((v) => !v.trackInventory) ? "Not tracked" : "Mixed"}</strong><small>{enabledVariants.every((v) => v.allowFractionalQuantity) ? "Fractional quantities enabled" : "Whole quantities by default"}</small></div></div>
        <div className="product-wizard-review-list">{enabledVariants.map((v, index) => { const list = activePriceLists.find((p) => p.id === v.priceListId); return <div key={v.id}><div><strong>{index+1}. {v.name}</strong><small>{v.sku} · {units.find((u) => u.id === v.baseUnitId)?.symbol || "unit"}{v.barcode ? ` · Barcode ${v.barcode}` : ""}{v.manufacturerPartNumber.trim() ? ` · MPN ${v.manufacturerPartNumber.trim()}` : ""}</small></div><div className="product-wizard-price-review"><strong>{list?.currency || ""} {v.unitPrice || "—"}</strong><small>{list?.name || "No price list"}</small></div></div>; })}</div>
        <div className="product-wizard-capability-note"><strong>No opening stock will be created</strong><p>Stock quantities and inventory valuation must be entered separately through Inventory or a posted goods receipt.</p></div>
        {errors.length > 0 && <div className="form-field-error" role="alert">{errors.join(" ")}</div>}
      </section>}
      {message && <p className={message.toLowerCase().includes("created ") ? "inline-message" : "form-field-error"} role="status">{message}</p>}
      <div className="product-wizard-actions">
        <span className="product-wizard-step-count">Step {step + 1} of 5</span>
        <div className="toolbar-actions">{step > 0 && <button type="button" className="button button-soft" onClick={goBack} disabled={busy}>Back</button>}{step < 4 ? <button type="button" className="button button-dark" onClick={goNext} disabled={busy || (step === 0 && (!activeCategories.length || !units.length))}>Continue</button> : <button type="submit" className="button button-dark" disabled={busy}>{busy ? "Creating product…" : "Create product"}</button>}</div>
      </div>
    </form>
  </div>;
}
