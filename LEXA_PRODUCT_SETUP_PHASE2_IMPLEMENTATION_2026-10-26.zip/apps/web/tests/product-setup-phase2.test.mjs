import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import test from 'node:test';

const root = path.resolve(new URL('../..', import.meta.url).pathname, '..');
const wizardPath = path.join(root, 'apps/web/app/products/product-setup-wizard.tsx');
const apiPath = path.join(root, 'apps/web/lib/api.ts');
const routePath = path.join(root, 'apps/api/app/routes/catalog.py');
const wizard = fs.readFileSync(wizardPath, 'utf8');
const api = fs.readFileSync(apiPath, 'utf8');
const route = fs.readFileSync(routePath, 'utf8');

test('Phase 2 wizard contains the agreed five steps and three variant modes', () => {
  assert.match(wizard, /const stepNames = \["Identity", "SKU & variants", "Tracking", "Pricing & costing", "Review"\]/);
  assert.match(wizard, /id:"single"/);
  assert.match(wizard, /id:"manual"/);
  assert.match(wizard, /id:"attributes"/);
  assert.match(wizard, /Preview combinations/);
  assert.match(wizard, /combinations\.length > 100/);
  assert.match(wizard, /Manufacturer part number \(optional\)/);
  assert.match(wizard, /price_list_id: v.priceListId/);
});

test('Phase 2 creation writes through the idempotent API and atomic backend endpoint', () => {
  assert.match(api, /postIdempotent<ProductFullSetupResult>\('\/api\/v1\/catalog\/products\/full-setup'/);
  assert.match(route, /@router\.post\("\/products\/full-setup"/);
  assert.match(route, /operation_type="catalog\.product\.full_setup"/);
  assert.match(route, /finish_idempotency\(db, idem/);
  assert.match(route, /db\.commit\(\)/);
  assert.match(route, /db\.rollback\(\)/);
});

test('Phase 2 enforces a selling price per variant and leaves opening stock to Inventory', () => {
  assert.match(wizard, /A valid selling price is required for every saleable variant/);
  assert.match(route, /price_list_id: UUID/);
  assert.match(route, /unit_price: Decimal = Field\(ge=0\)/);
  assert.match(route, /"opening_stock_created": False/);
  assert.match(wizard, /No opening stock will be created/);
});

test('Unsupported tax and traceability features are not presented as functioning controls', () => {
  assert.match(wizard, /Serial\/IMEI and batch\/lot\/expiry tracking are not enabled/);
  assert.match(wizard, /Tax rules are not assigned from this wizard/);
  assert.match(route, /no tenant-safe tax-category lookup/);
});
