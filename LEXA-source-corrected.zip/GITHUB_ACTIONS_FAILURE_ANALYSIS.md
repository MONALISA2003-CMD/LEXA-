# GitHub Actions failure analysis and recovery

**Repository:** `MONALISA2003-CMD/LEXA-`  
**Run inspected:** [40462755388](https://github.com/MONALISA2003-CMD/LEXA-/actions/runs/40462755388)  
**Commit:** `62229405378fc6213b847a68d2595e0211d5928d` — `Delete .github/workflows/lexa-zip-extract.yml`  
**Inspection date:** 2026-10-27

## What the linked run actually did

This run was **LEXA Main Build CI**, not a ZIP-extraction run. Its head commit deleted `.github/workflows/lexa-zip-extract.yml`, so the run had no extractor job and could not apply the cleaned archive. The run only reported the normal three CI jobs.

## Current `main` state confirmed after the run

The latest `main` commit observed during this inspection is [`7e16cbf5ecfc15edc107be7043e25f8e2dc46a8e`](https://github.com/MONALISA2003-CMD/LEXA-/commit/7e16cbf5ecfc15edc107be7043e25f8e2dc46a8e), titled `Add files via upload`. Its GitHub commit diff lists exactly one changed path: a newly added repository-root `LEXA-cleaned.zip`. It does not change the application source. A ZIP committed as a normal file is inert unless an active workflow is configured to process that path; the extractor workflow had already been deleted. The active CI path filters also do not include a root ZIP, so that upload itself does not run the build workflow. This explains why the repository source did not change after the archive upload.

- API unit and contract tests: **passed**.
- TypeScript typecheck: **passed**.
- Docker Compose and HAProxy configuration: **passed**.
- Frontend contract tests: **failed**; the production frontend build was skipped because the test step failed.

The failing contract was `apps/web/tests/phase12-live-brand-visibility.test.mjs`, “desktop sidebar and authentication use the full master artwork.” It searched for the *last* `.app-sidebar .app-brand { ... }` rule and expected that rule itself to contain `background-image`. The last occurrence in the checked-in CSS was only a responsive height override (`height: 82px` and `min-height: 82px`). The master artwork declaration exists in the base CSS rule and continues to cascade into the responsive override, so the test was checking the wrong CSS block rather than proving the logo was absent.

The test helper has been corrected to scan matching rules from newest to oldest until it finds the selector rule containing the required declaration. The logo assets and CSS implementation are retained.

## Why the previous cleaned ZIP could not be applied by the guarded replacement workflow

The existing `.github/workflows/replace-from-archive.yml` calls `scripts/replace_from_archive.py`, whose required-root-path validation expects all of the following:

- `README.md`
- `apps/web/package.json`
- `apps/api/app/main.py`
- `migrations/README.md`
- `.github/workflows/ci.yml`
- `.github/workflows/replace-from-archive.yml`

The earlier cleaned ZIP contained `.github/workflows/lexa-ci.yml` instead of `.github/workflows/ci.yml`. That filename mismatch is sufficient to make the replacement validator reject it before any file is replaced. The corrected ZIP now uses `.github/workflows/ci.yml`, and its CI path filters and repository-contract references have been updated consistently. This is a real compatibility fix, not a relaxation of validation.

## Correct way to apply this archive

The old `.github/workflows/lexa-zip-extract.yml` workflow is no longer present in the repository. Do not expect uploading a ZIP as a normal repository file to trigger that deleted workflow. Use the existing guarded **Replace repository from verified source archive** workflow instead:

1. Publish this exact `LEXA-cleaned.zip` as a GitHub Release asset and copy the asset URL.
2. Compute the exact archive checksum with `sha256sum LEXA-cleaned.zip`.
3. Open **Actions → Replace repository from verified source archive → Run workflow**.
4. Set `target_branch` to `main`; provide the asset URL, the archive SHA-256, and the current full 40-character `main` HEAD SHA.
5. Set `confirmation` to `REPLACE_ALL_FILES`. Keep `write_mode` at `pull_request`.
6. Review the generated PR and its CI result before merging. The workflow creates a pre-replacement backup artifact and deliberately refuses an archive checksum or branch-head mismatch.

The replacement is a full-tree replacement: it deletes the old tracked/untracked working-tree contents in its isolated Actions checkout (preserving `.git`) and copies the validated archive. That is what removes competing project snapshots; merely extracting files over the top of the existing repository would leave deleted paths behind. The workflow's branch-head guard and reviewable PR remain important safeguards.

## Limitations

The linked run is the CI run above; it does not expose a log for a separate failed extraction run. The analysis distinguishes the actual logged web-test failure from the independent archive-path mismatch found by comparing the previous ZIP with the current replacement workflow's validation requirements. The corrected archive has been checked locally against the replacement script and its source-level suites; only a new GitHub Actions run can confirm the remote full replacement, permissions, and resulting PR.
