# LEXA Repository Cleanup Report

**Run date:** 2026-10-27  
**Input:** `LEXA--main (1).zip`  
**Output:** `LEXA-cleaned.zip` (corrected archive; replaces the earlier incompatible build)

## Result

A canonical source archive has been assembled at the archive root, without a `LEXA-cleaned/LEXA--main/` wrapper. This corrected build also aligns the workflow filename with the existing replacement script (`.github/workflows/ci.yml`) and fixes the frontend contract helper that failed in GitHub Actions run 40462755388. The archive has not been applied to GitHub from this task. The corrected package now passes the existing replacement validator’s required-path checks; the previous package did not, because it supplied `lexa-ci.yml` rather than the required `ci.yml`.

| Measure | Before | After |
|---|---:|---:|
| ZIP size | 18,473,097 bytes (17.62 MiB) | approximately 1.40 MiB (about 1.47 MB; exact delivery size is reported alongside the download) |
| File entries | 2,607 | 427 |
| Uncompressed file content | 31,979,593 bytes (30.50 MiB) | 3,979,438 bytes (3.80 MiB) |
| ZIP size reduction | — | 92.03% |
| Duplicate archive paths | 0 | 0 |

Packaging uses ZIP DEFLATE compression level 9. The original archive held 25 embedded ZIP bundles (1,932,751 bytes of nested-archive payload); these were excluded from the source ZIP.

## Change counts

- **Files moved/renamed:** 28 (useful docs moved into topic-oriented locations and the CI workflow aligned to the required `ci.yml` path; see `RENAME_DELETE_MANIFEST.md`).
- **Added to the final canonical tree:** 10 — seven canonical-tree additions and three reports, including the GitHub Actions failure analysis.
- **Original file paths deleted:** 2,190 after excluding the 27 explicitly moved files. Most deletions were duplicate project snapshots, nested source exports, stale handoffs/release reports, old patch bundles, and generated/cached files.
- **Existing paths modified in place:** 12.
- **Canonical source files retained or moved:** 417 original archive files remain represented in the final tree.

## Canonical repository structure

```text
.
├── .github/workflows/       # CI and safeguarded archive replacement
├── apps/api/                # FastAPI application and API tests
├── apps/web/                # Next.js application, contracts, and browser tests
├── deploy/                  # Docker and Kubernetes deployment assets
├── docs/
│   ├── architecture/
│   ├── decisions/
│   ├── development/
│   ├── operations/
│   ├── product/
│   └── testing/
├── fixtures/                # Contract/type-check fixtures
├── migrations/              # Migration history and explicitly labelled recovery evidence
├── scripts/                 # Validation, replay planning, and operational scripts
├── tests/                   # Repository-wide unit/contract/integration checks
├── README.md
├── CONTRIBUTING.md
├── SECURITY.md
├── .env.example
├── docker-compose.yml
└── render.yaml
```

The active roots `apps/api`, `apps/web`, `migrations`, `deploy`, and the existing CI/deployment configuration were retained. The root README was rewritten around the actual checked-in structure, setup commands, environment variable names, tests, migrations, and deployment boundary. `CONTRIBUTING.md`, `SECURITY.md`, and `.editorconfig` were added. Useful documentation was reorganized under `docs/architecture`, `docs/operations`, `docs/product`, and `docs/testing`; chronology-based folder names were removed where they represented project snapshots rather than a stable architecture.

## Main source and quality changes

- Corrected the supplier-payment accounting block in `migrations/048_phase7_approval_limits_reversals_accounting.sql` to use the declared `a_cash` variable instead of undefined `v_cash`; added a regression contract test.
- Renamed `.github/workflows/lexa-ci.yml` to `.github/workflows/ci.yml`, matching the exact required path in the existing `scripts/replace_from_archive.py` validator; updated CI path filters and active test/documentation references. This corrects the prior archive/validator filename mismatch.
- Updated `scripts/validate-package.sh` to validate the canonical `apps/api/app` tree and the retained canonical workspace/tenant acceptance contract rather than a deleted `overrides/` tree and stale test path.
- Updated workspace setup tests to use the canonical API module and the current seven-step required-setup contract.
- Updated source/contract tests to follow the reorganized deployment docs and current migration replay manifest instead of hard-coded stale counts and paths. Updated all active CI/test/docs references to the canonical `.github/workflows/ci.yml` filename.
- Removed `.github/workflows/lexa-ai-router-build.yml` and its source-mutating patcher scripts because they built/applied source from documentation/patch artifacts rather than the canonical application tree. The regular CI workflow and guarded archive-replacement workflow were retained.
- Removed nested export ZIPs, duplicate snapshots, cache/bytecode outputs, obsolete handoffs, stale release reports, redundant generated manifests, and the competing source roots `source/`, `src/`, `overrides/`, and `lexa_v280_src/`.

## Checks executed and results

| Check | Result | Notes |
|---|---|---|
| Root contract/unit suite — `PYTHONDONTWRITEBYTECODE=1 pytest -q -p no:cacheprovider tests` | **PASS — 145 passed** | Rerun after workflow path normalization. |
| Web contract suite — `node --test tests/*.test.mjs` from `apps/web` | **PASS — 126 passed** | Rerun after the master-brand regression test helper fix; Node built-in runner requires no web dependency install. |
| Python syntax compilation — `python -m compileall -q apps/api/app scripts tests` | **PASS** | Generated bytecode was removed before packaging. |
| Shell syntax — `bash -n` across all repository `*.sh` files | **PASS** | No shell syntax errors reported. |
| Migration recovery manifest — `python scripts/check_migration_recovery_manifest.py` | **PASS** | Six historical source byte sequences remain marked as permanently replaced, not recovered. |
| Strict migration source check — `python scripts/check_migration_sources.py --strict` | **PASS** | Historical recovery decision is internally consistent; semantic validation is still pending. |
| Migration replay planning — `python scripts/run_clean_migration_replay.py --plan-only` | **PASS — 52 inputs hashed** | No database connection opened and no SQL executed. This is not semantic replay. |
| Web package JSON and lockfile parse | **PASS** | Both files parse as JSON and were preserved. |
| High-confidence secret-signature scan | **PASS — no matches** | Heuristic scan only; not a comprehensive secret audit. Only `.env.example` is present; no `.git`, dependency directory, nested ZIP, or cache is in the final tree. |
| ZIP structure/integrity and fresh extraction | **PASS** | Rebuilt archive has root-level canonical paths, no duplicate/unsafe entries, and a successful fresh extraction. |
| Guarded replacement-script validation and full-tree simulation | **PASS** | Tested against a disposable temporary Git checkout with the final archive, correct checksum, and exact expected HEAD; no real GitHub repository was modified. |
| Full API tests — collection attempt with disposable local settings | **BLOCKED** | 325 tests collected, but collection raised two import errors because `pwdlib` and `psycopg` are not installed. No API test suite pass is claimed. |
| TypeScript contract `tsc --noEmit -p tsconfig.contract.json` | **BLOCKED/FAIL in this environment** | The workspace has no installed Next/React dependencies; global TypeScript is 5.8.3 while `apps/web/package.json` specifies 5.9.3, and the contract stubs do not declare the complete Next/React surface used by app source. |
| Web dependency install / production typecheck and build | **NOT VERIFIED** | `npm ci` did not complete within the 120-second attempt; environment Node is 22.16.0, while the project requires Node 24.x. No production build is claimed. |
| Docker Compose validation, Ruff, mypy | **NOT RUN** | `docker`, `ruff`, and `mypy` are not installed in the execution environment. |
| Live database/RLS, Redis readiness, Playwright staging flows, provider calls, deployment status | **NOT RUN** | These require environment-specific services/credentials. No production database was connected to or modified. |

## Security and migration findings

The scan found no high-confidence private-key/token signatures in the final source tree. Real `.env` files and private keys are excluded, but this pattern scan should not be treated as proof that no secret could exist in any form. Rotate any credential that may have been exposed in prior Git history; deleting a file from this ZIP does not rewrite Git history or revoke a credential.

Migration filenames, ordering, source recovery metadata, ledger snapshots, and reconstruction artifacts were preserved. The strict source inventory records six historical migration sources whose exact bytes are unavailable and whose replacements have been permanently dispositioned; it does **not** assert historical-byte recovery. The clean replay command was run in plan-only mode only. Replacement semantic behavior, RLS, grants, function execution rights, and production migration status remain separate release gates.

## Risks and items intentionally preserved

- Unreleased standalone overlays and project snapshot directories were not merged into `apps/api` or `apps/web` merely because they contained additional files. Their unique business-write behavior was not promoted without establishing that it was canonical, tested, and intended for release. If a particular overlay was intended to be the release source, review it separately before applying it.
- Existing migration recovery decisions and source-gap evidence were kept as provenance, even where they document unrecovered original bytes.
- The full Next.js typecheck/build, Python API suite, live PostgreSQL/Redis behavior, browser acceptance, and deployment verification remain unverified for the environment reasons above.

## GitHub Actions run diagnosis

The supplied run `40462755388` was a normal `LEXA Main Build CI` run triggered by the commit deleting `.github/workflows/lexa-zip-extract.yml`; it was not an archive extraction run. After that run, the current `main` head became `7e16cbf5ecfc15edc107be7043e25f8e2dc46a8e` (`Add files via upload`), whose commit adds only the root-level `LEXA-cleaned.zip`; it does not replace or modify application source. Uploading the ZIP as a normal repository file does not trigger extraction, and the deleted extractor workflow cannot run. API tests, the TypeScript typecheck, and Compose/HAProxy validation passed. The web contract suite failed because `phase12-live-brand-visibility.test.mjs` inspected only the final responsive `.app-sidebar .app-brand` height override and mistakenly required it to repeat the base `background-image` declaration. The helper now searches matching rules for the required declaration and the web contracts are rerun below. The earlier archive also used `lexa-ci.yml`, while the active replacement validator requires `ci.yml`; this mismatch is corrected in the delivered archive. Full details are in `GITHUB_ACTIONS_FAILURE_ANALYSIS.md`.

## Release recommendation

Use `LEXA-cleaned.zip` as the cleaned source handoff, then run CI in the target GitHub repository and perform the environment-specific gates above before treating this as a validated release. The ZIP is a source cleanup and not evidence that a live deployment or production database changed.
