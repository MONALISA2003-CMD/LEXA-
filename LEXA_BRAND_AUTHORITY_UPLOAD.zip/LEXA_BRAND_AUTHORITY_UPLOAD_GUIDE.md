# LEXA Brand Authority — Manual Main-Branch Upload

This is an **overlay package** for the existing `MONALISA2003-CMD/LEXA-` repository. It implements the visual authority agreed for the supplied LEXA logo across the shared application shell, dashboard, sales, stock, products, customers, purchasing, finance, reports, intelligence, administration, compliance, documents, settings, sign-in, registration and password recovery screens.

## Exact files in this archive

- `apps/web/app/layout.tsx` — updated shared root layout, brand stylesheet import, metadata and icon.
- `apps/web/app/lexa-brand-authority.css` — new global brand system, loaded after the existing `globals.css` so the shared rules apply to all operations.
- `apps/web/public/lexa-master-logo.jpg` — the uploaded master artwork, retained as supplied (converted to an correctly named JPEG file).
- `apps/web/public/lexa-wordmark-master.jpg` — horizontal derivative for the application sidebar.
- `apps/web/public/lexa-app-mark.png` — compact L glyph derived from the master artwork for favicon/app-icon use.
- `apps/web/public/lexa-logo.svg`, `lexa-logo-light.svg`, `lexa-mark.svg` — preserve existing asset paths while redirecting them to official derivatives of the new master logo.
- `apps/web/tests/phase10-brand-authority.test.mjs` — contract tests for brand assets, shared styling, mobile rules and reduced-motion support.

No API, authentication logic, database migrations, environment variables, deployment settings or financial/business logic are changed.

## Applying the ZIP

1. Download and extract this archive on a computer into a working copy of the repository root, keeping the directory structure shown in the archive. The uploaded logo files belong in `apps/web/public`; the new stylesheet and layout belong in `apps/web/app`; the test belongs in `apps/web/tests`.
2. Replace `apps/web/app/layout.tsx` and the three existing SVG files with the versions in this archive. Add the new files and image assets. Do **not** delete or replace `apps/web/app/globals.css` or the existing application pages.
3. Commit/ upload these files to `main` through your chosen GitHub workflow. Since direct repository write access was rejected, this package is prepared for your manual upload; this assistant has not committed or deployed it.
4. From `apps/web`, run `npm ci --no-audit --no-fund`, then `npm test`, `npm run typecheck`, and `npm run build` on Node 24.
5. Inspect a Vercel preview on a desktop and a phone before considering the update released.

## Brand rules encoded

- The supplied LEXA master logo is the authority; an earlier green checkmark is no longer the main identity on shared shell/auth-brand surfaces.
- The master logo remains intact and is not stretched, recoloured or redrawn. A wordmark crop and a compact L derivative are derived only to support tight spaces.
- Navy is the foundation; blue/cyan/green/gold/red support interaction, positive status, highlights and warnings. Primary actions use one consistent high-contrast treatment; the interface does not turn every control into a rainbow.
- Existing pages/data/authorization remain as they are. This package changes presentation, not business truth.

## Verification boundary

The assets, CSS, root-layout replacement and contract test are generated and locally checked for required files, expected tokens and balanced CSS structure. A full Next.js typecheck/build and authenticated browser journey still need to run in the repository's Node 24 CI environment after upload. No live deployment is claimed.
