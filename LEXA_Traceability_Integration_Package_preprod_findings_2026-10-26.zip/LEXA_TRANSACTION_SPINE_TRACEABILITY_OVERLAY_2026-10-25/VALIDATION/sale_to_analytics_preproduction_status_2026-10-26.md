# LEXA sale-to-analytics pre-production gate — verified findings

**Checked:** 2026-10-26 UTC  
**Status:** NOT GREEN — production readiness and authenticated sale-to-analytics acceptance remain blocked.

## 1. GitHub source branch

- Repository: `MONALISA2003-CMD/LEXA-`.
- Existing work branch: `LEXA-branch`.
- Observed branch head: `9e44536c01080de0cad000f51a597f1cd62118bf`.
- GitHub repository metadata reports push permission. A previous failure to create a new branch is not evidence that the existing branch is absent.
- GitHub comparison reports `LEXA-branch` is **13 commits ahead and 71 commits behind** `main` (`status: diverged`).
- The existing branch does not contain `migrations/046`, `migrations/047`, `migrations/048`, or `apps/api/app/phase7_release_gate.py`. Its canonical clean-replay recovery manifest is still a closed historical gate ending at migration 045.
- The 049–051 overlay has **not** been committed or applied to the source branch. Applying 049–051 straight onto this source state would skip the missing migration source chain; doing so would be unsafe and would not constitute a verified replay.

## 2. Render readiness root cause

- Render service: `LEXA` (`srv-dakm8k95efls73egg9a0`), URL `https://lexa-n10e.onrender.com`, source branch `main`, root directory `apps/api`.
- The currently deployed `main` code deliberately requires migration `048_phase7_approval_limits_reversals_accounting` and its schema contract before `/ready` can return HTTP 200.
- A read-only query against production Neon confirmed these required predicates are all false: migration 048 recorded; `purchase_approval_limits` present; approval guard present; purchase-receipt journal function present; supplier journal function present.
- Render application logs on 2026-10-26 continue to emit `phase7_release_schema_not_ready`.
- The readiness gate is valid. It must not be weakened or changed to `/health` to disguise the missing production schema.
- No production migration, environment change, or deployment was executed during this pass.

## 3. Isolated replay branch results

On the isolated replay branch (`LEXA-PHASE7-REPLAY-20261022`, branch `lexa-inventory-overlay-replay-20261025`):

- All ten read-only checks matching the deployed Phase 7 readiness gate passed: migration 048, approval table, approval guard, receipt/supplier journal functions, forced RLS, tenant policy, receipt journal trigger, supplier journal trigger, and return reversal columns.
- The traceability overlay schema/migration and trigger smoke tests from the previous validation pass remain isolated from production.
- The two synthetic QA tenants still have **0 sales, 0 payments, 0 journal entries, and 0 outbox events each**. This is schema/trigger validation only, not an authenticated transaction test.

## 4. Overlay contract checks rerun in this pass

- Python byte-compilation of both overlay installers: passed.
- Static overlay contract tests: passed (12 checks).
- Tracked-workflow contract tests: passed (20 checks).
- ZIP integrity test: passed.
- This proves static contract presence and archive integrity only. It does not prove the patched full application builds or that business transactions succeed.

## 5. Acceptance matrix

| Gate | Current result | Evidence needed to turn green |
|---|---|---|
| Product setup → stock receipt → checkout → stock/COGS | NOT PROVEN | Authenticated test using canonical receiving and checkout endpoints; verify exactly one inventory movement per source line |
| Payment / receivable and sale idempotency | NOT PROVEN | Retry the same sale and payment idempotency keys; exactly one sale, payment allocation, journal pair and receipt |
| Balanced journals and customer reconciliation | NOT PROVEN | Assert debit = credit by currency and opening + charges − allocations − credits = closing customer balance |
| LEXA receipt, tax-support records, audit and analytics | NOT PROVEN | Read back records and outbox event; every record must retain the originating transaction ID and source reference |
| Partial payments and credit sales | NOT PROVEN | Exercise both through authenticated API/UI and reconcile residual receivables |
| Returns, refunds, corrections and reversals | NOT PROVEN | Exercise each canonical workflow; no duplicate stock or financial postings; preserve original source links |
| Restricted financial access | NOT PROVEN | Negative tenant/branch/role tests for unauthorized reads and writes |
| API test suite, frontend typecheck/build, clean replay through 051 | NOT RUN | CI on the integrated source after migration-history reconciliation |
| Production `/ready` | RED | Apply the approved Phase 7 migration after pre-production replay and acceptance pass, then re-check `/ready` |

## 6. Safe next sequence

1. Reconcile the canonical migration history on the working branch through 048, including source files, clean-replay manifest and checksums. The current recovery gate must not be bypassed.
2. Integrate migrations 049–051 and their guarded API/frontend patches on the same coherent source state.
3. Run the repository CI suites: full API tests, Python compile, frontend typecheck/contracts/production build, and clean database replay with RLS/least-privilege checks.
4. Execute authenticated staging E2E scenarios for checkout, payment/receivable, balanced journals, source-linked receipt/tax/audit/outbox/analytics, retries, partial payment, credit sale, return/refund/reversal/correction, and tenant/branch/role isolation.
5. Only after all pre-production gates pass, apply approved migrations to production and deploy the matching source. Then verify `/ready` returns HTTP 200 and re-run read-only reconciliation checks.

**No green status is claimed until these business acceptance tests pass.** No production database or deployment has been changed in this validation pass.
