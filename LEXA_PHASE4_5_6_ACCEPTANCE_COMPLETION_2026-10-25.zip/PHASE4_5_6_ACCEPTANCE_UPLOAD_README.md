# LEXA Phase 4–6 Acceptance Completion Overlay

**Prepared against:** `MONALISA2003-CMD/LEXA-` `main` at `b56cde4df204aadb4bfb06c7859ec4c704afde3b` (25 October 2026).

This is a repository-root overlay ZIP for LEXA's ZIP Extractor. Keep `main` selected and upload the ZIP at the repository root; do not unzip it on the phone.

## Scope

The audit found Phase 4 reporting and currency safeguards, Phase 5 sales/returns and accounting coverage, and Phase 6 stock workflows already present on `main`. The latest CI baseline run `40178105004` passed its API contracts, frontend typecheck/contracts/production build, and Docker/HAProxy jobs. This package adds permanent acceptance contracts and an isolated staging workflow test for the gaps in the Phase 4–6 completeness matrix—especially the stock-changing Phase 6 workflows that were not exercised by the earlier authenticated browser test.

### Added files

- `apps/api/tests/test_phase4_5_6_inventory_acceptance_contract.py` — source-level guards for reports, sale/return accounting, adjustments, count variance, transfer reconciliation, idempotency, immutable ledger semantics, valuation, stock ageing and movement health.
- `apps/web/tests/phase4-6-inventory-workflows.test.mjs` — Node contracts connecting those backend rules to the frontend API and visible inventory views.
- `apps/web/e2e/phase6-inventory-workflows-acceptance.spec.ts` — authenticated end-to-end test for a disposable staging tenant. The overlay also registers this spec in `playwright.config.ts` and extends `test:e2e:phase6` to execute both the existing inventory-intelligence test and this workflow acceptance test; It covers adjustment and stock-count posting; source/destination transfer quantities and inbound clearing; same-key create replay and changed-payload rejection; duplicate posting/dispatch/receipt non-mutation; insufficient-stock failure; restricted-location access; ledger history, valuation and reconciliation.

## Safe test behavior

The new Playwright workflow test is deliberately skipped unless all of these are supplied: `LEXA_PHASE6_ALLOW_STAGING_WRITES=1`, an HTTPS staging hostname in `LEXA_PHASE6_STAGING_HOSTS`, a `LEXA_PHASE6_STORAGE_STATE` path, and a disposable `LEXA_PHASE6_ACCEPTANCE_FIXTURE_JSON` with two accessible locations, one restricted location, and a tracked variant. Production hosts are explicitly rejected. No live database or production writes are part of this ZIP.

## Existing scope preserved

- Phase 4: explicit report-period application/validation, business currency, and unavailable-versus-zero messaging.
- Phase 5: server-owned taxes, role-checked checkout and discounts, partial/credit sales, return/refund caps and accounting/COGS links. Fiscal documents remain manual; no EFRIS API, payment gateway, or mobile-money integration is introduced.
- Phase 6: ledger-based adjustments, variance-based count reconciliation, source/destination transfer postings, location-level weighted-average valuation, stock ageing with unknown provenance clearly separated, and movement-health exceptions.

## Verification boundary

The latest existing GitHub CI baseline is green, but that status predates this overlay. Before calling this ZIP green, the new API and frontend contracts must pass on the commit produced by the ZIP Extractor. The Playwright write-flow requires the explicitly isolated staging fixture and is not evidence of production readiness. Local checks on the overlay: Python test-file compilation passed, Node contract-test syntax passed, TypeScript transpile syntax passed with zero diagnostics, and ZIP integrity/path checks passed. The current GitHub workflow has not run against these new files yet, so no candidate-specific green build is claimed. No production migration, commit, or deployment was performed by preparing this package.
