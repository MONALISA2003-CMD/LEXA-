import { expect, test } from '@playwright/test';

type Fixture = {
  environment: 'staging';
  disposable_scope: true;
  reset_strategy: 'dispose_test_tenant';
  actor_role: 'owner' | 'administrator' | 'manager';
  location_id: string;
  destination_location_id: string;
  restricted_location_id: string;
  variant_id: string;
};

const baseUrl = process.env.LEXA_BROWSER_BASE_URL || '';
const rawFixture = process.env.LEXA_PHASE6_ACCEPTANCE_FIXTURE_JSON || '';
let fixture: Fixture | null = null;
try { fixture = rawFixture ? JSON.parse(rawFixture) as Fixture : null; } catch { fixture = null; }
let baseHost = '';
try { baseHost = baseUrl ? new URL(baseUrl).hostname.toLowerCase() : ''; } catch { baseHost = ''; }
const allowedHosts = (process.env.LEXA_PHASE6_STAGING_HOSTS || '').split(',').map((item) => item.trim().toLowerCase()).filter(Boolean);
const storageState = process.env.LEXA_PHASE6_STORAGE_STATE || '';
const productionHosts = new Set(['lexa-green.vercel.app', 'lexa-n10e.onrender.com']);
const explicitlySafe = process.env.LEXA_PHASE6_ALLOW_STAGING_WRITES === '1'
  && fixture?.environment === 'staging'
  && fixture?.disposable_scope === true
  && fixture?.reset_strategy === 'dispose_test_tenant'
  && !productionHosts.has(baseHost)
  && allowedHosts.includes(baseHost)
  && Boolean(storageState)
  && Boolean(fixture?.location_id && fixture?.destination_location_id && fixture?.restricted_location_id && fixture?.variant_id)
  && fixture?.location_id !== fixture?.destination_location_id
  && fixture?.location_id !== fixture?.restricted_location_id
  && fixture?.destination_location_id !== fixture?.restricted_location_id;
const apiRoot = `${baseUrl.replace(/\/$/, '')}/api/lexa/api/v1`;
let liveAuthHeader = '';
function authHeaders() { return liveAuthHeader ? { Authorization: liveAuthHeader } : {}; }
function requestKey(label: string) { return `phase6-${label}-${crypto.randomUUID()}`; }

type ApiReply = { response: import('@playwright/test').APIResponse; body: any };
async function requestJson(
  page: import('@playwright/test').Page,
  method: 'GET' | 'POST' | 'PATCH',
  path: string,
  data?: unknown,
  idempotencyKey?: string,
): Promise<ApiReply> {
  const headers = {
    ...authHeaders(),
    ...(data !== undefined ? { 'Content-Type': 'application/json' } : {}),
    ...(idempotencyKey ? { 'Idempotency-Key': idempotencyKey } : {}),
  };
  const url = `${apiRoot}${path}`;
  const options = { headers, ...(data !== undefined ? { data } : {}) };
  const response = method === 'GET'
    ? await page.request.get(url, { headers })
    : method === 'PATCH'
      ? await page.request.patch(url, options)
      : await page.request.post(url, options);
  return { response, body: await response.json().catch(() => null) };
}
function qty(value: unknown, label: string): number {
  const result = Number(value);
  expect(Number.isFinite(result), `${label} must be numeric`).toBe(true);
  return result;
}
async function readBalance(page: import('@playwright/test').Page, locationId: string, variantId: string) {
  const query = new URLSearchParams({ location_id: locationId, variant_id: variantId, limit: '500' });
  const { response, body } = await requestJson(page, 'GET', `/inventory/balances?${query}`);
  expect(response.status(), `balance at location ${locationId} can be read`).toBe(200);
  expect(Array.isArray(body)).toBe(true);
  const row = (body as Array<Record<string, any>>).find((item) => item.location_id === locationId && item.variant_id === variantId);
  if (!row) return { on_hand: 0, reserved: 0, available: 0, inbound: 0, average_cost: 0, stock_value: 0 };
  return {
    on_hand: qty(row.on_hand, 'on_hand'), reserved: qty(row.reserved ?? 0, 'reserved'),
    available: qty(row.available ?? qty(row.on_hand, 'on_hand') - qty(row.reserved ?? 0, 'reserved'), 'available'),
    inbound: qty(row.inbound ?? 0, 'inbound'), average_cost: qty(row.average_cost ?? 0, 'average_cost'),
    stock_value: qty(row.stock_value ?? 0, 'stock_value'),
  };
}
async function readLedger(page: import('@playwright/test').Page, locationId: string, variantId: string) {
  const query = new URLSearchParams({ location_id: locationId, variant_id: variantId, limit: '500' });
  const { response, body } = await requestJson(page, 'GET', `/inventory/ledger?${query}`);
  expect(response.status(), 'inventory ledger is readable').toBe(200);
  expect(Array.isArray(body)).toBe(true);
  return body as Array<Record<string, any>>;
}
async function readIntegrity(page: import('@playwright/test').Page) {
  const { response, body } = await requestJson(page, 'GET', '/inventory/integrity');
  expect(response.status(), 'inventory reconciliation endpoint is readable').toBe(200);
  return body as { status: string; checked: number; mismatches: unknown[] };
}

// This test intentionally performs writes only on a separately approved,
// disposable staging tenant. It must never be pointed at production.
test.describe('Phase 6 stock movement, count, transfer and valuation acceptance (isolated staging only)', () => {
  test.skip(!explicitlySafe, 'Requires an approved HTTPS staging host, disposable tenant, two writable locations, a restricted third location, and LEXA_PHASE6_ALLOW_STAGING_WRITES=1.');

  test('adjustment, count reconciliation, transfer, duplicate replay, shortage and access boundaries', async ({ page }) => {
    const data = fixture!;
    expect(['owner', 'administrator', 'manager']).toContain(data.actor_role);
    expect(new URL(baseUrl).protocol).toBe('https:');

    page.on('request', (request) => {
      const authorization = request.headers()['authorization'];
      if (authorization?.startsWith('Bearer ') && request.url().includes('/api/lexa/api/v1/')) liveAuthHeader = authorization;
    });
    const inventoryWait = page.waitForResponse((response) => response.url().includes('/api/lexa/api/v1/inventory/balances') && response.status() === 200, { timeout: 20_000 });
    await page.goto('/inventory');
    await inventoryWait;
    await expect(page.getByText(/inventory/i).first()).toBeVisible();
    expect(liveAuthHeader.startsWith('Bearer '), 'the authenticated workspace supplied a bearer token').toBe(true);
    const identity = await requestJson(page, 'GET', '/auth/me');
    expect(identity.response.status(), 'current workspace identity is available').toBe(200);
    const actualPermissions = new Set((identity.body?.permissions ?? []) as string[]);
    for (const permission of [
      'inventory.read', 'inventory.manage', 'inventory.adjust.approve', 'inventory.adjust.post',
      'inventory.count.manage', 'inventory.count.approve', 'inventory.count.post',
      'inventory.transfer.create', 'inventory.transfer.approve', 'inventory.transfer.dispatch',
      'inventory.transfer.receive', 'inventory.transfer.complete',
    ]) {
      expect(actualPermissions.has(permission), `staging actor has ${permission}`).toBe(true);
    }

    const initialIntegrity = await readIntegrity(page);
    expect(initialIntegrity.status, 'fixture starts reconciled').toBe('ok');
    const sourceBefore = await readBalance(page, data.location_id, data.variant_id);
    const destinationBefore = await readBalance(page, data.destination_location_id, data.variant_id);
    const sourceLedgerBefore = await readLedger(page, data.location_id, data.variant_id);
    const destinationLedgerBefore = await readLedger(page, data.destination_location_id, data.variant_id);

    // Positive adjustment establishes a controlled known-cost movement, then tests replay.
    const adjustmentPayload = {
      location_id: data.location_id,
      reason_code: 'PHASE6_ACCEPTANCE_SEED',
      notes: 'Disposable Phase 6 stock acceptance fixture only',
      lines: [{ variant_id: data.variant_id, quantity_delta: '20', unit_cost: '17.25', notes: 'known cost receipt' }],
    };
    const adjustmentKey = requestKey('adjust-create');
    const createdAdjustment = await requestJson(page, 'POST', '/inventory/adjustments', adjustmentPayload, adjustmentKey);
    expect(createdAdjustment.response.status()).toBe(200);
    expect(createdAdjustment.body.status).toBe('DRAFT');
    const replayAdjustment = await requestJson(page, 'POST', '/inventory/adjustments', adjustmentPayload, adjustmentKey);
    expect(replayAdjustment.response.status()).toBe(200);
    expect(replayAdjustment.body.id).toBe(createdAdjustment.body.id);
    const changedPayloadReplay = await requestJson(page, 'POST', '/inventory/adjustments', {
      ...adjustmentPayload, lines: [{ variant_id: data.variant_id, quantity_delta: '21', unit_cost: '17.25' }],
    }, adjustmentKey);
    expect(changedPayloadReplay.response.status(), 'same key with changed payload is rejected').toBe(409);

    const adjustmentApproval = await requestJson(page, 'POST', `/inventory/adjustments/${createdAdjustment.body.id}/approve`, {}, requestKey('adjust-approve'));
    expect(adjustmentApproval.response.status()).toBe(200);
    expect(adjustmentApproval.body.status).toBe('APPROVED');
    const adjustmentPostKey = requestKey('adjust-post');
    const adjustmentPosted = await requestJson(page, 'POST', `/inventory/adjustments/${createdAdjustment.body.id}/post`, {}, adjustmentPostKey);
    expect(adjustmentPosted.response.status()).toBe(200);
    expect(adjustmentPosted.body.status).toBe('POSTED');
    const adjustmentPostReplay = await requestJson(page, 'POST', `/inventory/adjustments/${createdAdjustment.body.id}/post`, {}, adjustmentPostKey);
    expect(adjustmentPostReplay.response.status(), 'a stale repeat cannot post the same adjustment again').toBe(409);
    expect(adjustmentPostReplay.body.detail).toMatch(/cannot be posted|POSTED/i);
    const afterAdjustment = await readBalance(page, data.location_id, data.variant_id);
    expect(afterAdjustment.on_hand).toBeCloseTo(sourceBefore.on_hand + 20, 5);
    const expectedWeightedAverage = sourceBefore.on_hand > 0
      ? ((sourceBefore.on_hand * sourceBefore.average_cost) + (20 * 17.25)) / (sourceBefore.on_hand + 20)
      : 17.25;
    expect(afterAdjustment.average_cost).toBeCloseTo(expectedWeightedAverage, 4);
    expect(afterAdjustment.stock_value).toBeCloseTo(afterAdjustment.on_hand * afterAdjustment.average_cost, 4);
    expect((await readLedger(page, data.location_id, data.variant_id)).filter((row) => row.reference_id === createdAdjustment.body.id && row.transaction_type === 'ADJUSTMENT')).toHaveLength(1);

    // Count workflow: expected quantity is snapshotted, counted quantity is entered,
    // and only a non-zero variance is posted to the permanent stock ledger.
    const countCreated = await requestJson(page, 'POST', '/inventory/stock-counts', {
      location_id: data.location_id, scope_description: 'Phase 6 acceptance count', variant_ids: [data.variant_id],
    }, requestKey('count-create'));
    expect(countCreated.response.status()).toBe(200);
    expect(countCreated.body.status).toBe('COUNTING');
    const countedQuantity = afterAdjustment.on_hand + 2;
    const countLines = { lines: [{ variant_id: data.variant_id, counted_quantity: String(countedQuantity) }] };
    const countUpdated = await requestJson(page, 'PATCH', `/inventory/stock-counts/${countCreated.body.id}/lines`, countLines);
    expect(countUpdated.response.status()).toBe(200);
    const countSubmitted = await requestJson(page, 'POST', `/inventory/stock-counts/${countCreated.body.id}/submit`, {}, requestKey('count-submit'));
    expect(countSubmitted.response.status()).toBe(200);
    expect(countSubmitted.body.status).toBe('SUBMITTED');
    const countApproved = await requestJson(page, 'POST', `/inventory/stock-counts/${countCreated.body.id}/approve`, {}, requestKey('count-approve'));
    expect(countApproved.response.status()).toBe(200);
    expect(countApproved.body.status).toBe('APPROVED');
    const countPosted = await requestJson(page, 'POST', `/inventory/stock-counts/${countCreated.body.id}/post`, {}, requestKey('count-post'));
    expect(countPosted.response.status()).toBe(200);
    expect(countPosted.body.status).toBe('POSTED');
    const afterCount = await readBalance(page, data.location_id, data.variant_id);
    expect(afterCount.on_hand).toBeCloseTo(countedQuantity, 5);
    expect((await readLedger(page, data.location_id, data.variant_id)).filter((row) => row.reference_id === countCreated.body.id && row.transaction_type === 'COUNT_RECONCILIATION')).toHaveLength(1);

    // Transfer is a two-sided ledger move: dispatch reduces source and records
    // destination inbound; receipt preserves the sending cost and clears inbound.
    const transferQuantity = 3;
    const transferPayload = {
      source_location_id: data.location_id, destination_location_id: data.destination_location_id,
      notes: 'Phase 6 acceptance transfer', lines: [{ variant_id: data.variant_id, quantity: String(transferQuantity) }],
    };
    const transferKey = requestKey('transfer-create');
    const transferCreated = await requestJson(page, 'POST', '/inventory/transfers', transferPayload, transferKey);
    expect(transferCreated.response.status()).toBe(200);
    expect(transferCreated.body.status).toBe('DRAFT');
    const transferReplay = await requestJson(page, 'POST', '/inventory/transfers', transferPayload, transferKey);
    expect(transferReplay.response.status()).toBe(200);
    expect(transferReplay.body.id).toBe(transferCreated.body.id);
    const transferApproved = await requestJson(page, 'POST', `/inventory/transfers/${transferCreated.body.id}/approve`, {}, requestKey('transfer-approve'));
    expect(transferApproved.response.status()).toBe(200);
    const transferDispatchKey = requestKey('transfer-dispatch');
    const transferDispatched = await requestJson(page, 'POST', `/inventory/transfers/${transferCreated.body.id}/dispatch`, {}, transferDispatchKey);
    expect(transferDispatched.response.status()).toBe(200);
    expect(transferDispatched.body.status).toBe('DISPATCHED');
    const transferDispatchReplay = await requestJson(page, 'POST', `/inventory/transfers/${transferCreated.body.id}/dispatch`, {}, transferDispatchKey);
    expect(transferDispatchReplay.response.status(), 'a stale repeat cannot dispatch a transfer twice').toBe(409);
    const sourceAfterDispatch = await readBalance(page, data.location_id, data.variant_id);
    const destinationInTransit = await readBalance(page, data.destination_location_id, data.variant_id);
    expect(sourceAfterDispatch.on_hand).toBeCloseTo(afterCount.on_hand - transferQuantity, 5);
    expect(destinationInTransit.inbound).toBeCloseTo(destinationBefore.inbound + transferQuantity, 5);

    const receivePayload = { lines: [{ variant_id: data.variant_id, counted_quantity: String(transferQuantity) }] };
    const transferReceiveKey = requestKey('transfer-receive');
    const transferReceived = await requestJson(page, 'POST', `/inventory/transfers/${transferCreated.body.id}/receive`, receivePayload, transferReceiveKey);
    expect(transferReceived.response.status()).toBe(200);
    expect(transferReceived.body.status).toBe('RECEIVED');
    const transferReceiveReplay = await requestJson(page, 'POST', `/inventory/transfers/${transferCreated.body.id}/receive`, receivePayload, transferReceiveKey);
    expect(transferReceiveReplay.response.status(), 'a stale repeat cannot receive the same stock twice').toBe(409);
    const transferCompleted = await requestJson(page, 'POST', `/inventory/transfers/${transferCreated.body.id}/complete`, {}, requestKey('transfer-complete'));
    expect(transferCompleted.response.status()).toBe(200);
    expect(transferCompleted.body.status).toBe('COMPLETED');

    const sourceAfterTransfer = await readBalance(page, data.location_id, data.variant_id);
    const destinationAfterTransfer = await readBalance(page, data.destination_location_id, data.variant_id);
    expect(sourceAfterTransfer.on_hand).toBeCloseTo(afterCount.on_hand - transferQuantity, 5);
    expect(destinationAfterTransfer.on_hand).toBeCloseTo(destinationBefore.on_hand + transferQuantity, 5);
    expect(destinationAfterTransfer.inbound).toBeCloseTo(destinationBefore.inbound, 5);
    expect(destinationAfterTransfer.average_cost).toBeGreaterThan(0);
    expect(destinationAfterTransfer.stock_value).toBeCloseTo(destinationAfterTransfer.on_hand * destinationAfterTransfer.average_cost, 4);
    const sourceLedgerAfter = await readLedger(page, data.location_id, data.variant_id);
    const destinationLedgerAfter = await readLedger(page, data.destination_location_id, data.variant_id);
    const transferOutRows = sourceLedgerAfter.filter((row) => row.reference_id === transferCreated.body.id && row.transaction_type === 'TRANSFER_OUT');
    const transferInRows = destinationLedgerAfter.filter((row) => row.reference_id === transferCreated.body.id && row.transaction_type === 'TRANSFER_IN');
    expect(transferOutRows).toHaveLength(1);
    expect(transferInRows).toHaveLength(1);
    expect(qty(transferInRows[0].unit_cost, 'transfer-in unit cost')).toBeCloseTo(qty(transferOutRows[0].unit_cost, 'transfer-out unit cost'), 6);
    expect(qty(transferInRows[0].total_cost, 'transfer-in total cost')).toBeCloseTo(qty(transferOutRows[0].total_cost, 'transfer-out total cost'), 4);
    expect(sourceLedgerAfter.length).toBeGreaterThan(sourceLedgerBefore.length);
    expect(destinationLedgerAfter.length).toBeGreaterThan(destinationLedgerBefore.length);

    // Rejection must be atomic: an impossible dispatch cannot alter either stock or ledger.
    const shortagePayload = {
      source_location_id: data.location_id, destination_location_id: data.destination_location_id,
      notes: 'Expected insufficient-stock rejection',
      lines: [{ variant_id: data.variant_id, quantity: String(sourceAfterTransfer.on_hand + 1000) }],
    };
    const shortageCreated = await requestJson(page, 'POST', '/inventory/transfers', shortagePayload, requestKey('shortage-create'));
    expect(shortageCreated.response.status()).toBe(200);
    const shortageApproved = await requestJson(page, 'POST', `/inventory/transfers/${shortageCreated.body.id}/approve`, {}, requestKey('shortage-approve'));
    expect(shortageApproved.response.status()).toBe(200);
    const sourceBeforeRejectedDispatch = await readBalance(page, data.location_id, data.variant_id);
    const destinationBeforeRejectedDispatch = await readBalance(page, data.destination_location_id, data.variant_id);
    const ledgerBeforeRejectedDispatch = await readLedger(page, data.location_id, data.variant_id);
    const destinationLedgerBeforeRejectedDispatch = await readLedger(page, data.destination_location_id, data.variant_id);
    const rejectedDispatch = await requestJson(page, 'POST', `/inventory/transfers/${shortageCreated.body.id}/dispatch`, {}, requestKey('shortage-dispatch'));
    expect(rejectedDispatch.response.status(), 'insufficient stock must fail closed').toBe(409);
    expect(await readBalance(page, data.location_id, data.variant_id)).toEqual(sourceBeforeRejectedDispatch);
    expect(await readBalance(page, data.destination_location_id, data.variant_id)).toEqual(destinationBeforeRejectedDispatch);
    expect((await readLedger(page, data.location_id, data.variant_id)).map((row) => String(row.id)).sort()).toEqual(ledgerBeforeRejectedDispatch.map((row) => String(row.id)).sort());
    expect((await readLedger(page, data.destination_location_id, data.variant_id)).map((row) => String(row.id)).sort()).toEqual(destinationLedgerBeforeRejectedDispatch.map((row) => String(row.id)).sort());

    const unauthorizedTransfer = await requestJson(page, 'POST', '/inventory/transfers', {
      source_location_id: data.location_id, destination_location_id: data.restricted_location_id,
      lines: [{ variant_id: data.variant_id, quantity: '1' }],
    }, requestKey('unauthorized-transfer'));
    expect([403, 404], 'a branch outside the actor scope must not receive inventory').toContain(unauthorizedTransfer.response.status());

    const finalIntegrity = await readIntegrity(page);
    expect(finalIntegrity.status, 'all successful stock movements balance to the immutable ledger').toBe('ok');
    const ageing = await requestJson(page, 'GET', `/inventory/ageing?${new URLSearchParams({ location_id: data.location_id, limit: '500' })}`);
    expect(ageing.response.status()).toBe(200);
    expect(ageing.body.source).toBe('inventory_ledger_and_balance_projection');
    expect(String(ageing.body.age_method)).toMatch(/not batch\/serial tracking or FIFO accounting valuation/i);
    expect(Array.isArray(ageing.body.items)).toBe(true);
    const ageRow = (ageing.body.items as Array<Record<string, any>>).find((item) => item.location_id === data.location_id && item.variant_id === data.variant_id);
    expect(ageRow, 'the stock movement is visible in ageing output').toBeTruthy();
    for (const field of ['aged_over_30', 'aged_over_60', 'aged_over_90', 'unknown_age_quantity', 'traceable_remaining', 'on_hand', 'average_cost', 'stock_value']) {
      expect(qty(ageRow![field], `ageing ${field}`), `${field} is a non-negative numeric measure`).toBeGreaterThanOrEqual(0);
    }
    expect(typeof ageRow!.reconciliation_gap).toBe('boolean');
    expect(['RECONCILIATION_GAP', 'UNKNOWN_AGE_PRESENT', 'TRACEABLE']).toContain(ageRow!.age_status);
    expect(qty(ageRow!.stock_value, 'ageing stock value')).toBeCloseTo(qty(ageRow!.on_hand, 'ageing on hand') * qty(ageRow!.average_cost, 'ageing average cost'), 4);
    const health = await requestJson(page, 'GET', `/inventory/movement-health?${new URLSearchParams({ location_id: data.location_id, limit: '500' })}`);
    expect(health.response.status()).toBe(200);
    expect(health.body.source).toBe('completed_sales_returns_and_inventory_balances');
  });
});
