import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";

const root = new URL("../", import.meta.url);
const apiRoot = new URL("../../../apps/api/app/", import.meta.url);
const api = fs.readFileSync(new URL("lib/api.ts", root), "utf8");
const inventory = fs.readFileSync(new URL("app/inventory/page.tsx", root), "utf8");
const reports = fs.readFileSync(new URL("app/reports/page.tsx", root), "utf8");
const ledger = fs.readFileSync(new URL("routes/inventory.py", apiRoot), "utf8");
const helper = fs.readFileSync(new URL("inventory.py", apiRoot), "utf8");
const commerce = fs.readFileSync(new URL("routes/commerce.py", apiRoot), "utf8");

test("Phase 4 reporting uses an explicit period action and known business currency", () => {
  assert.match(reports, /Show these dates/);
  assert.match(reports, /nextFrom > nextTo/);
  assert.match(reports, /getBusinessProfile\(\)/);
  assert.match(reports, /currency: currencyCode/);
  assert.match(reports, /Unavailable/);
  assert.match(reports, /No records/);
});

test("Phase 5 checkout and return flows retain replay safety and COGS journals", () => {
  assert.match(commerce, /IDEMPOTENCY_KEY_REQUIRED/);
  assert.match(commerce, /post_sale_journal\(:id,:u\)/);
  assert.match(commerce, /post_sale_cogs_journal\(:id,:u\)/);
  assert.match(commerce, /post_sale_return_cogs_journal\(:id,:u\)/);
  assert.match(commerce, /remaining_refund_balance\(gross_collected,prior_refunds\)/);
});

test("inventory page and API expose adjustment, stock count, transfer, ageing, ledger and reconciliation workflows", () => {
  for (const name of ["createAdjustment", "approveAdjustment", "postAdjustment", "createStockCount", "updateCountLines", "submitStockCount", "approveStockCount", "postStockCount", "createTransfer", "approveTransfer", "dispatchTransfer", "receiveTransfer", "completeTransfer"]) {
    assert.match(api, new RegExp(`export function ${name}\\(`));
  }
  assert.match(api, /getInventoryLedger/);
  assert.match(api, /getInventoryAgeing/);
  assert.match(api, /getInventoryIntegrity/);
  assert.match(api, /Idempotency-Key/);
  assert.match(inventory, /Age of stock/);
  assert.match(inventory, /Stock Health/);
  assert.match(inventory, /Review difference/);
  assert.match(inventory, /Unknown age/);
});

test("inventory posting preserves the ledger and recomputes moving-average valuation safely", () => {
  assert.match(helper, /def weighted_average_cost/);
  assert.match(helper, /balance\.average_cost = new_avg/);
  assert.match(helper, /balance\.stock_value = q\(new_qty \* new_avg\)/);
  assert.match(helper, /total_cost=q\(abs\(quantity_delta\) \* \(unit_cost if quantity_delta > 0 else old_avg\)\)/);
  assert.match(ledger, /@router\.get\("\/ledger"/);
  assert.match(ledger, /@router\.get\("\/integrity"/);
  assert.match(ledger, /COUNT_RECONCILIATION/);
  assert.match(ledger, /TRANSFER_OUT/);
  assert.match(ledger, /TRANSFER_IN/);
  assert.match(ledger, /Insufficient stock for transfer line/);
});

 test("ageing clearly separates unknown provenance from traceable stock and is not accounting FIFO", () => {
  const ageing = ledger.split('@router.get("/ageing")', 2)[1]?.split('@router.post("/rebuild"', 1)[0] ?? "";
  const movement = ledger.split('@router.get("/movement-health")', 2)[1]?.split('@router.get("/ageing")', 1)[0] ?? "";
  assert.match(ageing, /unknown_age_quantity/);
  assert.match(ageing, /aged_over_30/);
  assert.match(ageing, /aged_over_60/);
  assert.match(ageing, /aged_over_90/);
  assert.match(ageing, /not an accounting FIFO valuation/);
  assert.match(movement, /OUT_OF_STOCK_WITH_RECENT_DEMAND/);
  assert.match(movement, /NO_SALE_90D/);
  assert.match(movement, /units_sold_30d/);
  assert.match(movement, /units_returned_30d/);
});
