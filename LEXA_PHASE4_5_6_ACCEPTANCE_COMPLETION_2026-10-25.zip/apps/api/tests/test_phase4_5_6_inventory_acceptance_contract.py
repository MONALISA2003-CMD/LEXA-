"""Regression contracts for Phase 4 reporting, Phase 5 commerce, and Phase 6 stock acceptance.

These source contracts complement runtime API tests and isolated staging Playwright E2E;
they intentionally do not claim to replace a disposable PostgreSQL replay or staging run.
"""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
API = ROOT / "apps" / "api" / "app"


def section(source: str, start: str, end: str) -> str:
    assert start in source, f"missing source section: {start}"
    assert end in source, f"missing source section terminator: {end}"
    return source.split(start, 1)[1].split(end, 1)[0]


def test_phase4_reports_keep_period_and_currency_semantics_explicit():
    reports = (ROOT / "apps/web/app/reports/page.tsx").read_text(encoding="utf-8")
    analytics = (API / "routes/analytics.py").read_text(encoding="utf-8")
    assert "Show these dates" in reports
    assert "nextFrom > nextTo" in reports
    assert "getBusinessProfile()" in reports
    assert "currency: currencyCode" in reports
    assert "Unavailable" in reports and "No records" in reports
    assert "Shows current stock, not stock as it was on the selected dates" in reports
    assert 'currency_code: str = Query(...' in analytics
    assert 'currency_code: str = Query(default="UGX"' not in analytics


def test_phase5_sales_and_returns_keep_accounting_cogs_and_manual_tax_fences():
    commerce = (API / "routes/commerce.py").read_text(encoding="utf-8")
    sale = section(commerce, '@router.post("/sales", status_code=201)', '@router.get("/receivables")')
    returns = commerce.split('@router.post("/sales/{sale_id}/returns", status_code=201)', 1)[1]
    assert 'IDEMPOTENCY_KEY_REQUIRED' in sale
    assert 'calculate_line_tax(' in sale
    assert 'post_sale_journal(:id,:u)' in sale
    assert 'post_sale_cogs_journal(:id,:u)' in sale
    assert 'result["fiscal_document_id"] = None' in sale
    assert 'result["fiscalization_status"] = "MANUAL_REQUIRED"' in sale
    assert 'remaining_refund_balance(gross_collected,prior_refunds)' in returns
    assert 'post_sale_return_journal(:id,:u)' in returns
    assert 'post_sale_return_cogs_journal(:id,:u)' in returns
    assert 'db.rollback()' in returns


def test_adjustments_require_authorization_and_post_audited_ledger_movements():
    route = (API / "routes/inventory.py").read_text(encoding="utf-8")
    helper = (API / "inventory.py").read_text(encoding="utf-8")
    create = section(route, '@router.post("/adjustments")', '@router.post("/adjustments/{adjustment_id}/approve")')
    approve = section(route, '@router.post("/adjustments/{adjustment_id}/approve")', '@router.post("/adjustments/{adjustment_id}/post")')
    post = section(route, '@router.post("/adjustments/{adjustment_id}/post")', '@router.post("/stock-counts")')
    assert 'Depends(require_permission("inventory.manage"))' in create
    assert 'ensure_location_access' in create
    assert 'Adjustment cannot contain the same variant twice' in create
    assert 'Positive adjustment requires a unit cost' in create
    assert 'Depends(require_permission("inventory.adjust.approve"))' in approve
    assert 'row.status != "DRAFT"' in approve and 'row.status = "APPROVED"' in approve
    assert 'Depends(require_permission("inventory.adjust.post"))' in post
    assert 'row.status != "APPROVED"' in post and 'row.status = "POSTED"' in post
    assert 'post_ledger(' in post and 'transaction_type="ADJUSTMENT"' in post
    assert 'write_audit(' in post and 'emit_event(' in post
    assert 'new_qty < 0' in helper and 'Insufficient available stock' in helper
    assert 'balance.stock_value = q(new_qty * new_avg)' in helper


def test_stock_count_requires_complete_count_before_approval_and_posts_only_variance():
    route = (API / "routes/inventory.py").read_text(encoding="utf-8")
    create = section(route, '@router.post("/stock-counts")', '@router.patch("/stock-counts/{count_id}/lines")')
    update = section(route, '@router.patch("/stock-counts/{count_id}/lines")', '@router.post("/stock-counts/{count_id}/submit")')
    submit = section(route, '@router.post("/stock-counts/{count_id}/submit")', '@router.post("/stock-counts/{count_id}/approve")')
    approve = section(route, '@router.post("/stock-counts/{count_id}/approve")', '@router.post("/stock-counts/{count_id}/post")')
    post = section(route, '@router.post("/stock-counts/{count_id}/post")', '@router.get("/transfers")')
    assert 'Depends(require_permission("inventory.count.manage"))' in create
    assert 'Stock count cannot contain duplicate variants' in create
    assert 'ensure_location_access' in update
    assert 'count.status != "COUNTING"' in update
    assert 'Every stock count line must have a counted quantity before submission' in submit
    assert 'row.status != "COUNTING"' in submit and 'row.status = "SUBMITTED"' in submit
    assert 'Depends(require_permission("inventory.count.approve"))' in approve
    assert 'row.status != "SUBMITTED"' in approve and 'row.status = "APPROVED"' in approve
    assert 'Depends(require_permission("inventory.count.post"))' in post
    assert 'row.status != "APPROVED"' in post and 'row.status = "POSTED"' in post
    assert 'if variance:' in post and 'transaction_type="COUNT_RECONCILIATION"' in post


def test_transfers_reconcile_both_locations_and_preserve_in_transit_cost():
    route = (API / "routes/inventory.py").read_text(encoding="utf-8")
    create = section(route, '@router.post("/transfers")', '@router.post("/transfers/{transfer_id}/approve")')
    approve = section(route, '@router.post("/transfers/{transfer_id}/approve")', '@router.post("/transfers/{transfer_id}/dispatch")')
    dispatch = section(route, '@router.post("/transfers/{transfer_id}/dispatch")', '@router.post("/transfers/{transfer_id}/receive")')
    receive = section(route, '@router.post("/transfers/{transfer_id}/receive")', '@router.post("/transfers/{transfer_id}/complete")')
    complete = section(route, '@router.post("/transfers/{transfer_id}/complete")', '@router.get("/variant-options")')
    assert 'body.source_location_id == body.destination_location_id' in create
    assert 'tenant_location(db, tenant_id, body.source_location_id)' in create
    assert 'tenant_location(db, tenant_id, body.destination_location_id)' in create
    assert create.count('ensure_location_access') >= 2
    assert 'Transfer cannot contain duplicate variants' in create
    assert 'row.status != "DRAFT"' in approve
    assert 'q(bal.on_hand) - q(bal.reserved) < remaining' in dispatch
    assert 'Insufficient stock for transfer line' in dispatch
    assert 'transaction_type="TRANSFER_OUT"' in dispatch
    assert 'change_inbound(db, tenant_id, row.destination_location_id, line.variant_id, remaining)' in dispatch
    assert 'qty > remaining' in receive and 'TRANSFER_QUANTITY_EXCEEDED' in receive
    assert 'transaction_type="TRANSFER_IN"' in receive
    assert 'change_inbound(db, tenant_id, row.destination_location_id, line.variant_id, -qty)' in receive
    assert 'row.status = "RECEIVED" if all(' in receive
    assert 'row.status != "RECEIVED"' in complete and 'row.status = "COMPLETED"' in complete


def test_duplicate_write_requests_have_payload_bound_idempotency_and_status_guards():
    helper = (API / "inventory.py").read_text(encoding="utf-8")
    routes = (API / "routes/inventory.py").read_text(encoding="utf-8")
    ui_api = (ROOT / "apps/web/lib/api.ts").read_text(encoding="utf-8")
    assert 'Idempotency-Key was already used with a different request' in helper
    assert 'row.request_hash != digest' in helper
    assert 'if row.response_status:' in helper
    assert 'Idempotency-Key' in ui_api and 'function key()' in ui_api
    # Every physical posting path is state-guarded before appending more ledger rows.
    for state_guard in ['row.status != "APPROVED"', 'row.status != "COUNTING"', 'row.status != "SUBMITTED"', 'row.status != "RECEIVED"']:
        assert state_guard in routes
    assert routes.count('idempotency_key: str | None = Header(None, alias="Idempotency-Key")') >= 10


def test_ledger_cost_and_reconciliation_views_are_read_only_and_tenant_location_scoped():
    route = (API / "routes/inventory.py").read_text(encoding="utf-8")
    helper = (API / "inventory.py").read_text(encoding="utf-8")
    ledger = section(route, '@router.get("/ledger", response_model=list[LedgerOut])', '@router.get("/products/{variant_id}")')
    integrity = section(route, '@router.get("/integrity")', '') if False else route.split('@router.get("/integrity")', 1)[1]
    assert 'Depends(require_permission("inventory.read"))' in ledger
    assert 'InventoryTransaction.tenant_id == tenant_id' in ledger
    assert 'InventoryTransaction.location_id.in_(allowed_locations)' in ledger
    assert 'balance.average_cost = new_avg' in helper
    assert 'balance.stock_value = q(new_qty * new_avg)' in helper
    assert 'total_cost=q(abs(quantity_delta) * (unit_cost if quantity_delta > 0 else old_avg))' in helper
    assert 'func.sum(InventoryTransaction.quantity_delta)' in integrity
    assert '"status": "ok" if not mismatches else "mismatch"' in integrity


def test_inventory_ageing_and_movement_health_are_scoped_and_not_misrepresented_as_fifo_costing():
    route = (API / "routes/inventory.py").read_text(encoding="utf-8")
    ageing = section(route, '@router.get("/ageing")', '@router.post("/rebuild", response_model=dict)')
    movement = section(route, '@router.get("/movement-health")', '@router.get("/ageing")')
    assert 'Depends(require_permission("inventory.read"))' in ageing
    assert 'allowed_location_ids' in ageing and 'ensure_location_access' in ageing
    assert 'unknown_age_quantity' in ageing
    assert 'not an accounting FIFO valuation' in ageing
    assert 'aged_over_30' in ageing and 'aged_over_60' in ageing and 'aged_over_90' in ageing
    assert 'Depends(require_permission("inventory.read"))' in movement
    assert "s.status='COMPLETED'" in movement
    assert 'units_sold_30d' in movement and 'units_returned_30d' in movement
    assert 'OUT_OF_STOCK_WITH_RECENT_DEMAND' in movement
    assert 'NO_SALE_90D' in movement
