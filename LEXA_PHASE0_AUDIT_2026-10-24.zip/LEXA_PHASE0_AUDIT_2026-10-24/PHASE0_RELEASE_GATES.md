# Phase 0 Release Gates and Immediate Work Plan

## Gate A — CI green on one exact commit (P0)

1. Apply the five expectation updates in `PHASE0_CI_REPAIR.patch` to a clean checkout of `d5be996d8cf45c93200351c6a21251c4d3a6c934`.
2. Run the five affected tests only, then the complete frontend Node tests and API pytest suite.
3. Run `LEXA Main Build CI`; confirm frontend typecheck **and production build**, all API tests, and Compose/HAProxy pass against the same SHA.
4. Do not remove the existing privacy, tenant scope or URA status guard assertions. Update only obsolete expected wording/metadata.

**Acceptance:** 0 failures, frontend production build passes, API suite passes, evidence tied to one SHA.

## Gate B — source/schema compatibility on an isolated database (P0)

1. Keep canonical production branch `lexa-live` untouched.
2. Use a fresh disposable PostgreSQL/Neon branch with documented origin and restricted credentials.
3. Replay the approved authoritative migration set from its approved start point, including 045–047. Resolve migration-history/provenance differences; a branch that merely has later versions is not equivalent to a clean replay.
4. Verify the objects created by 045–046, grants, forced RLS, expected functions and runtime-role permissions.
5. Run API integration tests on that schema; document/intelligence routes must return truthful empty/unavailable states rather than schema errors.

**Acceptance:** clean replay, schema diff, runtime-role tests, cross-tenant denial probes, rollback notes. No production migration in this gate.

## Gate C — business transaction acceptance (P0)

With synthetic data in an isolated staging tenant, verify:

`Sale + lines → inventory ledger/COGS → payment allocation or receivable → revenue/tax journal → audit/outbox → analytics refresh → optional fiscal-document queue`.

Also verify return/credit note, idempotent retry, permission denial, duplicate request, insufficient stock, failure rollback, branch isolation and stale analytics. Trace the same source sale from report to ledger. A unit test or green deployment badge is insufficient.

**Acceptance:** balanced journal invariants, correct stock cost, no duplicates on retries, every failed/partial state explicit.

## Gate D — AI question-only smoke test (P0/P1)

Use authenticated staging and synthetic non-sensitive questions only. Confirm off-topic and injection prompts are denied locally; names, emails, phones, IDs and numeric business facts are not sent externally under current policy; only allowlisted Gemini/Groq route; no automatic fallback; secrets and tenant/user IDs absent from provider payloads/logs; rate limit shared across replicas; browser-to-rendered-answer latency measured; no saved business facts invented.

**Acceptance:** synthetic end-to-end test, policy/privacy evidence, measured p50/p95 and honest error handling.

## Out of scope for Phase 0

- Applying 045, 046 or 047 to production.
- Locally generating an official EFRIS FDN, verification code or QR payload.
- Enabling paid providers, aggregate/confidential data transfer or autonomous writes.
- Connecting real mobile-money/bank movements without an approved provider/security spec.
- Declaring a 5,000-concurrent-user or 15-second p95 SLA without load-test evidence.
