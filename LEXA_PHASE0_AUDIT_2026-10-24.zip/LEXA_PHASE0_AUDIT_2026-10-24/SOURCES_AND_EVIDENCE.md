# Sources and Evidence Index

**Access date:** 24 October 2026 (UTC)

## Repository and CI
- Main repository: https://github.com/MONALISA2003-CMD/LEXA-
- Audited source commit: https://github.com/MONALISA2003-CMD/LEXA-/commit/d5be996d8cf45c93200351c6a21251c4d3a6c934
- Latest Main Build CI run: https://github.com/MONALISA2003-CMD/LEXA-/actions/runs/40100560783
- ZIP Extractor run: https://github.com/MONALISA2003-CMD/LEXA-/actions/runs/40100542999
- Relevant tests: `apps/web/tests/commerce-tax-efris-integrity.test.mjs`, `apps/web/tests/phase1-ux-contract.test.mjs`, `apps/web/tests/phase2-setup-readiness-contract.test.mjs`, `apps/api/tests/test_ai_assistant.py`, `apps/api/tests/test_demand_forecast.py`.
- Current source copy/policy: `apps/web/app/compliance/page.tsx`, `apps/api/app/routes/ai_assistant.py`, `apps/api/app/intelligence/routes.py`.
- Migrations: `migrations/045_intelligence_foundation.sql`, `migrations/046_intelligence_documents.sql`, `migrations/047_analytics_forecast_history_backfill.sql`.

## Hosted surfaces
- Render LEXA API: https://dashboard.render.com/web/srv-dakm8k95efls73egg9a0
- Vercel production deployment: https://vercel.com/kabuusumohammed182-7875s-projects/lexa/6ptbWrjzptoqUBzppRzuBiypdtt3
- Vercel domain: https://lexa-green.vercel.app
- Neon LEXA project: https://console.neon.tech/app/projects/wispy-mud-75323042
- Neon live branch: https://console.neon.tech/app/projects/wispy-mud-75323042/branches/br-soft-star-b1dj2m2w
- Neon replay branch: https://console.neon.tech/app/projects/wispy-mud-75323042/branches/br-dark-breeze-b1mgcaxj

## Interpretation
- Render `live` and Vercel `READY` are deployment states, not authenticated workflow acceptance.
- The latest inspected Main Build CI run failed while the providers were deployed.
- Neon inspection used only `SELECT` statements and schema/table metadata reads.
- Provider secrets were not retrieved or printed. The user's report that Gemini and Groq keys are configured is user-supplied context, not independently re-proven here.
