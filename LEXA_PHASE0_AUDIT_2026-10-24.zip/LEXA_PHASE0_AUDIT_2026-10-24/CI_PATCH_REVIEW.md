# CI Patch Review Notes

This proposed patch changes test expectations only. It does not alter runtime behavior, permissions, migrations, database data or hosting.

- The three frontend contracts are updated to match the exact current UI language while retaining the verified URA-status protections and the tax workflow checks.
- The provider test is updated to match the current `gpt-5-mini` server default; the test still asserts that an unconfigured provider is not configured.
- The demand-forecast capability test is reframed because external question-only assistant routing is now a separate dynamic capability. It explicitly retains assertions that personal data are not allowed externally, automatic fallbacks are disabled and business writes are disabled.

**Validation status:** patch proposed from CI logs and current source. It has not been applied to a clean checkout and the complete suite has not yet been rerun. Do not label it a fix until the follow-up CI run passes.
