# Phase 0 Baseline Audit — LEXA

**Checked:** 24 October 2026 (UTC / Africa-Kampala)  
**Canonical source SHA:** `d5be996d8cf45c93200351c6a21251c4d3a6c934`

## Executive result

**Phase 0 is not release-clear.** The current GitHub, Render and Vercel source revision can be identified, but main CI fails and the live production database migration history is behind the deployed source migration set. There is promising tenant isolation at the database catalog level, but business transactions, refreshed analytics and end-to-end acceptance have not been evidenced by production data.

## Source and deployment state

| Surface | Observation | Evidence |
|---|---|---|
| GitHub `main` | HEAD `d5be996d8cf45c93200351c6a21251c4d3a6c934`, message `chore: extract canonical LEXA source [lexa-extractor]` | https://github.com/MONALISA2003-CMD/LEXA-/commit/d5be996d8cf45c93200351c6a21251c4d3a6c934 |
| Main Build CI | Run `40100560783` completed **failure** | https://github.com/MONALISA2003-CMD/LEXA-/actions/runs/40100560783 |
| ZIP Extractor | Run `40100542999` succeeded for previous source SHA `12e8c17d8a5e52610bf3de3ae1f8ea5c12af1d74` | https://github.com/MONALISA2003-CMD/LEXA-/actions/runs/40100542999 |
| Render API | Service `LEXA`, `srv-dakm8k95efls73egg9a0`, root `apps/api`, Frankfurt; latest observed deploy `dep-dbebjo84cbqc73d9vspg` is **live** on `d5be996...` | https://dashboard.render.com/web/srv-dakm8k95efls73egg9a0 |
| Vercel | Latest production deployment is **READY** on `d5be996...` | https://vercel.com/kabuusumohammed182-7875s-projects/lexa/6ptbWrjzptoqUBzppRzuBiypdtt3 |
| External AI config | Render accepted merged updates `LEXA_AI_EXTERNAL_PROVIDERS_ENABLED=true` and `LEXA_AI_ALLOWED_PROVIDERS=gemini,groq`; deploy now live. User reports both provider keys are configured. | Render service link above; values were not independently read back. |

`READY`/`live` status confirms deployment state only. It does not prove a real authenticated assistant answer or business workflow. No external-provider prompt was executed during Phase 0.

## Exact main CI failures

Run `40100560783` has two failing jobs; the Compose/HAProxy job passed. API compilation and frontend TypeScript typecheck passed, but the web production build was skipped because the frontend contract tests failed.

### Frontend — job `120891673955`

**92 passed, 3 failed out of 95.**

| Test | Stale assertion | Current source wording | Safe expectation correction |
|---|---|---|---|
| `apps/web/tests/commerce-tax-efris-integrity.test.mjs` | `/real URA-approved connector/` | `apps/web/app/compliance/page.tsx` says `real, verified URA response` and `genuine URA-approved connection confirms registration` | Assert the current verified-response wording; keep the no-manual-ACTIVE assertion. |
| `apps/web/tests/phase1-ux-contract.test.mjs` | `/No tax rates are saved yet/` | `No rates configured yet.` | Match the current empty-state copy. |
| `apps/web/tests/phase2-setup-readiness-contract.test.mjs` | `/Configure a default tax rule/` | The current heading is `Default tax rule`. | Match the page heading; retain scope/date/tax guard assertions. |

These are test expectation mismatches, not proof the behavior is correct. Keep the surrounding privacy/compliance assertions intact.

### API — job `120891674045`

**288 passed, 2 failed.**

| Test | Failure | Proposed correction |
|---|---|---|
| `apps/api/tests/test_ai_assistant.py::test_provider_status_marks_unconfigured_provider` | Test expects `gpt-6-astra`, but `apps/api/app/routes/ai_assistant.py` declares `gpt-5-mini` as the current OpenAI fallback model. | Change only the asserted default to `gpt-5-mini`; no OpenAI request or key is required by this test. |
| `apps/api/tests/test_demand_forecast.py::test_capabilities_exposes_python_forecasting_without_external_ai_or_writes` | Test expects `"execution_available": False`, while the current endpoint sets it from `external_question_route_ready`. | Reframe the test to assert the dynamic question-only readiness field plus `personal_data_external_allowed=False` and `automatic_fallbacks=False`. Forecasting remains local and `automatic_business_writes=False`. |

The overall CI gate is therefore **RED**. The patch in this packet is a proposed test-only correction, not yet applied or validated against the full checkout.

## Production Neon state — read-only checks

- Project: `wispy-mud-75323042` (`LEXA`).
- Primary/default branch: `lexa-live`, ID `br-soft-star-b1dj2m2w`.
- The production `public.schema_migrations` history includes `044_phase3_password_reset_security` but no rows for `045_intelligence_foundation`, `046_intelligence_documents` or `047_analytics_forecast_history_backfill`.
- Current `main` contains migrations 045–047 and registers intelligence/document routes. This is a **source/schema compatibility risk** requiring isolated replay and route verification before release; it is not permission to run migrations on production.
- The live migration ledger also has historical numbering gaps (notably `004`, `005` and `032`) even though similarly numbered or adjacent migration files exist in the repository. Existing repository notes describe reconstructed migration equivalents and provenance decisions. The full approved migration plan must reconcile these gaps; do not blindly replay every file in numeric sort order.

### Production row counts observed

| Table | Count |
|---|---:|
| `tenants` | 7 |
| `sales` | 0 |
| `payments` | 0 |
| `inventory_transactions` | 0 |
| `journal_entries` | 0 |
| `analytics_daily_business_metrics` | 0 |
| `analytics_product_daily_metrics` | 0 |
| `analytics_refresh_runs` | 0 |
| `fiscal_documents` | 0 |
| `efris_configurations` | 2 |

There are no analytics refresh runs or metric rows in this observation. Forecasts gated by a recent, complete 56-day refresh therefore have no supporting production evidence and must remain unavailable rather than be fabricated as zero.

### RLS catalog check

The production catalog returned **130 public base tables, all 130 with RLS enabled and forced**. This is positive structural evidence, not proof of complete cross-tenant/branch isolation for every route or write as the application runtime role.

The non-primary branch `lexa-phase3-security-replay-20261021` (`br-dark-breeze-b1mgcaxj`) contains migration records for 045–047, but its catalog reports 123 base tables with 118 having RLS enabled and forced. This branch evidence does not equal a fresh empty-database migration replay or prove schema parity with current `lexa-live`.

## AI integration boundary

The current source includes Gemini/Groq adapters, central policy routing, explicit allowlisting, server-side secrets, a tenant/user rate limiter, local scope checks, personal-identifier screening, business-local-time context, a 12-second server-side model deadline and no automatic provider fallback. The current prompt path sends the screened **question only**; it does not retrieve saved tenant sales, stock or finance facts.

Consequently, LEXA must not invent answers to questions like “what were my sales yesterday?” until it has explicit server-side, typed, permission-checked read-only business tools that return minimum necessary facts with source/date/freshness. Never accept client-supplied tenant IDs or pass whole workspace records to the model. A 12-second timeout is not proof of a 15-second end-to-end p95; measure it in staging.

## Phase 0 decision

1. Keep production schema and data unchanged. No SQL mutation or migration was executed in this audit.
2. Review/apply the five test expectation changes in `PHASE0_CI_REPAIR.patch`, then rerun focused tests and full CI on one exact SHA.
3. Clean-replay the approved migration chain in a disposable PostgreSQL/Neon branch, including 045–047; verify objects, grants, forced RLS and runtime-role behavior.
4. Execute authenticated staging tests with synthetic tenant data for sale/return, stock, payments/receivables, journals, audit/outbox, analytics refresh, document routes and synthetic AI prompts.
5. Only then choose the next minimal P0 code increment.

## Scope and limits

This audit used GitHub/hosting metadata and read-only production SQL/catalog queries. It did not log in as a business user, run browser acceptance, call Gemini/Groq, run a clean migration replay, retrieve provider secrets, edit GitHub source, or alter production database state.
