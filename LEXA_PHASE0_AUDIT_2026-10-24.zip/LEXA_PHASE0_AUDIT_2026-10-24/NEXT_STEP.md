# Next exact step after Phase 0

Start from audited SHA `d5be996d8cf45c93200351c6a21251c4d3a6c934`. Apply `PHASE0_CI_REPAIR.patch` to a clean checkout, run the five affected tests, then full CI. Do not change production database state during that repair.

Once CI is green, run a clean isolated migration replay and test migrations 045–047 with the intelligence/document endpoints. Then implement the smallest P0 code increment: authenticated sale/return inter-module acceptance and a permission-checked, source-grounded, read-only AI business tool layer. Keep the assistant question-only until each tool enforces tenant/branch/permission checks, source/date/freshness provenance and synthetic privacy tests.
