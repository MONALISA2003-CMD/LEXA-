# Phase 1 acceptance matrix

| Step | Required invariant | Evidence to collect | Current evidence status |
|---|---|---|---|
| Product/SKU setup | Active tenant-owned product/variant, unique SKU, configured price and tax rule | API tests and tenant-scope tests | Source present; full journey not verified |
| Purchase order | PO approval/authorization; PO alone does not change on-hand | DB assertions before/after PO | Source present; synthetic end-to-end pending |
| Goods receipt | Only actual received quantity posts; receipt is idempotent; landed costs enter inventory valuation | Receipt replay and inventory-ledger comparison | Source present; synthetic end-to-end pending |
| Supplier bill/AP | Bill obligation does not receive stock again; PO/receipt variance reviewed | Receipt + bill comparison and AP journal balance | Source present; migration 048 absent from live ledger |
| Sale | Retry-safe; price/tax from server; stock insufficiency blocks; serialized unit cannot sell twice | Same-key replay, changed-payload conflict, concurrency tests | Source and contract tests present; staging pending |
| Inventory/cost | One movement per sold unit; cost uses posted inventory cost | Inventory ledger/balance and COGS comparison | Source present; full journey pending |
| Payment/receivable | Payments are allocated once; remaining amount is due; later payment does not create a new sale | Full-pay, split-pay, partial-pay, overpayment tests | Source present; full journey pending |
| Journals | Sale, COGS, receipt, supplier ledger and payment entries balance by tenant/currency; corrections are reversals | Sum debit == sum credit; source linkage; reversal tests | Functions/tests exist; live migration 048 not recorded |
| LEXA receipt | Printed content reflects authoritative saved sale; internal receipt is not represented as fiscal document | API/UI contract and browser print acceptance | Partial: sale detail and print button exist; dedicated receipt payload/layout missing |
| Tax-supporting records | Effective-dated tax rule is persisted; external fiscal reference is manual and clearly unverified by LEXA | Tax source metadata + manual record linkage tests | Source present; end-to-end pending |
| Analytics | Refreshes derive from authoritative ledgers, preserve business date/currency, expose freshness and source drill-down | Worker queue test, 56-day history checks, report/source reconciliation | Source and worker exist; live outbox is all pending per earlier audit; cause unknown |
| Security | Tenant/branch permission checks on every read/write; RLS forced and effective | disposable DB cross-tenant read/write denial tests | RLS metadata seen; effective isolation not proven |
| Release | Exact SHA has green CI, clean migration replay, staged workflow acceptance; deployed web/API SHAs match | CI run, replay artifact, staged run, host deployment metadata | Not satisfied |

## Required staged scenarios

1. Product with configured price/tax → approved PO → partial receipt with landed cost → bill linked to receipt → payment allocated to bill.
2. Same SKU sold for full payment; verify one sale, one stock decrement, sale journal, COGS journal, payment journal, receipt, tax metadata, audit/outbox and analytics.
3. Same sale with partial payment; verify receivable equals the unpaid remainder. Later payment reduces receivable and creates only payment/allocation/journal, not another sale.
4. Retry checkout with identical key/payload; response is replayed with no duplicate effects. Reuse key with changed payload; conflict.
5. Insufficient stock and duplicate serial sale reject without partial writes.
6. Print receipt and verify business/branch/date/items/discount/tax/total/paid/due and explicit non-fiscal disclaimer.
7. Record manually obtained URA fiscal document; ensure it is linked and labelled not verified by LEXA; ensure live EFRIS submission remains blocked.
8. Refresh analytics; prove reported sales/collections/COGS/stock reconcile to source ledgers and show stale/empty state honestly.
9. Partial supplier receipt and supplier bill: confirm no second stock receipt; check GRNI/AP/stock and journals balance.
