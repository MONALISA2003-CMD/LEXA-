# LEXA Phase 1 — Critical business journey implementation handoff

Date: 2026-10-26
Repository: `MONALISA2003-CMD/LEXA-`

## Scope

Product setup → purchase order → goods receipt → inventory/cost → sale → payment or receivable → balanced journals → LEXA receipt → tax-supporting record → analytics.

## Verified in canonical source (main at `cd92efe154a55f5126e4197bb9c6b4a182f6af92`)

- Product/SKU APIs: `apps/api/app/routes/catalog.py` (idempotent product/variant creation).
- Purchasing: `apps/api/app/routes/purchasing.py` (approved PO; actual receipt; weighted-average cost; landed cost; supplier bills/payments and allocations).
- Sales: `apps/api/app/routes/commerce.py` (required idempotency key; server-side price/tax resolution; stock ledger; payment allocation; receivable; sale and COGS journal functions; event/audit records).
- Analytics: `apps/api/app/routes/analytics.py`, `apps/api/app/workers/analytics_outbox.py`, migration 041/047.
- Manual fiscal records: `apps/api/app/routes/tax_reference.py`; live URA/EFRIS submission is deliberately blocked by `apps/api/app/main.py`.
- Sale detail currently prints generic sale details rather than a dedicated branded customer receipt. Sale-detail API does not return business transaction reference, branch/location labels, business profile, or fiscal-document linkage as a single receipt payload.
- `business_profiles` currently stores only legal name, display name, country and currency; no phone/email/address fields are present in canonical model/schema.
- Neon `lexa-live` migration ledger includes 047 but **does not include 048**. Current source has a `/ready` gate for migration 048. Migration 048 adds purchase approval limits, return reversal columns and supplier/receipt accounting triggers. Do not deploy code that requires 048 or call the database ready until its clean replay/security checks pass and migration is deliberately applied.

## Critical release blocker

GitHub main CI at `7ef1444f3f455a940fa1e0cae18c98c76775b72f` was failing the frontend brand contract. GitHub `main` subsequently advanced to `cd92efe154a55f5126e4197bb9c6b4a182f6af92` via ZIP extraction. A fresh CI result for that newer SHA was not yet available in this work. GitHub write API denied branch creation with HTTP 403, and local network could not clone GitHub; no source change has been pushed by this session.

## Implementation/verification status

This is a code/source handoff, not a claim that Phase 1 is complete or deployed. No production data or schema was mutated. The connected Neon `lexa-live` branch is treated as live and was inspected read-only. Existing disposable branches exist but were not used to run migrations because the available GitHub source checkout in the Vercel sandbox is stale (HEAD `8124cca...`, detached, with a pre-existing modified `apps/api/app/routes/finance.py`) and must not be treated as the current source.

## Required implementation increments

1. Add optional business profile contact/address fields with backward-compatible defaults and tenant-scoped audit/events.
2. Add a receipt read model that joins sale + transaction reference + branch/location + profile + line/tax totals + recorded payment allocations + receivable + posted journals + linked manual fiscal record.
3. Replace “Print details” with a customer receipt layout, including LEXA receipt ID, item quantities/prices/discounts/tax, total/paid/due, business/date/branch, and a clear `LEXA receipt — not an official URA/EFRIS fiscal receipt` label unless an external document was manually recorded.
4. Make receipt screen provide a link/action to record a manual URA fiscal reference; never submit to EFRIS.
5. Add tests for full-paid and partial-credit sales, split payments, retry idempotency, stock rejection, balanced SALE/COGS/PAYMENT journals, receipt content, manual fiscal reference distinction, analytics refresh provenance, and purchase receipt not double-counting stock when supplier bill posts.
6. Reconcile migration 048 and the live ledger through a reviewed forward-only migration procedure. Never edit historical migrations or insert fake migration-ledger rows.
7. Run API tests + web typecheck/contracts/build + disposable PostgreSQL clean replay + authenticated synthetic staging acceptance on one exact SHA. Only then consider production deployment.

## Safety constraints

- No production writes from this handoff.
- No payment-provider integration or live bank/mobile-money verification.
- No direct URA/EFRIS submission.
- Posted business facts are immutable; corrections are linked reversals/returns.
- Money stays Decimal/PostgreSQL numeric; use one authoritative transaction source and idempotency keys.
- Never claim receipt, journal, analytics, tenant isolation, or live acceptance as verified without a passing test/evidence artifact.
