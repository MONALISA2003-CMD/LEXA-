# Phase 1 source handoff

This folder contains a verified source-status report and a staging acceptance matrix. It is intentionally **not** an auto-extractable full-source ZIP, and contains no executable production migration. That is deliberate: the canonical GitHub write API denied branch creation, and the only available local checkout was stale and dirty. Packaging guessed replacement source files would risk overwriting newer code.

Start from current GitHub `main`, create a branch through GitHub UI, apply implementation changes in canonical paths, then run all required tests. Migration 048 is present in source but absent from the inspected live migration ledger; follow the repository's migration README and use only a disposable PostgreSQL clean replay before considering a production migration.
