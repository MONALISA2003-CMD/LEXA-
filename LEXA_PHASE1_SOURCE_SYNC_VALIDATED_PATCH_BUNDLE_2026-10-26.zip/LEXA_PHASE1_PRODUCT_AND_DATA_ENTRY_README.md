# LEXA Phase 1 — source-sync update bundle

**Validated target source:** `fa1e14fd289105e9a0a52d47bd69ee972af1c0e4` (GitHub `main` checked 2026-10-26). The patch was applied successfully to a clean worktree at this source revision.

## What this update changes

- Adds `POST /api/v1/catalog/products/quick-setup` with a typed OpenAPI response and idempotency support.
- Creates a product and first sellable variant in one database transaction, with optional barcode and price-list price; validates tenant-owned references and SKU/barcode conflicts; records audit/outbox events and rolls back on failed writes.
- Improves product setup for product name, category/brand, variant/pack name, SKU, base unit, costing method, optional barcode and optional selling price.
- Keeps opening stock in audited inventory and goods-receipt workflows, rather than treating catalog setup as a stock movement.
- Adds a print-ready LEXA sale receipt based on saved sale details, including lines, discounts/tax, branch/location, payment allocations and receivable balance.
- Shows journal debit/credit totals and balanced status; clarifies that manually entered URA/EFRIS references are not submitted or independently verified by LEXA.
- Extends the LEXA master-brand styles for the app shell/mobile top bar.
- Fixes migration 048's supplier-accounting trigger reference from undeclared `v_cash` to declared `a_cash`.
- Adds API and frontend contract regression tests and updates replay evidence.

Existing guarded entry points for purchase orders, goods receipts, supplier bills/payments, stock adjustments/counts/transfers, checkout and accounting are preserved. This patch does not replace those flows with direct table writes.

## Validation on the reconciled source tree

- Frontend tests: **133 passed, 0 failed** (`npm test` in `apps/web`).
- TypeScript: **passed** (`npm run typecheck`).
- Next.js production frontend build: **passed** (`npm run build`).
- API test suite: **343 passed**, 2 dependency deprecation warnings (`pytest -q` in `apps/api`). Test-only placeholder `DATABASE_URL`, `REDIS_URL`, and `JWT_SECRET` values were used; no live database or Redis service was configured.
- Python compile check for the changed API modules and new API tests: **passed**.
- Ruff critical-error check on changed API modules/tests: **passed**.
- `git diff --check`: **passed**.
- `git apply --check`: **passed** on the current `main` source revision listed above.

A disposable PostgreSQL migration replay from the previous validation pass reported 52 SQL steps successful after the migration 048 correction. That replay was **not re-run against a clean standard CI/staging database in this pass**, so release automation should repeat it.

## Important deployment status

This ZIP is a **source update patch bundle**, not a full repository snapshot and not proof of a production release. The changes were validated in an isolated worktree. GitHub branch creation was denied with HTTP 403 by the connected integration, and `git push` from the sandbox had no GitHub credentials; consequently, the validated candidate was **not pushed to GitHub**. The Vercel production frontend and Render API have **not** been updated by this pass, and no production database was touched.

Before calling the release complete, apply this patch to the source repository and commit the modified files; run CI and a clean migration replay; perform the authenticated staging flow with synthetic data; then verify the exact deployed commit on Vercel and Render.

## Apply to the source repository

From the repository root, review the working tree and run:

```bash
git apply --check LEXA_PHASE1_PRODUCT_AND_CRITICAL_JOURNEY.patch
git apply LEXA_PHASE1_PRODUCT_AND_CRITICAL_JOURNEY.patch
```

Review the diff before committing. Do not upload the ZIP into GitHub expecting Vercel to extract it—Vercel builds tracked source files, not a patch archive. Apply and commit the source changes first.
