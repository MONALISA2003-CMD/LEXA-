# LEXA Phase 7 migration fix and CI recovery package

## Verified issue

The source migration `migrations/048_phase7_approval_limits_reversals_accounting.sql` declares the supplier cash-account variable as `a_cash uuid`, but the `PAYMENT` branch of `public.post_supplier_ledger_journal` references `v_cash` three times. An isolated clean Neon replay of migrations 045, 046, and 047 then 048 failed exactly with:

`NeonDbError: "v_cash" is not a known variable`

Changing those references to the declared `a_cash` made migration 048 apply to the same disposable branch. Postconditions showed the 048 marker, approval table, guard/journal routines, journal triggers, and return-reversal column present. Two disposable tenants each received all five accounting mappings; `lexa_app` saw only its own approval-limit row and zero rows without tenant context. No production SQL/data was written.

## Files

- `patches/0001-fix-phase7-048-cash-variable.patch`: source correction and regression test.
- `.github/workflows/lexa-ci.yml`: safe backend/frontend contract jobs plus a local, disposable PostgreSQL replay through migration 048. It never connects to Neon.
- `scripts/check_phase7_replay.py`: validates the Phase 7 contract set, seed-trigger output, helper-function privilege revocation, and forced tenant RLS in the disposable CI database.

## Apply when GitHub write access is restored

From a checkout of current `main` (replace `/path/to/LEXA_PHASE7_FIX_PACKAGE` with the extracted package path):

```bash
git apply /path/to/LEXA_PHASE7_FIX_PACKAGE/patches/0001-fix-phase7-048-cash-variable.patch
mkdir -p .github/workflows scripts
cp /path/to/LEXA_PHASE7_FIX_PACKAGE/.github/workflows/lexa-ci.yml .github/workflows/lexa-ci.yml
cp /path/to/LEXA_PHASE7_FIX_PACKAGE/scripts/check_phase7_replay.py scripts/check_phase7_replay.py
```

Commit on a new feature branch and open a PR; do not push directly to `main`.

## Production release is still blocked

The GitHub connector denied branch creation/reference updates with HTTP 403, so these changes could not be committed remotely. Production Neon remains at migration 047. The only identified LEXA backup project contains an older selective recovery copy from 22 October and is not a verified current production backup. A fresh Neon snapshot of the live child branch is rejected by Neon (`not allowed to snapshot non-root branch`). Do not apply migration 048 to production until a current restorable backup and the normal release approval gate are available.
