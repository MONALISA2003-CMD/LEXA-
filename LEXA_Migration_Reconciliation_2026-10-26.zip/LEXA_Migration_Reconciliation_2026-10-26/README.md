# LEXA migration reconciliation and traceability acceptance — 2026-10-26

This package contains the existing 049–051 traceability overlay plus current validation evidence and the migration-lineage decision required before source integration. It is not a claim that source changes were pushed or that authenticated end-to-end acceptance passed.

## Current verified results
- The disposable Neon replay branch has exactly one ledger entry for each of 048, 049, 050 and 051; latest version is `051_tracked_inventory_workflow_integration`.
- The four serial/lot tables have RLS enabled and forced, one tenant policy each; serial and lot movement tables each have one user trigger.
- The overlay's static contract scripts pass (32 checks total), and its Python installers/test scripts compile.
- The existing findings ZIP passes `unzip -t`.
- Both QA tenants still have zero sales, payments, journal entries, and outbox events.
- The production database lacks the Phase 7 048 contract and remains correctly blocked by `/ready`.
- GitHub writes are denied to the connected integration (HTTP 403); no branch commit, PR, or deployment was made.

## Reconciliation decision required
Canonical `main` replay order uses:
1. `045_intelligence_foundation.sql`
2. `046_intelligence_documents.sql`
3. `047_analytics_forecast_history_backfill.sql`
4. `048_phase7_approval_limits_reversals_accounting.sql`

`LEXA-branch` instead has a branch-only `045_phase8_reconciliation_closed_snapshot.sql` and its replay manifest says the maintained chain ends at that migration. The branch is diverged from `main` (13 commits ahead, 72 behind at the latest comparison). Do not overwrite either manifest, renumber migrations, edit applied ledger rows, or merge the two chains by filename-prefix assumption. Reconcile full migration identities and deployed ledger state first, preserving both the intelligence/document/forecast migrations and the closed-reconciliation snapshot guard in a reviewed forward-only sequence.

## Next execution sequence
1. Restore authorized GitHub write access to the repository integration, then create a source reconciliation commit on `LEXA-branch` (or a reviewed staging branch) with a canonical replay manifest covering both migration lineages through 048.
2. Run migration recovery/source-integrity checks and a clean local PostgreSQL replay through 048.
3. Integrate the 049–051 overlay, API routes and frontend traceability pages; run the overlay static contracts.
4. Run the full API pytest suite, frontend typecheck/tests/build, and full disposable PostgreSQL replay on the exact commit SHA.
5. Provision authenticated disposable staging credentials/tenant and execute checkout/payment retry tests, partial and credit payments, returns/refunds/corrections, journal/customer reconciliation, source-linked receipt/tax/audit/outbox/analytics checks, and role/tenant/branch access denial tests.
6. Only after those pass, review the migration rollout, obtain explicit production approval, deploy the matching code/schema, and re-check `/ready`.

No production migration or deployment is authorized by this package.
