# LEXA Phase 1 implementation bundle

This bundle targets `MONALISA2003-CMD/LEXA-` and reuses its current catalogue, branch/location, purchase and stock-ledger foundation. It adds an inventory-traceability migration, a tenant-scoped FastAPI router, a user-facing inventory tracking screen, an install guide and an acceptance matrix.

## Install

See `OVERLAY/docs/PHASE1_GENERIC_INVENTORY.md`. Copy the migration and API/web files into a full LEXA checkout and register the router. This is an **overlay**, not a copy of the full repository, and it has not been applied to a production database.

## Status

The code is prepared for source review and integration; it is not yet a release-ready/production-certified phase. In particular, the current POS, supplier receipt, transfer, count and return commands must be connected to serial/lot allocations, then tested end-to-end against a disposable PostgreSQL database. The database guard is intentionally designed to fail closed when tracked sales omit identities.

## Safety

No production SQL is executed by this bundle. Run migration/replay only against a fresh disposable database. Do not deploy from this bundle before the documented release gates pass.
