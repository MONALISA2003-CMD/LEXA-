# LEXA — phone-first handoff

You do not need to edit code or type terminal commands on your phone to use this handoff. This single ZIP contains the corrected source patch, regression test, additive Phase 7 validation workflow, test scripts, isolated replay evidence, and the current audit/release checklist.

## What has been completed

- Confirmed the migration 048 defect: `post_supplier_ledger_journal` declares `a_cash` but references undeclared `v_cash` three times in the supplier-payment path.
- Prepared the source correction and a regression test.
- Tested the corrected migration and representative receipt/bill/payment journal, reversal, idempotency and approval-limit behavior on a disposable Neon replay branch only.
- Added an installer that checks expected source context and refuses to overwrite conflicting existing files.
- Prepared an additional GitHub Actions workflow without replacing `.github/workflows/lexa-ci.yml`.
- Verified the ZIP, package checksums, Python syntax, JSON evidence and workflow YAML.

## What is not complete — do not label production green

- GitHub repository writes were rejected by the connected integration (HTTP 403), so the patch has not been committed and GitHub Actions has not run on the proposed changes.
- The full clean-replay workflow has not yet passed on GitHub's PostgreSQL runner.
- Production is still recorded at migration 047; migration 048 has **not** been applied to production.
- A fresh, complete, restorable production backup and the normal release approval were not verified. The older backup artifact was selective and is not sufficient evidence for this release.
- Last observed readiness checks were Vercel HTTP 503 and Render `phase7_release_schema_not_ready`; authenticated end-to-end business and AI/analytics acceptance remain outstanding.

## Safety decision

The production migration must remain blocked until a current restore-tested backup and normal approval exist, followed by passing CI/staging acceptance. Do not delete existing Neon branches to bypass the branch limit. Do not treat the isolated Neon evidence as proof that production is ready.

## If you are handing it to an authorized maintainer

Send them this ZIP as-is. The `APPLY/` installer and `PATCHES/` file are for applying the proposed source change to the exact repository revision recorded in `SOURCE_BASELINE.json`. The maintainer should review the resulting diff and run the added CI workflow before release. The ZIP itself is not meant to be unpacked directly over the production database or treated as a deployment.
