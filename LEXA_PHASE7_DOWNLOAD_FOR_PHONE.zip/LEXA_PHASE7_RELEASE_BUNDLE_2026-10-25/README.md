# LEXA Phase 7 migration-048 fix package

**Baseline reviewed:** `main` at `43514afbe9153eca3bd4092f8e06ef9a162bb567` (25 October 2026 observation)

**Purpose:** deliver an applicable source patch, safe installation path, additive Phase 7 clean-replay CI workflow, behavioral checks, and release evidence when GitHub write access is unavailable.

## Contents

- `PATCHES/0001-fix-phase7-048-cash-variable.patch`: contextual unified diff that changes the three undeclared `v_cash` references to the declared `a_cash` variable and adds a regression test.
- `APPLY/apply_phase7_fix.py`: guarded installer; no network/database/deploy or Git write action.
- `OVERLAY/.github/workflows/lexa-phase7-validation.yml`: separate additive workflow, leaving existing `.github/workflows/lexa-ci.yml` intact.
- `OVERLAY/scripts/check_phase7_replay.py`: schema, forced tenant RLS, seed mapping, and helper-privilege assertions against disposable CI PostgreSQL.
- `OVERLAY/scripts/check_phase7_behavioral_replay.py`: receipt/bill/payment journals, idempotency, return reversal and approval guard tests against disposable CI PostgreSQL.
- `EVIDENCE/`: JSON evidence from the isolated Neon replay/behavioral test branch only.
- `AUDIT/`: prior end-to-end module matrix, release-gate re-audit and read-only verification SQL.
- `SOURCE_BASELINE.json`: repository/source blob identifiers used to prepare this bundle.

## Confirmed source defect

The `PAYMENT` branch of `public.post_supplier_ledger_journal` declares `a_cash uuid` but refers to `v_cash` three times. A clean isolated Neon replay of migrations 045–047 plus migration 048 failed compilation with `"v_cash" is not a known variable`; changing only those references to `a_cash` allowed migration 048 to run on the disposable test branch. The replay also passed the recorded schema/RLS and representative accounting trigger assertions. This is test evidence, not production application.

## Safety and limits

The bundle is intentionally not a production migration operator. It does not hold or include secrets, does not mutate Neon, does not delete branches, and does not deploy. Use a clean feature branch and review its diff. The full repository-level clean replay and automated GitHub CI have not been executed by this chat environment. The CI workflow in this bundle is **proposed and syntax-checked**, not already green.
