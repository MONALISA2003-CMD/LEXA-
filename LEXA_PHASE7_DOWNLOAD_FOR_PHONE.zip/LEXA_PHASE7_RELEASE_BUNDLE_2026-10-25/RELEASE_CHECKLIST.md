# LEXA release checklist — migration 048

## Source / repository

- [ ] Apply `APPLY/apply_phase7_fix.py` to the exact current main checkout.
- [ ] Confirm `git diff --check` succeeds and migration/test changes are limited to the intended fix.
- [ ] Run the targeted API test locally.
- [ ] Run `python scripts/run_clean_migration_replay.py --plan-only`.
- [ ] Open a feature-branch PR; keep the existing `lexa-ci.yml` file in place.
- [ ] Wait for both the existing main CI and the added Phase 7 clean replay workflow to pass; inspect replay evidence and logs, not only the summary badge.

## Backup / release approval — hard gate

- [ ] Produce a fresh, complete production backup through Neon’s approved backup/recovery mechanism.
- [ ] Verify the backup includes the current production branch/schema/data and can be restored into a separate branch/project. Record snapshot/restore IDs and validation results.
- [ ] Obtain the normal database owner/release approver's approval for migration 048 and the rollback/restore plan.
- [ ] Do not delete existing Neon branches to get around the branch limit. If the backup mechanism is unavailable on the live child branch, resolve that through the approved Neon owner/support path instead.

## Staging and end-to-end acceptance

- [ ] Apply migration 048 only through the approved migration pipeline to a staging target first.
- [ ] Check all Phase 7 readiness contracts, mapping seed rows, least-privilege grants and cross-tenant isolation.
- [ ] Run purchase approval cap boundary cases, goods receipt posting, supplier bill/AP, bank payment journal, idempotency and supplier-return reversal.
- [ ] Run authenticated sign-in/workspace tests and tenant/branch isolation tests.
- [ ] Run sales → stock/payment → journal/analytics and PO → receipt → supplier bill/AP → payment allocation/balance workflows with authorized synthetic fixtures.
- [ ] Verify AI policy routing/provider eligibility/latency/isolation and that requests unrelated to LEXA are rejected, without exposing secrets.
- [ ] Verify analytics/forecast behavior using valid test history and confirm unavailable/partial-history UX is truthful.

## Production release and smoke

- [ ] Record backup ID, approval, migration checksum, source commit, CI evidence and rollback path in the release record.
- [ ] Apply migration through the approved production pipeline only after every prior item passes.
- [ ] Verify `/health`, `/ready`, tenant isolation and representative real business workflows after migration.
- [ ] Verify Vercel readiness is healthy and Render's readiness gate no longer reports `phase7_release_schema_not_ready`.
- [ ] Monitor logs, journal balancing, RLS denials, payment allocation and analytics refresh; roll back/recover under the approved plan if checks fail.

**Current decision from last observation:** BLOCKED. Production remained at migration 047, readiness returned 503, the current verified complete/restorable backup and approval record were absent, and authenticated staging acceptance had not run.
