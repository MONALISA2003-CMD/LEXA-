# LEXA Phase 7 release bundle — start here

This is a corrected, reviewable handoff package for the migration-048 source defect and release-validation work. It is designed to be applied to the current `main` checkout without replacing your existing `.github/workflows/lexa-ci.yml`.

## What was corrected in this package

1. The previous ZIP's unified-diff hunk headers were malformed. This bundle contains a rebuilt contextual patch that can be validated with `git apply --check`.
2. The prior CI file occupied the existing `lexa-ci.yml` path. This bundle instead adds a separate workflow at `.github/workflows/lexa-phase7-validation.yml`; the current main workflow stays untouched.
3. A guarded installer preflights every target, refuses conflicting overlay files, applies the SQL/test patch as a unit, and performs post-install checks.
4. The package carries the isolated Neon replay evidence, original audit/module matrix, current release-gate re-audit and read-only SQL evidence.

## Apply to a clean checkout

Extract the ZIP, then run this command from any directory (replace paths for your computer):

```bash
python /path/to/LEXA_PHASE7_RELEASE_BUNDLE_2026-10-25/APPLY/apply_phase7_fix.py --repo /path/to/LEXA-
```

On Windows, quote paths with spaces:

```powershell
python "C:\path\to\LEXA_PHASE7_RELEASE_BUNDLE_2026-10-25\APPLY\apply_phase7_fix.py" --repo "C:\path\to\LEXA-"
```

The installer applies the migration/test correction and adds the new Phase 7 validation workflow and two CI replay scripts. It does **not** commit, push, connect to any database, deploy a service, or modify production data.

## Then validate and open a PR

From the repository root:

```bash
git diff --check
python -m pytest apps/api/tests/test_phase7_approval_reversal_accounting.py -q
python scripts/run_clean_migration_replay.py --plan-only
git status --short
```

Review the diff and open a PR from a feature branch. The added Phase 7 workflow then performs the clean migration replay against an empty, local-to-the-runner PostgreSQL database and runs schema/RLS and accounting behavior checks. A green source/test run is necessary, but is not a substitute for the production backup and approval gates below.

## Production remains deliberately blocked

Do **not** apply migration 048 to production from this ZIP. The last verification showed: production still at migration 047; Vercel readiness returned HTTP 503; Render logged `phase7_release_schema_not_ready`; a current complete/restorable production backup and release approval were not verified; and authenticated end-to-end acceptance is still outstanding. The only earlier backup artifact reviewed was selective and dated 22 October, not a verified complete pre-048 restore point.

See `RELEASE_CHECKLIST.md`, `IMPLEMENTATION_STATUS.md` and `AUDIT/LEXA_RELEASE_GATE_REAUDIT_2026-10-25.md` for evidence and release criteria.
