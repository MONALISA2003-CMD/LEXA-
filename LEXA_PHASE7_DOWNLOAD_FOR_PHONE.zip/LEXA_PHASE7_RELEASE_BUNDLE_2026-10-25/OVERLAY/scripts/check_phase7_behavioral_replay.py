#!/usr/bin/env python3
"""Exercise migration 048 accounting triggers and approval guard in disposable local CI PostgreSQL.

This creates only synthetic fixtures. It refuses all non-loopback targets; never point it at
Neon, staging, production, or a customer database.
"""
from __future__ import annotations

import os
import sys
import uuid
from urllib.parse import urlsplit


def fail(message: str) -> None:
    print(f"FAIL: {message}", file=sys.stderr)
    raise SystemExit(1)


def main() -> int:
    if os.getenv("LEXA_ALLOW_DISPOSABLE_REPLAY") != "1":
        fail("requires LEXA_ALLOW_DISPOSABLE_REPLAY=1")
    database_url = os.getenv("DATABASE_URL", "").strip()
    parsed = urlsplit(database_url)
    host = (parsed.hostname or "").lower()
    dbname = (parsed.path or "").lstrip("/").lower()
    if parsed.scheme not in {"postgres", "postgresql"}:
        fail("DATABASE_URL must use postgres/postgresql")
    if host not in {"127.0.0.1", "localhost", "::1"}:
        fail("refusing non-loopback database host")
    if not any(token in dbname for token in ("replay", "test", "ci")) or dbname in {"neondb", "postgres", "production", "prod", "lexa"}:
        fail("database name must explicitly identify a disposable local replay/test/CI database")

    try:
        import psycopg
    except ImportError:
        fail("psycopg is required")

    def uid() -> str:
        return str(uuid.uuid4())

    def execute(cur, sql: str, params=()):
        cur.execute(sql, params)
        return cur

    def one(cur, sql: str, params=()):
        execute(cur, sql, params)
        return cur.fetchone()[0]

    conn = psycopg.connect(database_url)
    conn.autocommit = True
    suffix = uuid.uuid4().hex[:10]
    checks: list[str] = []
    try:
        with conn.cursor() as cur:
            actual_db = one(cur, "SELECT current_database()")
            if actual_db.lower() != dbname:
                fail(f"database mismatch: URL says {dbname}; server says {actual_db}")

            tenant = uid()
            user = uid()
            role = uid()
            membership = uid()
            branch = uid()
            warehouse = uid()
            location = uid()
            supplier = uid()
            unit = uid()
            category = uid()
            product = uid()
            variant = uid()
            po = uid()
            po_line = uid()
            receipt = uid()
            receipt_line = uid()
            inventory_tx = uid()
            bill = uid()
            bill_ledger = uid()
            payment = uid()
            payment_ledger = uid()
            purchase_return = uid()
            return_line = uid()
            return_inventory_tx = uid()
            return_ledger = uid()
            reversal_ledger = uid()
            approval_within = uid()
            approval_over = uid()
            approval_without_context = uid()
            bank_account = uid()
            payable_account = uid()
            inventory_account = uid()
            input_tax_account = uid()
            expense_account = uid()

            with conn.transaction():
                execute(cur, "INSERT INTO public.tenants(id,name,status) VALUES (%s,%s,'ACTIVE') RETURNING id", (tenant, f"phase7-behavior-{suffix}"))
                if str(cur.fetchone()[0]) != tenant:
                    fail("database unexpectedly changed the explicit tenant identifier")

                # The migration's tenant-created trigger must seed all five purchasing accounts.
                keys = [
                    "GOODS_RECEIVED_NOT_INVOICED", "LANDED_COST_CLEARING", "PURCHASES_CLEARING",
                    "SUPPLIER_ADVANCES", "PURCHASE_COST_VARIANCE",
                ]
                execute(cur, "SELECT count(*) FROM public.accounting_mappings WHERE tenant_id=%s AND mapping_key = ANY(%s)", (tenant, keys))
                if cur.fetchone()[0] != 5:
                    fail("tenant accounting-seed trigger did not create all five purchasing mappings")

                # Add the generic chart-of-accounts mappings that the legacy foundation expects.
                accounts = [
                    (inventory_account, "9100", "Test inventory", "ASSET", "DEBIT", "INVENTORY"),
                    (payable_account, "9101", "Test accounts payable", "LIABILITY", "CREDIT", "ACCOUNTS_PAYABLE"),
                    (input_tax_account, "9102", "Test input tax", "ASSET", "DEBIT", "INPUT_TAX"),
                    (expense_account, "9103", "Test operating expenses", "EXPENSE", "DEBIT", "OPERATING_EXPENSES"),
                    (bank_account, "9104", "Test bank", "ASSET", "DEBIT", "PAYMENT_CHANNEL.BANK"),
                ]
                for account_id, code, name, account_type, normal_balance, mapping_key in accounts:
                    execute(cur, "INSERT INTO public.accounting_accounts(id,tenant_id,code,name,account_type,normal_balance) VALUES (%s,%s,%s,%s,%s,%s)",
                            (account_id, tenant, f"{code}-{suffix}", name, account_type, normal_balance))
                    execute(cur, "INSERT INTO public.accounting_mappings(tenant_id,mapping_key,account_id) VALUES (%s,%s,%s)",
                            (tenant, mapping_key, account_id))

                # Build a minimal but relationally valid purchase/receipt fixture.
                execute(cur, "INSERT INTO public.branches(id,tenant_id,name,code) VALUES (%s,%s,%s,%s)",
                        (branch, tenant, "Phase 7 behavior branch", f"P7B-{suffix}"))
                execute(cur, "INSERT INTO public.warehouses(id,tenant_id,branch_id,name,code) VALUES (%s,%s,%s,%s,%s)",
                        (warehouse, tenant, branch, "Phase 7 behavior warehouse", f"P7W-{suffix}"))
                execute(cur, "INSERT INTO public.locations(id,tenant_id,warehouse_id,name,code) VALUES (%s,%s,%s,%s,%s)",
                        (location, tenant, warehouse, "Phase 7 behavior location", f"P7L-{suffix}"))
                execute(cur, "INSERT INTO public.parties(id,tenant_id,party_type,display_name,legal_name) VALUES (%s,%s,'ORGANIZATION',%s,%s)",
                        (supplier, tenant, "Phase 7 behavior supplier", "Phase 7 behavior supplier Ltd"))
                execute(cur, "INSERT INTO public.units(id,tenant_id,name,code,symbol,unit_type,allows_fraction,precision_scale) VALUES (%s,%s,'Each',%s,'ea','COUNT',false,0)",
                        (unit, tenant, f"P7EACH-{suffix}"))
                execute(cur, "INSERT INTO public.categories(id,tenant_id,name,code) VALUES (%s,%s,%s,%s)",
                        (category, tenant, "Phase 7 behavior category", f"P7CAT-{suffix}"))
                execute(cur, "INSERT INTO public.products(id,tenant_id,category_id,name,product_type,has_variants) VALUES (%s,%s,%s,%s,'STOCKED',true)",
                        (product, tenant, category, "Phase 7 behavior product"))
                execute(cur, "INSERT INTO public.product_variants(id,tenant_id,product_id,name,sku,base_unit_id,track_inventory,allow_fractional_quantity) VALUES (%s,%s,%s,%s,%s,%s,true,false)",
                        (variant, tenant, product, "Phase 7 behavior variant", f"P7SKU-{suffix}", unit))
                execute(cur, "INSERT INTO public.purchase_orders(id,tenant_id,po_number,supplier_party_id,branch_id,receiving_location_id,status,order_date,currency_code,subtotal,tax_amount,total) VALUES (%s,%s,%s,%s,%s,%s,'OPEN',CURRENT_DATE,'UGX',100,0,100)",
                        (po, tenant, f"P7-PO-{suffix}", supplier, branch, location))
                execute(cur, "INSERT INTO public.purchase_order_lines(id,tenant_id,purchase_order_id,line_number,variant_id,ordered_quantity,received_quantity,unit_cost,tax_rate,tax_amount,line_subtotal,line_total,description) VALUES (%s,%s,%s,1,%s,10,0,10,0,0,100,100,'CI fixture')",
                        (po_line, tenant, po, variant))
                execute(cur, "INSERT INTO public.purchase_receipts(id,tenant_id,receipt_number,purchase_order_id,receiving_location_id,status,received_at,landed_cost_total,landed_cost_allocation_method) VALUES (%s,%s,%s,%s,%s,'DRAFT',now(),0,'BY_VALUE')",
                        (receipt, tenant, f"P7-RCPT-{suffix}", po, location))
                execute(cur, "INSERT INTO public.purchase_receipt_lines(id,tenant_id,receipt_id,purchase_order_line_id,variant_id,received_quantity,unit_cost,base_unit_cost,landed_cost_amount,notes) VALUES (%s,%s,%s,%s,%s,10,10,10,0,'CI fixture')",
                        (receipt_line, tenant, receipt, po_line, variant))
                execute(cur, "INSERT INTO public.inventory_transactions(id,tenant_id,location_id,variant_id,transaction_type,quantity_delta,unit_cost,total_cost,balance_after,reference_type,reference_id,idempotency_key,metadata) VALUES (%s,%s,%s,%s,'PURCHASE_RECEIPT',10,10,100,10,'purchase_receipt',%s,%s,'{\"fixture\":true}'::jsonb)",
                        (inventory_tx, tenant, location, variant, receipt, f"p7-receipt-{suffix}"))
                execute(cur, "UPDATE public.purchase_receipts SET status='POSTED',posted_at=now() WHERE id=%s", (receipt,))

                def assert_posted_balanced(source_type: str, source_id: str, entry_role: str) -> str:
                    execute(cur, "SELECT id,status FROM public.journal_entries WHERE tenant_id=%s AND source_type=%s AND source_id=%s AND entry_role=%s ORDER BY created_at",
                            (tenant, source_type, source_id, entry_role))
                    rows = cur.fetchall()
                    if len(rows) != 1 or rows[0][1] != "POSTED":
                        fail(f"{entry_role} must create exactly one POSTED journal; found {len(rows)}")
                    journal_id = str(rows[0][0])
                    execute(cur, "SELECT count(*),COALESCE(sum(debit),0),COALESCE(sum(credit),0) FROM public.journal_lines WHERE tenant_id=%s AND journal_entry_id=%s",
                            (tenant, journal_id))
                    count, debit, credit = cur.fetchone()
                    if count < 2 or debit != credit or debit <= 0:
                        fail(f"{entry_role} journal is not balanced (lines={count}, debit={debit}, credit={credit})")
                    return journal_id

                receipt_journal = assert_posted_balanced("PURCHASE_RECEIPT", receipt, "RECEIPT_RECOGNITION")
                if str(one(cur, "SELECT public.post_purchase_receipt_journal(%s)", (receipt,))) != receipt_journal:
                    fail("receipt journal replay did not return the original journal ID")
                execute(cur, "SELECT count(*) FROM public.journal_entries WHERE tenant_id=%s AND source_type='PURCHASE_RECEIPT' AND source_id=%s AND entry_role='RECEIPT_RECOGNITION'", (tenant, receipt))
                if cur.fetchone()[0] != 1:
                    fail("receipt journal replay created a duplicate journal")
                checks.append("receipt trigger posts one balanced, idempotent journal")

                # Supplier bill -> supplier ledger -> accounting journal trigger.
                bill = uid()
                bill_ledger = uid()
                execute(cur, "INSERT INTO public.supplier_bills(id,tenant_id,supplier_party_id,purchase_order_id,purchase_receipt_id,bill_number,bill_date,due_date,currency_code,subtotal,tax_amount,other_charges,total,status,match_status,supplier_reference) VALUES (%s,%s,%s,%s,%s,%s,CURRENT_DATE,CURRENT_DATE+30,'UGX',100,0,0,100,'POSTED','MATCHED',%s)",
                        (bill, tenant, supplier, po, receipt, f"P7-BILL-{suffix}", f"P7-REF-{suffix}"))
                execute(cur, "INSERT INTO public.supplier_ledger_entries(id,tenant_id,supplier_party_id,currency_code,entry_type,source_type,source_id,reference,debit_amount,credit_amount,metadata) VALUES (%s,%s,%s,'UGX','BILL','supplier_bill',%s,%s,0,100,'{\"fixture\":true}'::jsonb)",
                        (bill_ledger, tenant, supplier, bill, f"P7-BILL-{suffix}"))
                bill_journal = assert_posted_balanced("SUPPLIER_LEDGER", bill_ledger, "BILL")
                if str(one(cur, "SELECT public.post_supplier_ledger_journal(%s)", (bill_ledger,))) != bill_journal:
                    fail("supplier bill journal replay did not return the original journal ID")
                if one(cur, "SELECT count(*) FROM public.journal_entries WHERE tenant_id=%s AND source_type='SUPPLIER_LEDGER' AND source_id=%s AND entry_role='BILL'", (tenant, bill_ledger)) != 1:
                    fail("supplier bill journal replay created a duplicate journal")
                checks.append("supplier bill ledger trigger posts one balanced, idempotent journal")

                # Exercise the exact payment branch that previously referenced undeclared v_cash.
                payment = uid()
                payment_ledger = uid()
                execute(cur, "INSERT INTO public.supplier_payments(id,tenant_id,supplier_party_id,payment_number,payment_date,currency_code,amount,payment_method,reference,status) VALUES (%s,%s,%s,%s,CURRENT_DATE,'UGX',100,'BANK_TRANSFER',%s,'POSTED')",
                        (payment, tenant, supplier, f"P7-PAY-{suffix}", f"P7-BANK-{suffix}"))
                execute(cur, "INSERT INTO public.supplier_ledger_entries(id,tenant_id,supplier_party_id,currency_code,entry_type,source_type,source_id,reference,debit_amount,credit_amount,metadata) VALUES (%s,%s,%s,'UGX','PAYMENT','supplier_payment',%s,%s,100,0,'{\"fixture\":true}'::jsonb)",
                        (payment_ledger, tenant, supplier, payment, f"P7-PAY-{suffix}"))
                payment_journal = assert_posted_balanced("SUPPLIER_LEDGER", payment_ledger, "PAYMENT")
                if str(one(cur, "SELECT public.post_supplier_ledger_journal(%s)", (payment_ledger,))) != payment_journal:
                    fail("supplier payment journal replay did not return the original journal ID")
                if one(cur, "SELECT count(*) FROM public.journal_entries WHERE tenant_id=%s AND source_type='SUPPLIER_LEDGER' AND source_id=%s AND entry_role='PAYMENT'", (tenant, payment_ledger)) != 1:
                    fail("supplier payment journal replay created a duplicate journal")
                checks.append("supplier bank-payment trigger posts one balanced journal using a_cash")

                # Supplier return credit and compensating reversal journal.
                purchase_return = uid()
                return_line = uid()
                return_inventory_tx = uid()
                return_ledger = uid()
                reversal_ledger = uid()
                execute(cur, "INSERT INTO public.purchase_returns(id,tenant_id,return_number,purchase_receipt_id,receiving_location_id,status,reason,notes) VALUES (%s,%s,%s,%s,%s,'POSTED','CI reversal fixture','Disposable CI fixture')",
                        (purchase_return, tenant, f"P7-RET-{suffix}", receipt, location))
                execute(cur, "INSERT INTO public.purchase_return_lines(id,tenant_id,purchase_return_id,purchase_receipt_line_id,variant_id,quantity,unit_cost,supplier_credit_unit_cost,reason) VALUES (%s,%s,%s,%s,%s,10,10,10,'CI reversal fixture')",
                        (return_line, tenant, purchase_return, receipt_line, variant))
                execute(cur, "INSERT INTO public.inventory_transactions(id,tenant_id,location_id,variant_id,transaction_type,quantity_delta,unit_cost,total_cost,balance_after,reference_type,reference_id,idempotency_key,metadata) VALUES (%s,%s,%s,%s,'PURCHASE_RETURN',-10,10,100,0,'purchase_return',%s,%s,'{\"fixture\":true}'::jsonb)",
                        (return_inventory_tx, tenant, location, variant, purchase_return, f"p7-return-{suffix}"))
                execute(cur, "INSERT INTO public.supplier_ledger_entries(id,tenant_id,supplier_party_id,currency_code,entry_type,source_type,source_id,reference,debit_amount,credit_amount,metadata) VALUES (%s,%s,%s,'UGX','RETURN_CREDIT','purchase_return',%s,%s,0,100,'{\"fixture\":true}'::jsonb)",
                        (return_ledger, tenant, supplier, purchase_return, f"P7-RET-{suffix}"))
                return_journal = assert_posted_balanced("SUPPLIER_LEDGER", return_ledger, "RETURN_CREDIT")
                execute(cur, "INSERT INTO public.supplier_ledger_entries(id,tenant_id,supplier_party_id,currency_code,entry_type,source_type,source_id,reference,debit_amount,credit_amount,metadata) VALUES (%s,%s,%s,'UGX','RETURN_REVERSAL','purchase_return',%s,%s,100,0,'{\"fixture\":true}'::jsonb)",
                        (reversal_ledger, tenant, supplier, purchase_return, f"P7-RET-REV-{suffix}"))
                execute(cur, "UPDATE public.purchase_returns SET status='REVERSED',reversal_reason='CI compensating-entry test',reversed_at=now() WHERE id=%s", (purchase_return,))
                execute(cur, "SELECT status FROM public.journal_entries WHERE id=%s", (return_journal,))
                if cur.fetchone()[0] != "REVERSED":
                    fail("return-credit source journal was not marked REVERSED")
                execute(cur, "SELECT count(*),COALESCE(sum(jl.debit),0),COALESCE(sum(jl.credit),0) FROM public.journal_entries je JOIN public.journal_lines jl ON jl.tenant_id=je.tenant_id AND jl.journal_entry_id=je.id WHERE je.tenant_id=%s AND je.reversal_of_id=%s AND je.status='POSTED'", (tenant, return_journal))
                count, debit, credit = cur.fetchone()
                if count < 2 or debit != credit or debit <= 0:
                    fail("return reversal did not create a balanced POSTED compensating journal")
                checks.append("supplier return reversal creates a posted compensating journal and preserves the original")

                # Database authority, not UI-only, enforces manager approval caps.
                approval = one(cur, "SELECT id FROM public.permissions WHERE code='purchasing.approve'")
                execute(cur, "INSERT INTO public.users(id,email,password_hash,is_active,display_name) VALUES (%s,%s,'not-used-for-auth',true,'Phase7 approval fixture')",
                        (user, f"p7-approval-{suffix}@example.invalid"))
                manager_name = f"Phase7 Manager {suffix}"
                execute(cur, "INSERT INTO public.roles(id,tenant_id,name,description) VALUES (%s,%s,%s,'Disposable CI role')", (role, tenant, manager_name))
                execute(cur, "INSERT INTO public.tenant_memberships(id,tenant_id,user_id,status) VALUES (%s,%s,%s,'ACTIVE')", (membership, tenant, user))
                execute(cur, "INSERT INTO public.membership_roles(membership_id,role_id) VALUES (%s,%s)", (membership, role))
                execute(cur, "INSERT INTO public.role_permissions(role_id,permission_id) VALUES (%s,%s)", (role, approval))
                execute(cur, "SELECT set_config('app.tenant_id',%s,true)", (tenant,))
                execute(cur, "INSERT INTO public.purchase_approval_limits(tenant_id,role_name,currency_code,max_approval_amount) VALUES (%s,%s,'UGX',1000000)", (tenant, manager_name))
                for po_id, po_number, total in [
                    (approval_within, f"P7-OK-{suffix}", 750000),
                    (approval_over, f"P7-OVER-{suffix}", 1000001),
                    (approval_without_context, f"P7-NOCTX-{suffix}", 100),
                ]:
                    execute(cur, "INSERT INTO public.purchase_orders(id,tenant_id,po_number,supplier_party_id,branch_id,receiving_location_id,status,order_date,currency_code,subtotal,tax_amount,total) VALUES (%s,%s,%s,%s,%s,%s,'SUBMITTED',CURRENT_DATE,'UGX',%s,0,%s)",
                            (po_id, tenant, po_number, supplier, branch, location, total, total))

            # Within-limit approval succeeds.
            with conn.transaction():
                execute(cur, "SELECT set_config('app.user_id',%s,true)", (user,))
                execute(cur, "UPDATE public.purchase_orders SET status='OPEN',approved_by=%s,approved_at=now() WHERE id=%s", (user, approval_within))
            if one(cur, "SELECT status FROM public.purchase_orders WHERE id=%s", (approval_within,)) != "OPEN":
                fail("within-limit manager approval did not pass")

            # Above-limit approval must fail with the expected contract code.
            try:
                with conn.transaction():
                    execute(cur, "SELECT set_config('app.user_id',%s,true)", (user,))
                    execute(cur, "UPDATE public.purchase_orders SET status='OPEN',approved_by=%s,approved_at=now() WHERE id=%s", (user, approval_over))
            except Exception as exc:
                if "PURCHASE_APPROVAL_LIMIT_EXCEEDED_OR_NOT_CONFIGURED" not in str(exc):
                    fail(f"above-limit approval failed for the wrong reason: {exc}")
            else:
                fail("above-limit manager approval unexpectedly passed")
            if one(cur, "SELECT status FROM public.purchase_orders WHERE id=%s", (approval_over,)) != "SUBMITTED":
                fail("above-limit purchase order status changed despite rejection")

            # Missing user context must fail closed.
            try:
                with conn.transaction():
                    execute(cur, "UPDATE public.purchase_orders SET status='OPEN',approved_at=now() WHERE id=%s", (approval_without_context,))
            except Exception as exc:
                if "PURCHASE_APPROVER_CONTEXT_REQUIRED" not in str(exc):
                    fail(f"approval without context failed for the wrong reason: {exc}")
            else:
                fail("approval without user context unexpectedly passed")
            if one(cur, "SELECT status FROM public.purchase_orders WHERE id=%s", (approval_without_context,)) != "SUBMITTED":
                fail("no-context purchase order status changed despite rejection")
            checks.append("approval limit trigger accepts within-cap manager, rejects above-cap and rejects missing context")

            print("PASS: Phase 7 behavioral replay on disposable local PostgreSQL.")
            for check in checks:
                print(f"  - {check}")
            print("All fixture writes are confined to the local disposable CI database.")
            return 0
    finally:
        conn.close()


if __name__ == "__main__":
    raise SystemExit(main())
