#!/usr/bin/env python3
"""Verify migration 048 contracts, tenant seed triggers, and approval-limit RLS.

This script is intentionally restricted to a disposable local PostgreSQL database.
It creates two temporary test tenants and writes fixture rows; never point it at Neon,
production, staging, or a customer database.
"""
from __future__ import annotations

import os
import sys
import uuid
from urllib.parse import urlsplit


def fail(message: str) -> None:
    print(f"FAIL: {message}", file=sys.stderr)
    raise SystemExit(1)


def main() -> int:
    if os.getenv("LEXA_ALLOW_DISPOSABLE_REPLAY") != "1":
        fail("requires LEXA_ALLOW_DISPOSABLE_REPLAY=1")

    database_url = os.getenv("DATABASE_URL", "").strip()
    parsed = urlsplit(database_url)
    host = (parsed.hostname or "").lower()
    dbname = (parsed.path or "").lstrip("/").lower()
    if parsed.scheme not in {"postgres", "postgresql"}:
        fail("DATABASE_URL must use postgres/postgresql")
    if host not in {"127.0.0.1", "localhost", "::1"}:
        fail("refusing non-loopback database host")
    if not any(token in dbname for token in ("replay", "test", "ci")):
        fail("database name must explicitly identify a disposable replay/test/CI database")
    if dbname in {"neondb", "postgres", "production", "prod", "lexa"}:
        fail("refusing a production-like database name")

    try:
        import psycopg
    except ImportError:
        fail("psycopg is required")

    expected_migrations = [
        "045_intelligence_foundation",
        "046_intelligence_documents",
        "047_analytics_forecast_history_backfill",
        "048_phase7_approval_limits_reversals_accounting",
    ]
    mapping_keys = [
        "GOODS_RECEIVED_NOT_INVOICED",
        "LANDED_COST_CLEARING",
        "PURCHASES_CLEARING",
        "SUPPLIER_ADVANCES",
        "PURCHASE_COST_VARIANCE",
    ]

    with psycopg.connect(database_url) as conn:
        with conn.cursor() as cur:
            cur.execute("SELECT current_database()")
            actual_db = cur.fetchone()[0]
            if actual_db.lower() != dbname:
                fail(f"connected database mismatch: URL says {dbname}, server says {actual_db}")

            cur.execute(
                "SELECT version::text FROM public.schema_migrations WHERE version::text = ANY(%s) ORDER BY applied_at, version",
                (expected_migrations,),
            )
            applied_order = [row[0] for row in cur.fetchall()]
            if applied_order != expected_migrations:
                fail(
                    "migration markers are missing or out of order: "
                    + ", ".join(applied_order)
                )

            cur.execute(
                """
                SELECT
                  EXISTS (SELECT 1 FROM public.schema_migrations WHERE version=%s),
                  to_regclass('public.purchase_approval_limits') IS NOT NULL,
                  to_regprocedure('public.enforce_purchase_order_approval_limit()') IS NOT NULL,
                  to_regprocedure('public.post_purchase_receipt_journal(uuid)') IS NOT NULL,
                  to_regprocedure('public.post_supplier_ledger_journal(uuid)') IS NOT NULL,
                  EXISTS (SELECT 1 FROM pg_class c WHERE c.oid=to_regclass('public.purchase_approval_limits')
                          AND c.relrowsecurity AND c.relforcerowsecurity),
                  EXISTS (SELECT 1 FROM pg_policy p WHERE p.polrelid=to_regclass('public.purchase_approval_limits')
                          AND p.polname='purchase_approval_limits_tenant_isolation'),
                  EXISTS (SELECT 1 FROM pg_trigger t WHERE t.tgrelid=to_regclass('public.purchase_receipts')
                          AND t.tgname='trg_purchasing_receipt_after_post' AND NOT t.tgisinternal),
                  EXISTS (SELECT 1 FROM pg_trigger t WHERE t.tgrelid=to_regclass('public.supplier_ledger_entries')
                          AND t.tgname='trg_purchasing_supplier_ledger_after_insert' AND NOT t.tgisinternal),
                  (SELECT count(*)=3 FROM information_schema.columns WHERE table_schema='public'
                    AND table_name='purchase_returns' AND column_name IN ('reversal_reason','reversed_by','reversed_at'))
                """,
                ("048_phase7_approval_limits_reversals_accounting",),
            )
            names = [
                "migration marker", "approval-limit table", "approval guard function",
                "receipt journal function", "supplier journal function", "forced approval-limit RLS",
                "approval-limit tenant policy", "receipt journal trigger", "supplier journal trigger",
                "return reversal columns",
            ]
            values = cur.fetchone()
            failures = [name for name, value in zip(names, values, strict=True) if not value]
            if failures:
                fail("Phase 7 contracts absent: " + ", ".join(failures))

            cur.execute("SELECT to_regrole('lexa_app') IS NOT NULL")
            if not cur.fetchone()[0]:
                fail("runtime role lexa_app is missing")
            cur.execute(
                "SELECT has_function_privilege('lexa_app', 'public.seed_purchasing_accounting_accounts(uuid)', 'EXECUTE')"
            )
            if cur.fetchone()[0]:
                fail("tenant seed helper must not be directly executable by lexa_app")

            suffix = uuid.uuid4().hex[:12]
            tenant_a_name = f"phase7-ci-a-{suffix}"
            tenant_b_name = f"phase7-ci-b-{suffix}"
            cur.execute(
                "INSERT INTO public.tenants(name,status) VALUES (%s,'ACTIVE') RETURNING id",
                (tenant_a_name,),
            )
            tenant_a = cur.fetchone()[0]
            cur.execute(
                "INSERT INTO public.tenants(name,status) VALUES (%s,'ACTIVE') RETURNING id",
                (tenant_b_name,),
            )
            tenant_b = cur.fetchone()[0]

            for tenant_id in (tenant_a, tenant_b):
                cur.execute(
                    "SELECT count(*) FROM public.accounting_mappings WHERE tenant_id=%s AND mapping_key = ANY(%s)",
                    (tenant_id, mapping_keys),
                )
                if cur.fetchone()[0] != len(mapping_keys):
                    fail(f"tenant seed trigger did not create all five account mappings for {tenant_id}")

            cur.execute(
                """
                INSERT INTO public.purchase_approval_limits(tenant_id,role_name,currency_code,max_approval_amount)
                VALUES (%s,'Manager','UGX',1000000), (%s,'Manager','UGX',250000)
                """,
                (tenant_a, tenant_b),
            )

    # Test forced RLS as the actual least-privilege application role. Each check
    # is a separate transaction so SET LOCAL ROLE and app.tenant_id cannot leak.
    def visible_rows(tenant_id: uuid.UUID | None) -> list[tuple[str, str, int]]:
        with psycopg.connect(database_url) as conn:
            with conn.transaction():
                with conn.cursor() as cur:
                    cur.execute("SET LOCAL ROLE lexa_app")
                    if tenant_id is not None:
                        cur.execute("SELECT set_config('app.tenant_id', %s, true)", (str(tenant_id),))
                    cur.execute(
                        "SELECT tenant_id::text, role_name, max_approval_amount::int FROM public.purchase_approval_limits ORDER BY tenant_id"
                    )
                    return cur.fetchall()

    if visible_rows(None):
        fail("approval limits leaked without tenant context")
    rows_a = visible_rows(tenant_a)
    rows_b = visible_rows(tenant_b)
    if len(rows_a) != 1 or rows_a[0][0] != str(tenant_a) or rows_a[0][2] != 1_000_000:
        fail("tenant A did not see exactly its own approval-limit row")
    if len(rows_b) != 1 or rows_b[0][0] != str(tenant_b) or rows_b[0][2] != 250_000:
        fail("tenant B did not see exactly its own approval-limit row")

    print("PASS: ordered migrations 045-048, all 10 Phase 7 contracts, 5 accounting mappings per new tenant, and tenant-isolated approval-limit RLS.")
    print("Disposable CI fixture writes were confined to the local replay database.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
