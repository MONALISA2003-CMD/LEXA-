#!/usr/bin/env python3
"""Safely apply the LEXA Phase 7 source patch and additive CI/test files.

This does not connect to any database, deploy, commit, or push. It refuses to
replace conflicting overlay files and requires the expected source patch to apply.
"""
from __future__ import annotations

import argparse
import hashlib
import shutil
import subprocess
import sys
from pathlib import Path

BUNDLE = Path(__file__).resolve().parents[1]
PATCH = BUNDLE / "PATCHES" / "0001-fix-phase7-048-cash-variable.patch"
OVERLAY = BUNDLE / "OVERLAY"
OVERLAY_FILES = {
    OVERLAY / ".github/workflows/lexa-phase7-validation.yml": Path(".github/workflows/lexa-phase7-validation.yml"),
    OVERLAY / "scripts/check_phase7_replay.py": Path("scripts/check_phase7_replay.py"),
    OVERLAY / "scripts/check_phase7_behavioral_replay.py": Path("scripts/check_phase7_behavioral_replay.py"),
}
FIX_TEST = "test_supplier_payment_journal_uses_the_declared_cash_account_variable"


def run(args: list[str], cwd: Path, check: bool = True) -> subprocess.CompletedProcess[str]:
    result = subprocess.run(args, cwd=cwd, text=True, capture_output=True, check=False)
    if check and result.returncode:
        raise RuntimeError(
            f"Command failed ({result.returncode}): {' '.join(args)}\n"
            f"stdout:\n{result.stdout}\nstderr:\n{result.stderr}"
        )
    return result


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def inspect_phase7_state(repo: Path) -> tuple[bool, bool]:
    migration_path = repo / "migrations/048_phase7_approval_limits_reversals_accounting.sql"
    test_path = repo / "apps/api/tests/test_phase7_approval_reversal_accounting.py"
    if not migration_path.is_file() or not test_path.is_file():
        raise RuntimeError("Required migration/test source files are missing. Use the current main checkout.")
    migration = migration_path.read_text(encoding="utf-8")
    test_text = test_path.read_text(encoding="utf-8")
    try:
        section = migration.split("CREATE OR REPLACE FUNCTION public.post_supplier_ledger_journal", 1)[1].split(
            "CREATE OR REPLACE FUNCTION public.purchasing_supplier_ledger_after_insert", 1
        )[0]
    except IndexError as exc:
        raise RuntimeError("Could not isolate post_supplier_ledger_journal function in migration 048.") from exc
    bad_count = section.count("v_cash")
    declared = "a_cash uuid;" in section
    already_fixed = bad_count == 0 and "a_cash := public.accounting_mapping_account(e.tenant_id,v_map);" in section
    if bad_count == 3 and declared:
        migration_needs_patch = True
    elif already_fixed:
        migration_needs_patch = False
    else:
        raise RuntimeError(
            f"Unexpected source state: post_supplier_ledger_journal has {bad_count} v_cash reference(s); "
            f"a_cash declaration present={declared}. No source files changed. Review manually."
        )
    test_present = FIX_TEST in test_text
    if not migration_needs_patch and not test_present:
        raise RuntimeError("SQL appears fixed but regression test is absent; refusing an ambiguous partial state.")
    return migration_needs_patch, test_present


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", required=True, type=Path, help="path to the checked-out LEXA- Git repository")
    args = parser.parse_args()
    repo = args.repo.resolve()
    if not repo.is_dir():
        print(f"ERROR: repository path does not exist: {repo}", file=sys.stderr)
        return 2

    try:
        top = Path(run(["git", "rev-parse", "--show-toplevel"], cwd=repo).stdout.strip()).resolve()
        if top != repo:
            raise RuntimeError(f"--repo must be the repository root; git root is {top}")
        migration_needs_patch, test_present = inspect_phase7_state(repo)

        # Preflight all additive files before applying the source patch.
        for source, relative in OVERLAY_FILES.items():
            if not source.is_file():
                raise RuntimeError(f"Package overlay file is missing: {source}")
            target = repo / relative
            if target.exists() and target.read_bytes() != source.read_bytes():
                raise RuntimeError(
                    f"Refusing to overwrite a different existing file: {relative}. "
                    "Compare/merge it manually, then rerun. No overlay files were copied."
                )

        if migration_needs_patch:
            checked = run(["git", "apply", "--check", str(PATCH)], cwd=repo, check=False)
            if checked.returncode:
                raise RuntimeError(
                    "Corrected patch did not apply to this checkout; no files changed. "
                    "This package expects the recorded main source.\n" + checked.stderr
                )
            run(["git", "apply", str(PATCH)], cwd=repo)
            print("APPLIED: migration 048 cash-variable correction and regression test")
        else:
            print("SKIPPED: migration fix and regression test are already present")

        installed: list[str] = []
        for source, relative in OVERLAY_FILES.items():
            target = repo / relative
            if target.exists():
                print(f"OK: already installed {relative}")
                continue
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source, target)
            installed.append(str(relative))
            print(f"ADDED: {relative}")

        # Post-write source verification.
        migration_needs_patch_after, test_present_after = inspect_phase7_state(repo)
        if migration_needs_patch_after or not test_present_after:
            raise RuntimeError("Post-install verification did not pass; inspect git diff before proceeding.")
        print("PASS: source state verified; no database connection, commit, push, or deployment performed.")
        print("Next: review `git diff --check`, run API tests, then open a PR to main.")
        return 0
    except Exception as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
