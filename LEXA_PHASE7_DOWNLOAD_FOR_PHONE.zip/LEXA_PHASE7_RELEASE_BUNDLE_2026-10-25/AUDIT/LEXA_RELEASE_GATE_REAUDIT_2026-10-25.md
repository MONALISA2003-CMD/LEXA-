# LEXA Phase 7 Release Gate Re-audit

**Audit date:** 25 October 2026  
**Evidence window:** live Render logs observed through 2026-10-25 12:24:33 UTC  
**Decision: BLOCKED — do not mark the full stack green.**

## Executive decision

Production is not migration-048-ready. The live Neon database `neondb` on project `LEXA` (`wispy-mud-75323042`), branch `lexa-live` (`br-soft-star-b1dj2m2w`), records migration 047 as its latest migration. Migration marker `048_phase7_approval_limits_reversals_accounting` is absent and `public.purchase_approval_limits` is absent. The ten boolean contracts queried directly from `apps/api/app/phase7_release_gate.py` all evaluate false in production.

The application gate is behaving appropriately: Render is still emitting `phase7_release_schema_not_ready`. Do not bypass the gate or treat the current deploy as release-ready.

## Separate Neon backup project: verified to exist, but not a current complete pre-048 backup

- **Project:** `LEXA-BACKUP-20261022`
- **Project ID:** `weathered-tooth-59279917`
- **Database:** `lexa_backup`, branch `lexa-backup` (`br-noisy-water-bay4966c`)
- **Existing manual snapshot:** `LEXA-Backup-Verified-2026-10-22`, created 2026-10-22 05:57:22 UTC, about 46 MB.

The backup manifest records a selective recovery copy of 119 public tables. Exact row-content checks matched for all 119 tables at capture time; 107 tables included data and 12 were excluded. Explicit omissions included analytics metric/refresh tables, sessions, security tokens, outbox events, event-consumption/idempotency tables; production role passwords and short-lived security-token rows were not copied. The manifest expressly calls it a *selective native schema and data copy, not a byte-identical provider snapshot*.

That recovery copy is stale for the release in question: it records migrations only through `045_phase5_journal_period_date_guard`, has nine tenant records instead of the seven currently on live production, and has zero sales/payment/purchase-order rows. It cannot be treated as the normal current production backup needed before migration 048.

A fresh Neon snapshot attempt against the current `lexa-live` branch was rejected by Neon with `not allowed to snapshot non-root branch`. The live project has no listed snapshots and the branch has no configured snapshot schedule. **No fresh production snapshot was created, and no branch was deleted.** Use the approved Neon backup/PITR/export process suitable for the live branch and verify its restore point before authorizing the migration.

## Migration source and isolated schema-contract check

Source files were verified on GitHub `main`:

- [`migrations/048_phase7_approval_limits_reversals_accounting.sql`](https://github.com/MONALISA2003-CMD/LEXA-/blob/main/migrations/048_phase7_approval_limits_reversals_accounting.sql) — source SHA `bedb55d17aa9a219e7266f5ba7a3a71009d2506e`.
- [`apps/api/app/phase7_release_gate.py`](https://github.com/MONALISA2003-CMD/LEXA-/blob/main/apps/api/app/phase7_release_gate.py) — source SHA `a5a138d1a4b5add6086427ad115c91ec082a2b6f`.

The migration is explicitly forward-only and warns against production execution without the normal backup/release gate. It adds the approval-limit table and forced tenant RLS/policy, purchasing permission records and role mappings, tenant accounting seed mappings, return reversal columns/status constraint, approval enforcement and supplier/receipt accounting journal functions/triggers, backfills existing posted purchasing events, revokes direct runtime execution from trigger-only helper functions, and inserts the migration marker at the end of the transaction.

A schema-level check on the separate Neon replay project `LEXA-PHASE7-REPLAY-20261022` (`wispy-frog-93010235`), root branch `phase7-clean-replay` (`br-jolly-mode-b966dwys`), database `neondb`, returned all ten gate contracts as true. That database records migrations 046, 047 and 048 in order. This is useful **isolated schema-contract evidence only**: that replay database has zero tenants and zero business transactions, so it does not prove seed-account behavior, trigger behavior against actual events, or the authenticated business flows. The separate child branch named `phase7-8-full-audit-replay-20261025` had 048 but was not used as ordered migration-sequence evidence because its marker check did not show 046/047.

## Live production gate — FAIL

The exact contract checks in `phase7_release_gate.py` produced these production results:

| Contract | Live production |
|---|---|
| Migration 048 marker present | FAIL |
| `purchase_approval_limits` table present | FAIL |
| `enforce_purchase_order_approval_limit()` present | FAIL |
| `post_purchase_receipt_journal(uuid)` present | FAIL |
| `post_supplier_ledger_journal(uuid)` present | FAIL |
| Approval-limit RLS and FORCE RLS enabled | FAIL |
| `purchase_approval_limits_tenant_isolation` policy present | FAIL |
| Receipt-posting journal trigger present | FAIL |
| Supplier-ledger journal trigger present | FAIL |
| `purchase_returns.reversal_reason` present | FAIL |

**Production SQL was read-only during this audit. Migration 048 was not executed against production and no test/business data was written to production.**

## Render status

- Service: `LEXA`, `srv-dakm8k95efls73egg9a0`, URL `https://lexa-n10e.onrender.com`.
- Latest Render deploy inspected: `dep-dbetr7ajnfac73e56tkg`, status `live`, commit `aa4cdf46c9f59d4be120886b63613122cd3bf94a`.
- Render application logs contain repeated `phase7_release_schema_not_ready` events through 2026-10-25 12:24:33 UTC, after the current deployment.
- A fresh `/ready` HTTP-200 response could not be obtained in this audit environment; provider log query did not return request records for `/ready`. The uploaded audit pack previously recorded repeated `/ready` HTTP 503 responses. **There is no verified evidence of `/ready` returning 200, and the gate logs definitely have not cleared.**

## Analytics and forecast readiness — FAIL / not proven

Live production has seven active tenant records. Table counts read directly from Neon:

- `sales`, `payments`, `purchase_orders`, `purchase_receipts`, `supplier_bills`, `journal_entries`, `supplier_ledger_entries`, `transaction_lines`, `business_transactions`, `inventory_transactions`, `sale_returns`, `refund_records`, and `expense_records`: zero rows in the inspected live database (supplier bills table exists but is empty).
- Each of `analytics_product_daily_metrics`, `analytics_daily_business_metrics`, `analytics_branch_daily_metrics`, `analytics_customer_purchase_patterns`, and `analytics_inventory_health_metrics`: zero rows.
- `analytics_refresh_runs`: 14 rows, all recorded as `SUCCEEDED`, across seven tenants. Latest per-tenant successful range is 2026-08-31 through 2026-10-25, but metric outputs are still empty.

The refresh function marks a run `SUCCEEDED` after its SQL completes, even if its source-date query yields no event dates and therefore inserts no daily business metric rows. The 14 success markers and a 56-day date span are not sufficient evidence that forecast inputs exist or are usable. Do not present forecasts as ready. The application should show a clear no-data/insufficient-history state until real tenant-scoped source events are present and metric/forecast completeness is checked.

## Authenticated staging acceptance and AI — NOT RUN

No authenticated staging session or credentials were available in the audit context. Therefore the following have **not** been runtime-verified:

1. Sign-in and workspace selection.
2. Sale → stock decrement → recorded payment method → journal → report.
3. Purchase order → partial receipt → supplier bill/AP → payment allocation → supplier balance.
4. AI request → central policy route → answer.
5. Business-only AI smoke test, provider/model eligibility, end-to-end latency, cross-tenant isolation, and rejection of a non-LEXA question.

No provider secrets were read or exposed and no live model request was sent. CI/source-level safeguards are not runtime proof of provider eligibility, latency, or tenant isolation.

## Release decision and exact next steps

1. **Secure and verify a fresh, restorable production backup** through the approved Neon process for the current live branch. Keep the old selective backup as a separate recovery artifact, not as the pre-migration backup. Do not delete branches to make capacity.
2. Record the required human release approval and rollback/restore point in the project's normal release process.
3. The schema-level ordered 046/047/048 replay check has passed on the isolated `phase7-clean-replay` database. Before production, complete any remaining isolated behavioral tests (especially accounting seeds and receipt/bill/payment/return trigger behavior with fixture data) in a safe staging database.
4. Apply migration 048 only through the approved production migration workflow after steps 1–3 are satisfied.
5. Rerun the read-only SQL supplied in `neon_read_only_verification.sql` on the intended live branch/database; require marker, table, RLS/policy, functions, triggers and return fields all to pass.
6. Verify a direct HTTP `200` from Render `/ready` and confirm new logs no longer contain `phase7_release_schema_not_ready`.
7. Run the authenticated staging acceptance flows and AI smoke/tenant-isolation/non-LEXA tests; record status and latency without logging secrets.
8. Diagnose analytics refreshes against real staging fixtures, verify the metric tables populate and freshness/gap/partial-history guards work; do not write fixture transactions to production.
9. Mark the full stack green only after all of these gates pass.

## Change record for this audit

- Read-only SQL queries were run against production and isolated replay/backup databases.
- No production migration was applied.
- No production test data was written.
- No Neon branch was deleted.
- No Render environment variables or secrets were read or changed.
- No release approval is claimed.
