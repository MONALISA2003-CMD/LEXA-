-- READ ONLY. Run against the intended production branch/database AFTER the approved migration.
-- No DDL or DML is executed by this script.
SELECT jsonb_build_object(
  'database', current_database(),
  'postgres_version', current_setting('server_version'),
  'latest_migration', (
    SELECT version FROM public.schema_migrations
    ORDER BY applied_at DESC, version DESC LIMIT 1
  ),
  'migration_048_present', EXISTS (
    SELECT 1 FROM public.schema_migrations
    WHERE version='048_phase7_approval_limits_reversals_accounting'
  ),
  'approval_table_present', to_regclass('public.purchase_approval_limits') IS NOT NULL,
  'approval_guard_present', to_regprocedure('public.enforce_purchase_order_approval_limit()') IS NOT NULL,
  'receipt_journal_function_present', to_regprocedure('public.post_purchase_receipt_journal(uuid)') IS NOT NULL,
  'supplier_journal_function_present', to_regprocedure('public.post_supplier_ledger_journal(uuid)') IS NOT NULL,
  'approval_rls_forced', EXISTS (
    SELECT 1 FROM pg_class c
    WHERE c.oid=to_regclass('public.purchase_approval_limits')
      AND c.relrowsecurity AND c.relforcerowsecurity
  ),
  'approval_tenant_policy_present', EXISTS (
    SELECT 1 FROM pg_policy p
    WHERE p.polrelid=to_regclass('public.purchase_approval_limits')
      AND p.polname='purchase_approval_limits_tenant_isolation'
  ),
  'receipt_journal_trigger_present', EXISTS (
    SELECT 1 FROM pg_trigger t
    WHERE t.tgrelid=to_regclass('public.purchase_receipts')
      AND t.tgname='trg_purchasing_receipt_after_post' AND NOT t.tgisinternal
  ),
  'supplier_journal_trigger_present', EXISTS (
    SELECT 1 FROM pg_trigger t
    WHERE t.tgrelid=to_regclass('public.supplier_ledger_entries')
      AND t.tgname='trg_purchasing_supplier_ledger_after_insert' AND NOT t.tgisinternal
  ),
  'return_reversal_columns_present', EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema='public' AND table_name='purchase_returns'
      AND column_name='reversal_reason'
  ),
  'tenants', (SELECT count(*) FROM public.tenants),
  'sales_rows', (SELECT count(*) FROM public.sales),
  'payment_rows', (SELECT count(*) FROM public.payments),
  'purchase_order_rows', (SELECT count(*) FROM public.purchase_orders),
  'purchase_receipt_rows', (SELECT count(*) FROM public.purchase_receipts),
  'supplier_bill_rows', (SELECT count(*) FROM public.supplier_bills),
  'journal_entry_rows', (SELECT count(*) FROM public.journal_entries),
  'analytics_refresh_runs', (SELECT count(*) FROM public.analytics_refresh_runs),
  'analytics_product_daily_metrics', (SELECT count(*) FROM public.analytics_product_daily_metrics),
  'analytics_daily_business_metrics', (SELECT count(*) FROM public.analytics_daily_business_metrics),
  'analytics_branch_daily_metrics', (SELECT count(*) FROM public.analytics_branch_daily_metrics),
  'analytics_customer_purchase_patterns', (SELECT count(*) FROM public.analytics_customer_purchase_patterns),
  'analytics_inventory_health_metrics', (SELECT count(*) FROM public.analytics_inventory_health_metrics),
  'latest_successful_refresh', (
    SELECT jsonb_build_object(
      'from_date', from_date, 'to_date', to_date, 'completed_at', completed_at
    ) FROM public.analytics_refresh_runs
    WHERE status='SUCCEEDED' ORDER BY completed_at DESC LIMIT 1
  )
) AS release_audit;
