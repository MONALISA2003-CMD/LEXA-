-- READ ONLY: run against the intended Neon branch/database after the approved migration.
-- This query does not change data or schema.
SELECT json_build_object(
  'database', current_database(),
  'postgres_version', current_setting('server_version'),
  'migration_048_present', EXISTS (
    SELECT 1 FROM public.schema_migrations
    WHERE version = '048_phase7_approval_limits_reversals_accounting'
  ),
  'approval_limits_table_present', to_regclass('public.purchase_approval_limits') IS NOT NULL,
  'approval_guard_present', to_regprocedure('public.enforce_purchase_order_approval_limit()') IS NOT NULL,
  'receipt_journal_function_present', to_regprocedure('public.post_purchase_receipt_journal(uuid)') IS NOT NULL,
  'supplier_ledger_journal_function_present', to_regprocedure('public.post_supplier_ledger_journal(uuid)') IS NOT NULL,
  'analytics_refresh_table_present', to_regclass('public.analytics_refresh_runs') IS NOT NULL,
  'daily_product_metrics_present', to_regclass('public.analytics_product_daily_metrics') IS NOT NULL,
  'latest_refresh', (
    SELECT json_build_object(
      'status', status, 'from_date', from_date, 'to_date', to_date,
      'completed_at', completed_at
    )
    FROM public.analytics_refresh_runs
    ORDER BY started_at DESC LIMIT 1
  ),
  'latest_successful_refresh', (
    SELECT json_build_object(
      'from_date', from_date, 'to_date', to_date, 'completed_at', completed_at
    )
    FROM public.analytics_refresh_runs
    WHERE status = 'SUCCEEDED'
    ORDER BY completed_at DESC LIMIT 1
  )
) AS release_audit;
