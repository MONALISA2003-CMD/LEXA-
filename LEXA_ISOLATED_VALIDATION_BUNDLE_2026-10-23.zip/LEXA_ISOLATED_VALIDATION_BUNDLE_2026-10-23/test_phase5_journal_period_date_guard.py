"""Static regression contract for the Phase 5 accounting-period date guard.

The SQL migration must also be exercised against disposable PostgreSQL before release.
"""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
MIGRATION = ROOT / "migrations" / "045_phase5_journal_period_date_guard.sql"


def test_posting_guard_loads_period_dates_for_the_same_tenant():
    sql = MIGRATION.read_text()
    assert "WHERE tenant_id = v_tenant AND id = v_period" in sql
    assert "SELECT start_date, end_date, status" in sql
    assert "IF NOT FOUND THEN RAISE EXCEPTION 'Accounting period not found for journal tenant'" in sql


def test_posting_rejects_dates_outside_the_open_accounting_period():
    sql = MIGRATION.read_text()
    assert "IF v_period_status <> 'OPEN' THEN" in sql
    assert "IF v_entry_date < v_period_start OR v_entry_date > v_period_end THEN" in sql
    assert "Journal entry date % is outside accounting period [% - %]" in sql


def test_existing_phase5_currency_balance_and_account_guards_are_preserved():
    sql = MIGRATION.read_text()
    for token in (
        "Only draft journal entries can be posted",
        "v_currency !~ '^[A-Z]{3}$'",
        "upper(jl.currency_code) <> v_currency",
        "round(v_debit, 4) <> round(v_credit, 4)",
        "v_lines < 2",
        "a.status <> 'ACTIVE' OR NOT a.allow_posting",
        "GRANT EXECUTE ON FUNCTION public.post_journal_entry(uuid, uuid) TO lexa_app",
        "045_phase5_journal_period_date_guard",
    ):
        assert token in sql


def test_migration_is_forward_only_and_does_not_rewrite_historical_journals():
    sql = MIGRATION.read_text().lower()
    assert sql.strip().startswith("-- lexa phase 5 hardening candidate")
    assert "update public.journal_entries" in sql  # only the function's posting transition
    assert "delete from public.journal_entries" not in sql
    assert "truncate public.journal_entries" not in sql
