# LEXA isolated recovery and Phase 5 validation report

**Run date:** 2026-10-23 (UTC)  
**Scope:** LEXA main and LEXA Backup only; all writes in this run were to a separate disposable restore branch inside the `LEXA-BACKUP-20261022` Neon project.  
**Status:** Partial validation completed. Do **not** treat this as release approval or as proof of a clean full-chain replay.

## Executive result

- The provider successfully restored the backup's saved snapshot into a new branch named `lexa-recovery-drill-20261023`, branch ID `br-noisy-water-bay4966c`, from snapshot `snap-autumn-cherry-baa1e2r3`.
- The restored branch reproduced the starting backup baseline of 119 public tables, with row-level security enabled and forced on every table, 460 public routines, 127 policies, 36 user triggers, no public views or sequences, and the backup's 31-row migration ledger through `031_phase3_auth_surface_rls`.
- Canonical migrations 033–038 were replayed on that isolated branch. Migration 038's `CREATE INDEX CONCURRENTLY` statements were correctly executed outside a transaction after the transaction-wrapped attempt correctly failed.
- Canonical migration 043 and candidate migration 045 were then applied on the disposable branch for targeted behavioral tests. This was a **targeted test branch, not a clean end-to-end replay**: migrations 039–042 and 044 were not applied because the execution integration blocked the call before those statements ran.
- PostgreSQL behavior tests for period boundaries, invalid period/tenant context, no partial journal writes on failed posting, journal reversal, and duplicate reversal all passed.
- Static source-contract tests for migration 045: **4 passed** (`pytest -q apps/api/tests/test_phase5_journal_period_date_guard.py`).
- Deeper dynamic tests for refund/customer-credit reconciliation, return-journal idempotency, and failure rollback after a return-journal has partially written were not completed. The tool blocked the synthetic fixture transaction before it executed; observed fixture counts confirm those rows were not added.
- Both original database branches, GitHub, Render and Vercel were left unchanged.

## 1. Exact scope and non-mutation statement

| Resource | Treatment |
|---|---|
| Neon LEXA main project `wispy-mud-75323042`, branch `br-soft-star-b1dj2m2w`, DB `neondb` | Read-only inspection only |
| Neon LEXA Backup project `weathered-tooth-59279917`, original branch `br-noisy-sea-ba35uu3p`, DB `lexa_backup` | Read-only inspection only |
| Neon disposable restored branch `br-noisy-water-bay4966c` | Snapshot restore, test-only migration replay, candidate guard, and synthetic QA journals |
| GitHub `MONALISA2003-CMD/LEXA-` | Read-only fetch; no branch/file writes |
| LEXA Render service and LEXA Vercel project | Not changed; no deploy triggered |

The disposable branch now contains synthetic QA data and the candidate migration marker. It has intentionally **not** been deleted: deleting a branch is destructive and requires separate authorization. The branch must not be routed to the app or promoted to the original backup branch.

## 2. Snapshot and table-data verification

### Provider restore baseline

Immediately after restoration, direct PostgreSQL checks showed:

- PostgreSQL 18.6.
- 119 public base tables.
- RLS enabled on 119/119 tables; FORCE RLS on 119/119 tables.
- 460 public routines, 127 public policies, 36 non-internal public-table triggers.
- Zero public views and zero public sequences.
- 31 migration rows with newest version `031_phase3_auth_surface_rls`.
- Core business tables such as `sales`, `sale_returns`, `refund_records`, `customer_credits`, `journal_entries`, and `journal_lines` had no rows in the saved backup baseline.

### Data comparison against the original backup branch

Before evaluating post-migration counts, row counts and a canonical JSON row digest were compared between the source backup branch and the restored branch for **99 common, unaffected public tables**. Result: 99 tables compared on each side and **zero row-count or digest differences**.

The original backup's own `lexa_backup_archive.table_verification` records also report 119/119 table row-count matches and 119/119 content matches for the selective archive it created. These are two separate facts: its manifest verifies its archive process; the new disposable restore comparison independently checks 99 unaffected tables after provider restore.

### Important exclusions / restore limits

The archive manifest describes this as `selective_native_schema_and_data_copy` with status `VERIFIED_WITH_EXPLICIT_EXCLUSIONS`, not a byte-identical provider snapshot. It records 107 data-included tables and 12 excluded tables, with 57 omitted source rows: 38 sessions, 16 outbox events, and 3 idempotency records. It also says production role passwords and short-lived security-token rows were not copied. Therefore, this run proves the saved provider snapshot can be restored and that selected data is consistent; it does **not** prove the selective archive includes all live operational state or can replace the original database.

## 3. Migration replay notes

The following current repository SQL files were fetched from `MONALISA2003-CMD/LEXA-` `main` and executed only on the new restored branch:

| Migration | Git object SHA | Result |
|---|---|---|
| `033_phase5_refund_settlement_consistency.sql` | `0b0d7cfad51e830935a653d45dca2d0f619b3ebe` | Applied |
| `034_phase5_return_accounting_journals.sql` | `f68850a43fcbd5529a4dc5569e052913363ca605` | Applied |
| `035_phase5_none_return_receivable_guard.sql` | `c81eb346db3810d94b7e6d1175a929434924ebbe` | Applied |
| `036_phase6_inventory_intelligence.sql` | `e1c9511ee950800f203a07e0e37fc52efbeb1f74` | Applied |
| `037_phase6_inventory_ageing_index.sql` | `07a09892cb7087faf391ea16c39287b54726ff48` | Applied |
| `038_phase6_movement_health_indexes.sql` | `5b03b8a75bd4c8df847b673b360a1254adc352e2` | Applied non-transactionally as its comments require |
| `039`–`042` | — | Not applied; executor blocked the call before execution |
| `043_phase5_journal_currency_guard.sql` | `c80b2515fc2d814be09700e2e7aa4cc3397f962d` | Applied to support the targeted test |
| `044_phase3_password_reset_security.sql` | `dfc2eee8f48c6357dc79cfbabf685e067705f7eb` | Not applied |
| Candidate `045_phase5_journal_period_date_guard.sql` | Local candidate; not found at this exact path by the GitHub read integration | Applied to the disposable branch for targeted tests |

Do not use this branch ledger as proof of a clean canonical migration sequence: it intentionally skips 039–042 and 044 and applies 043/045 for the focused test. A fresh, clean replay with an execution harness that preserves migration transaction semantics is still a release gate.

After targeted migration and test setup, the disposable branch had 120 public tables, 120/120 with RLS enabled and forced, 464 routines, 128 policies, 37 triggers, zero views, and zero sequences. The changed counts are expected from the migrations and test-only changes; they are not comparable to the pre-migration baseline without accounting for those changes.

## 4. PostgreSQL behavior tests — passed

The candidate `post_journal_entry` function was exercised with balanced synthetic journal entries and tenant-specific periods in one test transaction, only on branch `br-noisy-water-bay4966c`.

| Test case | Result | Evidence/expected state |
|---|---|---|
| First day of open period (`2026-06-01`) | PASS | Entry transitioned from DRAFT to POSTED |
| Last day of open period (`2026-06-30`) | PASS | Entry transitioned from DRAFT to POSTED |
| One day before (`2026-05-31`) | PASS | Rejected with period-boundary error; row remained DRAFT and `posted_at` stayed null |
| One day after (`2026-07-01`) | PASS | Rejected with period-boundary error; row remained DRAFT and `posted_at` stayed null |
| Closed period (`2026-07-15`) | PASS | Rejected because period was not OPEN; row remained DRAFT and `posted_at` stayed null |
| Cross-tenant period ID | PASS | Tenant-scoped period lookup rejected it; journal header and lines were absent after the failed attempt |
| Reverse a posted journal | PASS | Original marked REVERSED; one linked reversal journal was POSTED |
| Attempt a second reversal | PASS | Rejected; no duplicate reversal was recorded |

These exercise the real PostgreSQL routine, FK/tenant constraints, and transaction behavior for journal-posting failures. They do not prove the full HTTP/API posting path or all Phase 5 accounting paths.

## 5. Phase 5 review: source routines, state and current gaps

Inspected functions on the restored branch include:

- `post_sale_return_journal(uuid, uuid)`: calculates tax/net return, recorded refunds, non-cancelled customer credit, receivable reduction, and includes a return-settlement idempotency lookup keyed by tenant/source/role.
- `refresh_sale_payment_totals(uuid, uuid)`: derives collected amount from recorded allocations, subtracts recorded refunds, separates credit issued from credit applied, then refreshes sale paid/due totals.
- `refresh_customer_credit(uuid)`: derives allocated amount, remaining balance, and credit state from recorded credit allocations.
- `reverse_journal_entry(uuid, uuid, date)`: reverses posted journal lines and uses a linked reversal header; duplicate reversal is prevented.
- Trigger inventory includes posted journal header/line protection, customer-credit allocation validation and total refresh, refund reconciliation and sale-payment total refresh.

These are source/schema observations plus the targeted journal and reversal tests. The remaining dynamic transaction tests were blocked before execution, so the following are **not yet proven**:

1. A mixed cash-refund / customer-credit / receivable reduction example reconciles to the precise expected amounts across sales, return, refund, credit, and journal lines.
2. Calling `post_sale_return_journal` twice with an unchanged source return returns the same ID and creates no duplicate journal.
3. Customer credit allocation refresh produces the correct partial-use balance, and reversal of the allocation restores prior state.
4. A deliberately invalid currency/account on a return journal causes the whole return-posting operation to roll back all journal headers and lines.
5. A provider/API smoke run pointed to the disposable branch; the existing Render application was not pointed at the test branch.

Do not infer success for these from the fact that the tables began empty or that the SQL function definitions look plausible.

## 6. Security and privileges: release blocker found

RLS being enabled and forced is not sufficient if a runtime role can bypass RLS. A direct `pg_roles` query on the original backup branch **and** the restored branch reported `rolcanlogin=true`, `rolbypassrls=true`, `rolcreaterole=true`, and `rolcreatedb=true` for roles including `lexa_app`, `lexa_runtime`, `lexa_runtime_safe`, `lexa_runtime_login_p3`, and `lexa_backup_admin`. The role-management API surfaced conflicting login metadata for some roles, so direct PostgreSQL role flags must be treated as the evidence to resolve.

This is a high-priority security review item. The run did not alter privileges. Confirm the intended role model and grants from the migration/source manifest with database-owner review, and prove tenant-isolation using a runtime role whose actual PostgreSQL privileges are correct. Do not declare backup or application security verified just because all tables report FORCE RLS.

Partial grant checks succeeded on the restored test branch: `lexa_app` had SELECT/INSERT access and EXECUTE access on `post_journal_entry(uuid,uuid)`, `post_sale_return_journal(uuid,uuid)`, and `refresh_sale_payment_totals(uuid,uuid)`. A complete baseline-vs-restore table/routine grant comparison and an application smoke call were blocked by the current tool integration; grant parity is therefore not fully proven.

## 7. Current GitHub status for the candidate

A read-only fetch of `migrations/045_phase5_journal_period_date_guard.sql` from `main` returned HTTP 404. That does not exclude the possibility that a ZIP was uploaded to another path, but it means this exact migration path was not verifiable as a committed migration at the time of this check. No GitHub write was made from this session.

## 8. Release gate / next steps

Do **not** apply migration 045 to either original branch yet. Recommended next sequence:

1. Resolve the runtime-role `BYPASSRLS` and role-privilege finding, with a tenant-isolation test on the correct application role.
2. Create a fresh disposable replay target, run all canonical migrations in the intended order—including 038 outside transaction and with no skipped 039–044—and capture schema/routine/grant fingerprints.
3. Add the actual PostgreSQL behavior test as a durable integration script; run the missing refund/credit/idempotency/rollback scenarios in the same isolated database once the execution path supports synthetic fixtures safely.
4. Run an API smoke test against the disposable target only, using isolated test credentials and a test-only configuration. Do not repoint Render.
5. Compare grant, policy, trigger and routine inventories with the manifest; document all excluded session/outbox/idempotency state and the intended recovery point.
6. Only after evidence and review, prepare a release candidate; no production migration, schema sync, backup overwrite, or deployment is authorized by this report.

**Bottom line:** snapshot restoration and targeted period/reversal PostgreSQL tests have real passing evidence. The overall restore/security gate remains **NOT PASSED** because role bypass-RLS privileges require reconciliation, full grant comparison/application smoke did not complete, the migration replay was not clean end-to-end, and refund/customer-credit transactional tests remain outstanding.
