# LEXA Phase 00–01 baseline and implementation record

**Observed:** 25 October 2026 (UTC)  
**Repository:** `MONALISA2003-CMD/LEXA-`  
**Baseline `main` SHA:** `cd7fba79e4e75048a5e0b72c74f99053a627b023`  
**Status:** source overlay prepared; GitHub writes blocked by integration HTTP 403; no PR or CI run exists for this change.

## Phase 00 — Source and infrastructure baseline

### Source of truth

- The latest observed `main` commit adds `LEXA_PHASE7_DOWNLOAD_FOR_PHONE.zip`; it does not edit the SQL migration or its test.
- Current GitHub blob identifiers observed for migration 048 and its test are recorded in `SOURCE_BASELINE.json`. Those source files match the baseline expected by this overlay.
- The existing `.github/workflows/lexa-ci.yml` is retained. It runs API tests, web typecheck/tests/build and compose configuration checks only when their configured source paths change; uploading a ZIP alone does not satisfy these path filters.
- The repository is a full application source tree; this bundle is an overlay only. Never unpack this ZIP over the whole repository or treat it as the full source.

### Hosted revision identity

- Vercel project `lexa`: latest observed production-target deployment `dpl_CuGCMupuEfirG1FqWE6fv4fzy2mT`, state `READY`, branch `main`, SHA `cd7fba79e4e75048a5e0b72c74f99053a627b023`.
- Render service `LEXA`: latest observed live deployment `dep-dbetr7ajnfac73e56tkg`, SHA `aa4cdf46c9f59d4be120886b63613122cd3bf94a`.
- These SHAs differ. Deployment metadata/build readiness does not prove the same source is running on both hosts or that critical workflows pass.
- Neon project metadata identifies live project `LEXA` / branch `lexa-live`, plus separate backup and replay projects. Production SQL was not executed during this implementation phase. Earlier supplied read-only release-gate evidence states production was missing migration 048 and remained at migration 047 at audit time; reconfirm through the approved read-only audit before any future release decision.

### Access and changes

- Feature-branch creation was attempted against GitHub and rejected with HTTP 403: `Resource not accessible by integration`.
- No remote Git writes, PR creation, production query, database mutation, migration, branch deletion or deployment were performed.
- This bundle is the fallback source overlay requested by the owner. An authorized maintainer must apply it to a feature branch and review the resulting diff.

## Phase 01 — Platform foundations and migration reliability

### Included changes

1. `migrations/048_phase7_approval_limits_reversals_accounting.sql`: replace the three undeclared `v_cash` references with the declared `a_cash` variable in the supplier-payment journal branch.
2. `apps/api/tests/test_phase7_approval_reversal_accounting.py`: add a regression test that asserts the declared variable is used and `v_cash` no longer occurs in that function.
3. Add `.github/workflows/lexa-phase7-validation.yml` without replacing the existing canonical CI workflow. It runs clean replay against an empty CI-only PostgreSQL instance and then validates the phase-7 schema/RLS and purchase accounting behavior.
4. Add replay scripts under `scripts/` for schema/privilege checks and isolated receipt/bill/payment/reversal/approval-limit behavior.
5. Add this baseline record to the application repository under `docs/engineering/` when installed.

### Required gates after application

From a clean checkout on a feature branch:

```bash
git diff --check
python -m pytest apps/api/tests/test_phase7_approval_reversal_accounting.py -q
python scripts/run_clean_migration_replay.py --plan-only
```

Then require the existing GitHub CI and the additive Phase 7 replay workflow to pass on the same commit SHA. Inspect uploaded replay evidence and logs. The entire database replay and behavior test sequence has **not** been run by this chat environment.

## Explicit non-goals

- Do not run or apply migration 048 in production as part of Phase 00/01.
- Do not create, delete or overwrite production/Neon branches or use the old selective backup as a full restore-tested pre-migration backup.
- Do not deploy this overlay directly.
- Do not add EFRIS/URA APIs, payment gateways, mobile-money or bank APIs.
- Do not claim production readiness based on files, unit tests or deployment `READY` state alone.
