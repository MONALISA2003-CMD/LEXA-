# LEXA Phase 00–01 implementation overlay — start here

The GitHub integration rejected feature-branch creation with HTTP 403, so this ZIP is the requested fallback. It is a source overlay, not a full project archive.

## Install

1. Download/extract the ZIP.
2. Use the existing full LEXA repository checkout at the source revision recorded in `SOURCE_BASELINE.json` (current observed `main`: `cd7fba79e4e75048a5e0b72c74f99053a627b023`).
3. Prefer a feature branch. Run `APPLY/apply_phase7_fix.py --repo /path/to/LEXA-`.
4. Review `git diff --check` and the full diff. Do not force the patch if actual source differs.
5. Run the targeted pytest and migration replay plan commands shown in `README.md`.
6. Push/open a PR through an authorized GitHub account, then require existing CI and the new isolated Phase 7 workflow to pass on the same SHA.

## Changes in this overlay

- Phase 00 repository/hosted SHA baseline record.
- Phase 01 migration 048 supplier-payment variable correction and regression test.
- An additive disposable PostgreSQL replay workflow and phase-7 schema/accounting behavior scripts.

## Do not release from this ZIP

The prior audit data reports live production missing migration 048, no current complete restore-tested pre-migration backup and staging acceptance not proven. No production SQL was run during this implementation. Do not apply migration 048 to production or bypass the readiness gate. A `READY` frontend deployment is not proof of end-to-end business correctness. See `AUDIT/LEXA_RELEASE_GATE_REAUDIT_2026-10-25.md` and `RELEASE_CHECKLIST.md`.
