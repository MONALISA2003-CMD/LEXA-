# LEXA Phase 00–01 baseline + migration reliability overlay

**Observed `main`:** `cd7fba79e4e75048a5e0b72c74f99053a627b023` (25 October 2026)  
**Repository:** https://github.com/MONALISA2003-CMD/LEXA-

This ZIP is an **apply-ready source overlay**, not a full repository, backup image, deployment or production migration package. GitHub feature-branch creation was rejected by the connected integration with HTTP 403 (`Resource not accessible by integration`), so this package is the requested fallback. No remote write was completed.

## What's included

- `SOURCE_BASELINE.json` and `OVERLAY/docs/engineering/phase-00-01-baseline-2026-10-25.md`: latest observed repo/deployment identity, known gaps and implementation boundary.
- `PATCHES/0001-fix-phase7-048-cash-variable.patch`: fix three undeclared `v_cash` references in the migration's supplier-payment journal path and add regression coverage.
- `APPLY/apply_phase7_fix.py`: guarded installer that checks source context, refuses conflicting overlay files and performs post-apply checks. It does not connect to a database, commit, push or deploy.
- `OVERLAY/.github/workflows/lexa-phase7-validation.yml`: additive CI job; the existing `.github/workflows/lexa-ci.yml` is preserved.
- `OVERLAY/scripts/check_phase7_replay.py` and `check_phase7_behavioral_replay.py`: clean-runner schema/RLS/accounting behavior verification scripts.
- `AUDIT/` and `EVIDENCE/`: existing supplied read-only audit records and isolated Neon replay evidence. These are historical/source artifacts, not new production checks performed in this run.

## Confirmed migration defect

`post_supplier_ledger_journal` declares `a_cash uuid` but the supplier payment branch uses the undeclared identifier `v_cash` in three places. This overlay switches those references to `a_cash` and adds a regression test.

## Apply to the current repository checkout

Extract the ZIP and run:

```bash
python /path/to/LEXA_PHASE00_01_IMPLEMENTATION_BUNDLE_2026-10-25/APPLY/apply_phase7_fix.py --repo /path/to/LEXA-
```

Review the resulting diff. The installer refuses unexpected source states and conflicting overlay files. If the installer refuses, do not force-apply; compare the actual source to `SOURCE_BASELINE.json` first.

Then run from repository root:

```bash
git diff --check
python -m pytest apps/api/tests/test_phase7_approval_reversal_accounting.py -q
python scripts/run_clean_migration_replay.py --plan-only
```

After commit/PR through an authorized GitHub workflow, require both the existing CI and the additive Phase 7 replay workflow to pass on the same SHA. Inspect artifacts and logs. This chat environment did not run the full repository CI or complete PostgreSQL replay.

## Safety boundary

No production SQL or migration was run, no production/Neon branches were changed, no secrets were read, and no deployment was initiated. Do not apply migration 048 to production until the current complete backup has been restored/verified and the normal approval and staging acceptance gates have passed. **No EFRIS or payment API integration is included.**
