# LEXA — phone-first Phase 00–01 handoff

This ZIP is a source overlay because GitHub branch creation was rejected with HTTP 403. It is not the whole project and is not a deployment.

## Included

- Phase 00 baseline for source/deployment revision identity and current evidence limitations.
- Migration 048 fix: three `v_cash` references changed to the declared `a_cash` variable.
- Regression test for that exact defect.
- Additive isolated PostgreSQL replay workflow plus schema and accounting checks.
- Guarded apply script and checksum manifest.

## Next authorized maintainer steps

Apply to the full repo using `APPLY/apply_phase7_fix.py`, inspect the diff, run the commands in `README.md`, then open a PR through an authorized GitHub identity. Review both CI workflows and the replay artifacts on the same SHA.

## Not completed

- No GitHub source write or PR created; integration returned HTTP 403.
- Full GitHub CI and full repository clean replay have not run on this overlay.
- No production SQL, migration, Neon branch change or deployment occurred.
- Production release readiness is not claimed; previous audit evidence reports migration 048 absent in production, backup/release approval gates incomplete, and authenticated end-to-end acceptance outstanding.

No EFRIS/payment gateway APIs are added. Do not use this ZIP to apply production migrations.
