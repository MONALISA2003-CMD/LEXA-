# Acceptance matrix — Phase 3 Increments 01–06 candidate

| Area | Candidate implementation/evidence | Status | Remaining gate |
|---|---|---|---|
| Business profile and first branch | Increment 01 API/UI prerequisite is in the combined overlay; static source contracts pass. | Candidate implemented | DB/API tests for create/update, retries and partial setup failure. |
| Workspace selection/switching | Active-membership-backed options; destination active check; old session revoked before tenant-context change; workspace picker. | Source implemented | Authenticated refresh/revocation E2E; zero/one/multiple workspace cases; stale cache denial. |
| Resume onboarding | Progress derives from stored profile, branch, warehouse and location records. | Source implemented | ASGI/Postgres tests for partial setup, retries, deactivated records, and duplicate create. |
| Invitation token | Hash-at-rest, expiry, email binding, one-use accept/revoke/resend; no raw token in audit/outbox. | Source/contracts + selected RLS evidence | Concurrent accept/replay/expiry E2E; actual email strategy; account-registration paths. |
| Membership lifecycle | Tenant-scoped list/activate/deactivate; revokes workspace sessions; shared last-owner advisory lock. | Source/contracts | Concurrent two-owner-removal test under app role; authenticated session invalidation. |
| Member role assignment | `PUT /members/{id}/roles`, tenant role validation, no empty set, Owner-grant guard, audit/outbox, explicit UI Save. | Implemented in candidate; source tests pass | Authenticated positive/negative API tests, race tests and permissions seeded on a clean final replay. |
| Role permission admin | Owner-only role creation and permission catalog; custom role permission replacement; built-in Owner set protected. | Implemented in candidate; source tests pass | Permission ID tampering, role-change authorization tests and browser E2E. |
| Branch assignment model | Assignment data management and branch context. | Implemented in candidate | Prove assignments actually deny access on all branch-sensitive routes, including branch/warehouse deactivation paths. |
| Inventory branch enforcement | Balance/ledger/product history reads filtered; adjustments, stock counts and transfers check reachable locations; rebuild guarded by full branch scope; integrity read scoped. | Core routes guarded; source tests pass | Authenticated DB/API E2E, SQL query audit, race tests, legacy null-branch warehouse cleanup policy. |
| Sales and returns | Checkout ties sale branch to assigned location; sales/returns scope and location checks; receivable path checks; dashboard/reconciliation full-scope gates. | Core routes guarded; source tests pass | Verify every commerce endpoint and DB helper path, with assigned/unassigned branch cases. |
| Analytics/finance/compliance | Branch analytic row filters; workspace-wide analytics/finance/compliance requires full active-branch coverage and no active unscoped locations. | Fail-closed candidate | Route-by-route aggregation query audit and role-specific tests. |
| API/UI tests | Package validation: 34 Python, compile, 8 Node contracts and isolated TypeScript fixture pass. Full repo pytest in disposable installed-overlay checkout: 116 passed, 1 skipped because Redis is unavailable. | Source/package tests passed; full repository suite partial | Install Redis to rerun auth-refresh integration; app frontend Node 24 typecheck, tests and build on overlay. |
| Installer integration | Applied in a disposable reconstructed source checkout using copied installer with adjusted temporary HEAD guard; per-file source blob guards remained. | Smoke integration passed | Reproduce from canonical checkout at exact pinned commit when checkout network/access is available. |
| Schema/RLS | Earlier isolated replay selected RLS tests passed; 119 tables, 1,300 columns and recorded metadata counts. | Partial isolated evidence | Fresh empty-database replay using final bundle and canonical schema parity. |
| Historical SQL | Missing originals remain declared; equivalents live only in `reconstructed/`. Original 021 preserved. | Blocked | Recover six originals or approve forward-history plan and review 021 candidate. |
| CI/remote delivery | No hosted branch/PR/CI. Previous branch creation returned 403. | Not done | Authorized GitHub access, reviewed immutable commit and required CI checks. |
| Production/release | No production migrations, credentials, DB roles, hosted settings or deployment touched. | Not attempted | Separate explicit release approval, backup/rollback, runtime role plan and staging verification. |

## Historical source gate

Unresolved original migrations: `010_phase2_catalog_intelligence.sql`, `011_phase2_catalog_runtime_constraints.sql`, `023_phase4_purchasing_core.sql`, `024_phase4_purchasing_security.sql`, `025_phase4_purchasing_permissions.sql`, and `026_phase4_membership_branch_integrity.sql`. Candidate equivalents are not byte-identical history.
