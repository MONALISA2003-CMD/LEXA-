class CatalogValidation(ValueError):
    pass
